<?php

// Heading
$_['heading_title']    = 'MP Last-Modifies';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified MP Last-Modified module!';
$_['text_edit']        = 'Edit MP Last-Modified Module';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify MP Last-Modified module!';