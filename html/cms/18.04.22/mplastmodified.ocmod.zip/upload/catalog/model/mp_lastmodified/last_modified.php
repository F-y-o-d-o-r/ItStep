<?php

class ModelMpLastmodifiedLastModified extends Model {
	
	public function getLastCategoryTime($catalog_id=false) {
		$query = $this->db->query("SELECT date_modified FROM " . DB_PREFIX . "category c
		INNER JOIN " . DB_PREFIX . "category_description cd ON (c.category_id = cd.category_id)
		LEFT JOIN " . DB_PREFIX . "category_to_store c2s ON (c.category_id = c2s.category_id)
		WHERE
			".($catalog_id?"c.category_id = {$catalog_id} AND":'')."
			cd.language_id = '" . (int)$this->config->get('config_language_id') . "' AND
			c2s.store_id = '" . (int)$this->config->get('config_store_id') . "' AND
			c.status = '1'
		ORDER BY date_modified DESC LIMIT 1");
		
		if ($query->num_rows)
			return $query->row['date_modified'];
		else 
			return false;
	}
	
	public function getLastProductTime($catalog_id=false) {
		$query = $this->db->query("SELECT date_modified FROM " . DB_PREFIX . "product p
		INNER JOIN " . DB_PREFIX . "product_description pd ON (p.product_id = pd.product_id)
		LEFT JOIN " . DB_PREFIX . "product_to_store p2s ON (p.product_id = p2s.product_id)
		".($catalog_id?"INNER JOIN " . DB_PREFIX . "product_to_category p2c ON (p.product_id = p2c.product_id)":"")."
		WHERE
			pd.language_id = '" . (int)$this->config->get('config_language_id') . "' AND
			p2s.store_id = '" . (int)$this->config->get('config_store_id') . "' AND
			p.status = '1'
			".($catalog_id?" AND p2c.category_id = {$catalog_id}":"")."
		ORDER BY date_modified DESC LIMIT 1");

		if ($query->num_rows)
			return $query->row['date_modified'];
		else 
			return false;
	}
	
	public function getProductTime($product_id) {
		$query = $this->db->query("SELECT date_modified FROM " . DB_PREFIX . "product p
		INNER JOIN " . DB_PREFIX . "product_description pd ON (p.product_id = pd.product_id)
		LEFT JOIN " . DB_PREFIX . "product_to_store p2s ON (p.product_id = p2s.product_id)
		WHERE
			p.product_id = {$product_id} AND
			pd.language_id = '" . (int)$this->config->get('config_language_id') . "' AND
			p2s.store_id = '" . (int)$this->config->get('config_store_id') . "' AND
			p.status = '1'
		LIMIT 1");

		if ($query->num_rows)
			return $query->row['date_modified'];
		else 
			return false;
	}
}

