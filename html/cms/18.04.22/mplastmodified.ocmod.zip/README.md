For return 304 last modified since header for home, product and category pages to crawl new pages by google easily.

This extension helps you to crawl more pages of your website. Googlebot uses an algorithmic process computer programs determine which sites to crawl, how often, and how many pages to fetch from each site. Googlebot's crawl, copy of each page at a time. If you see that Googlebot is downloading a page multiple times, it's probably because the crawler was stopped and restarted. By using this extension it returns header "304 Not Modified" and google bot skipp that page and shift to next page and by this way google will index more pages of your store.

Installation: standard OCMOD extension.

Возврат заголовка 304 Last-Modified, для главной страницы, страниц продукта и категории, для облегчения сканирования новых страниц с помощью Google и других поисковых ботов. Время последнего изменения для главной страницы берется с самого последнего изменения из всех категорий и продуктов. Для страницы категории время последнего изменения берется максимальное либо с последнего изменения категории, либо товаров, входящих в неё.

Это расширение позволяет улучшить эффективность сканирования страниц вашего сайта. Поисковый бот использует алгоритмический процесс, программы определяют какие сайты нужно сканировать, как часто и сколько страниц. Если вы видите, что поисковый бот загружает страницу несколько раз, это, вероятно, потому, что бот был остановлен и перезапущен. Это расширение возвращает заголовок "304 Not Modified", и поисковый бот пропускает эту страницу переходя на следующую, там образом поисковик будет индексировать больше страниц вашего магазина.

Заголовок Last-Modified отдает время последнего изменения документа. Эта информация, несомненно, в какой-то мере полезна, и если этот заголовок не отдавать, то, к примеру, в Яндексе в сниппетах не будет показываться дата документа, и он также будет отсутствовать в результатах поиска, отсортированных по дате. Однако, собственно управлять индексацией с помощью этого заголовка невозможно.

Дело в том, что поисковый робот для документа, который он еще ни разу не индексировал, в первый раз задает запрос GET без всяких условий. А вот при повторном обращении к нему, он задает запрос с заголовком If-Modified-Since, в котором указывает дату предыдущей индексации документа. Вот, к примеру, выдержка из документации к продукту для поиска по корпоративным ресурсам Google Search Appliance: «During the recrawl of an indexed document, the Google Search Appliance sends the If-Modified-Since header based on the last crawl date of the document» («Во время повторной индексации проиндексированного документа, Google Search Appliance посылает заголовок If-Modified-Since, основанный на дате последней индексации документа» — здесь и далее перевод автора).

И вот уже для ответа на запрос с заголовком If-Modified-Since согласно протоколу RFC2616 имеются следующие варианты:

a) If the request would normally result in anything other than a 200 (OK) status, or if the passed If-Modified-Since date is invalid, the response is exactly the same as for a normal GET. A date which is later than the server’s current time is invalid. (Если результат ответа на обычный запрос должен быть отличен от 200 (ОК), или если дата в If-Modified-Since некорректна, то ответ должен точно совпадать с ответом на обычный запрос GET. Дата, более поздняя, чем текущее время сервера, является некорректной).

b) If the variant has been modified since the If-Modified-Since date, the response is exactly the same as for a normal GET. (Если документ изменен с даты, указанной в If-Modified-Since, то ответ должен точно совпадать с ответом на обычный запрос GET.)

c) If the variant has not been modified since a valid If-Modified-Since date, the server SHOULD return a 304 (Not Modified) response. (Если документ не изменен с даты, указанной в If-Modified-Since, то сервер должен вернуть ответ 304 Not Modified.)

Информация с ресурса https://www.searchengines.ru/zagolovki_last_.html

При установке: стандартное расширение OCMOD.
