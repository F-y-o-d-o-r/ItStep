-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Апр 11 2018 г., 18:13
-- Версия сервера: 5.7.21-20-beget-5.7.21-20-1-log
-- Версия PHP: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `d99796fq_joomla`
--

-- --------------------------------------------------------

--
-- Структура таблицы `jm_assets`
--
-- Создание: Мар 30 2018 г., 11:27
-- Последнее обновление: Апр 11 2018 г., 09:27
--

DROP TABLE IF EXISTS `jm_assets`;
CREATE TABLE `jm_assets` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'Primary Key',
  `parent_id` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set parent.',
  `lft` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set lft.',
  `rgt` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set rgt.',
  `level` int(10) UNSIGNED NOT NULL COMMENT 'The cached level in the nested tree.',
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The unique name for the asset.\n',
  `title` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The descriptive title for the asset.',
  `rules` varchar(5120) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'JSON encoded access control.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `jm_assets`
--

INSERT INTO `jm_assets` (`id`, `parent_id`, `lft`, `rgt`, `level`, `name`, `title`, `rules`) VALUES
(1, 0, 0, 181, 0, 'root.1', 'Root Asset', '{\"core.login.site\":{\"6\":1,\"2\":1},\"core.login.admin\":{\"6\":1},\"core.login.offline\":{\"6\":1},\"core.admin\":{\"8\":1},\"core.manage\":{\"7\":1},\"core.create\":{\"6\":1,\"3\":1},\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"core.edit.own\":{\"6\":1,\"3\":1}}'),
(2, 1, 1, 2, 1, 'com_admin', 'com_admin', '{}'),
(3, 1, 3, 6, 1, 'com_banners', 'com_banners', '{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1}}'),
(4, 1, 7, 8, 1, 'com_cache', 'com_cache', '{\"core.admin\":{\"7\":1},\"core.manage\":{\"7\":1}}'),
(5, 1, 9, 10, 1, 'com_checkin', 'com_checkin', '{\"core.admin\":{\"7\":1},\"core.manage\":{\"7\":1}}'),
(6, 1, 11, 12, 1, 'com_config', 'com_config', '{}'),
(7, 1, 13, 16, 1, 'com_contact', 'com_contact', '{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1}}'),
(8, 1, 17, 22, 1, 'com_content', 'com_content', '{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1}}'),
(9, 1, 23, 24, 1, 'com_cpanel', 'com_cpanel', '{}'),
(10, 1, 25, 26, 1, 'com_installer', 'com_installer', '{\"core.manage\":{\"7\":0},\"core.delete\":{\"7\":0},\"core.edit.state\":{\"7\":0}}'),
(11, 1, 27, 30, 1, 'com_languages', 'com_languages', '{\"core.admin\":{\"7\":1}}'),
(12, 1, 31, 32, 1, 'com_login', 'com_login', '{}'),
(13, 1, 33, 34, 1, 'com_mailto', 'com_mailto', '{}'),
(14, 1, 35, 36, 1, 'com_massmail', 'com_massmail', '{}'),
(15, 1, 37, 38, 1, 'com_media', 'com_media', '{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":{\"5\":1}}'),
(16, 1, 39, 44, 1, 'com_menus', 'com_menus', '{\"core.admin\":{\"7\":1}}'),
(17, 1, 45, 46, 1, 'com_messages', 'com_messages', '{\"core.admin\":{\"7\":1},\"core.manage\":{\"7\":1}}'),
(18, 1, 47, 144, 1, 'com_modules', 'com_modules', '{\"core.admin\":{\"7\":1}}'),
(19, 1, 145, 148, 1, 'com_newsfeeds', 'com_newsfeeds', '{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1}}'),
(20, 1, 149, 150, 1, 'com_plugins', 'com_plugins', '{\"core.admin\":{\"7\":1}}'),
(21, 1, 151, 152, 1, 'com_redirect', 'com_redirect', '{\"core.admin\":{\"7\":1}}'),
(22, 1, 153, 154, 1, 'com_search', 'com_search', '{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1}}'),
(23, 1, 155, 156, 1, 'com_templates', 'com_templates', '{\"core.admin\":{\"7\":1}}'),
(24, 1, 157, 160, 1, 'com_users', 'com_users', '{\"core.admin\":{\"7\":1}}'),
(26, 1, 161, 162, 1, 'com_wrapper', 'com_wrapper', '{}'),
(27, 8, 18, 21, 2, 'com_content.category.2', 'Uncategorised', '{}'),
(28, 3, 4, 5, 2, 'com_banners.category.3', 'Uncategorised', '{}'),
(29, 7, 14, 15, 2, 'com_contact.category.4', 'Uncategorised', '{}'),
(30, 19, 146, 147, 2, 'com_newsfeeds.category.5', 'Uncategorised', '{}'),
(32, 24, 158, 159, 2, 'com_users.category.7', 'Uncategorised', '{}'),
(33, 1, 163, 164, 1, 'com_finder', 'com_finder', '{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1}}'),
(34, 1, 165, 166, 1, 'com_joomlaupdate', 'com_joomlaupdate', '{}'),
(35, 1, 167, 168, 1, 'com_tags', 'com_tags', '{}'),
(36, 1, 169, 170, 1, 'com_contenthistory', 'com_contenthistory', '{}'),
(37, 1, 171, 172, 1, 'com_ajax', 'com_ajax', '{}'),
(38, 1, 173, 174, 1, 'com_postinstall', 'com_postinstall', '{}'),
(39, 18, 48, 49, 2, 'com_modules.module.1', 'Main Menu', '{}'),
(40, 18, 50, 51, 2, 'com_modules.module.2', 'Login', '{}'),
(41, 18, 52, 53, 2, 'com_modules.module.3', 'Popular Articles', '{}'),
(42, 18, 54, 55, 2, 'com_modules.module.4', 'Recently Added Articles', '{}'),
(43, 18, 56, 57, 2, 'com_modules.module.8', 'Toolbar', '{}'),
(44, 18, 58, 59, 2, 'com_modules.module.9', 'Quick Icons', '{}'),
(45, 18, 60, 61, 2, 'com_modules.module.10', 'Logged-in Users', '{}'),
(46, 18, 62, 63, 2, 'com_modules.module.12', 'Admin Menu', '{}'),
(47, 18, 64, 65, 2, 'com_modules.module.13', 'Admin Submenu', '{}'),
(48, 18, 66, 67, 2, 'com_modules.module.14', 'User Status', '{}'),
(49, 18, 68, 69, 2, 'com_modules.module.15', 'Title', '{}'),
(50, 18, 70, 71, 2, 'com_modules.module.16', 'Login Form', '{}'),
(51, 18, 72, 73, 2, 'com_modules.module.17', 'Breadcrumbs', '{}'),
(52, 18, 74, 75, 2, 'com_modules.module.79', 'Multilanguage status', '{}'),
(53, 18, 76, 77, 2, 'com_modules.module.86', 'Joomla Version', '{}'),
(54, 18, 78, 79, 2, 'com_modules.module.87', 'Popular Tags', '{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),
(55, 18, 80, 81, 2, 'com_modules.module.88', 'Site Information', '{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),
(56, 18, 82, 83, 2, 'com_modules.module.89', 'Release News', '{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),
(57, 18, 84, 85, 2, 'com_modules.module.90', 'Latest Articles', '{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),
(58, 18, 86, 87, 2, 'com_modules.module.91', 'User Menu', '{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),
(59, 18, 88, 89, 2, 'com_modules.module.92', 'Image Module', '{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),
(60, 18, 90, 91, 2, 'com_modules.module.93', 'Search', '{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),
(61, 27, 19, 20, 3, 'com_content.article.1', 'Getting Started', '{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),
(62, 1, 175, 176, 1, '#__ucm_content.1', '#__ucm_content.1', '{}'),
(63, 11, 28, 29, 2, 'com_languages.language.2', 'Русский (Россия)', '{}'),
(64, 1, 177, 178, 1, 'com_fields', 'com_fields', '{}'),
(65, 1, 179, 180, 1, 'com_associations', 'com_associations', '{}'),
(66, 16, 40, 41, 2, 'com_menus.menu.3', 'Test', '{}'),
(67, 18, 92, 93, 2, 'com_modules.module.94', 'new test menu', '{}'),
(68, 18, 94, 95, 2, 'com_modules.module.95', 'Навигатор сайта (хлебные крошки)', '{}'),
(69, 16, 42, 43, 2, 'com_menus.menu.4', 'test menu 2', '{}'),
(70, 18, 96, 97, 2, 'com_modules.module.96', 'test menu 2', '{}'),
(71, 18, 98, 99, 2, 'com_modules.module.97', 'HTML-код', '{}'),
(72, 18, 100, 101, 2, 'com_modules.module.98', 'rss korr', '{}'),
(73, 18, 102, 103, 2, 'com_modules.module.99', 'banner', '{}'),
(74, 18, 104, 105, 2, 'com_modules.module.100', 'enter here', '{}'),
(75, 18, 106, 107, 2, 'com_modules.module.101', 'kategorii', '{}'),
(76, 18, 108, 109, 2, 'com_modules.module.102', 'who is here', '{}'),
(77, 18, 110, 111, 2, 'com_modules.module.103', 'rssssssssssssss', '{}'),
(78, 18, 112, 113, 2, 'com_modules.module.104', 'archive', '{}'),
(79, 18, 114, 115, 2, 'com_modules.module.105', 'news', '{}'),
(80, 18, 116, 117, 2, 'com_modules.module.106', 'last news', '{}'),
(81, 18, 118, 119, 2, 'com_modules.module.107', 'most readeble', '{}'),
(82, 18, 120, 121, 2, 'com_modules.module.108', 'the same', '{}'),
(83, 18, 122, 123, 2, 'com_modules.module.109', 'kateg', '{}'),
(84, 18, 124, 125, 2, 'com_modules.module.110', 'footer 2', '{}'),
(85, 18, 126, 127, 2, 'com_modules.module.111', 'last users registered', '{}'),
(86, 18, 128, 129, 2, 'com_modules.module.112', 'wrapper', '{}'),
(87, 18, 130, 131, 2, 'com_modules.module.113', 'languages', '{}'),
(88, 18, 132, 133, 2, 'com_modules.module.114', 'search here', '{}'),
(89, 18, 134, 135, 2, 'com_modules.module.115', 'popular tags', '{}'),
(90, 18, 136, 137, 2, 'com_modules.module.116', 'the same tags', '{}'),
(91, 18, 138, 139, 2, 'com_modules.module.117', 'random img', '{}'),
(92, 18, 140, 141, 2, 'com_modules.module.118', 'statistic', '{}'),
(93, 18, 142, 143, 2, 'com_modules.module.119', 'search good', '{}');

-- --------------------------------------------------------

--
-- Структура таблицы `jm_associations`
--
-- Создание: Мар 30 2018 г., 11:27
--

DROP TABLE IF EXISTS `jm_associations`;
CREATE TABLE `jm_associations` (
  `id` int(11) NOT NULL COMMENT 'A reference to the associated item.',
  `context` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The context of the associated item.',
  `key` char(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The key for the association computed from an md5 on associated ids.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `jm_banners`
--
-- Создание: Мар 30 2018 г., 11:27
--

DROP TABLE IF EXISTS `jm_banners`;
CREATE TABLE `jm_banners` (
  `id` int(11) NOT NULL,
  `cid` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(400) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `imptotal` int(11) NOT NULL DEFAULT '0',
  `impmade` int(11) NOT NULL DEFAULT '0',
  `clicks` int(11) NOT NULL DEFAULT '0',
  `clickurl` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `catid` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `custombannercode` varchar(2048) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sticky` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `metakey` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `params` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `own_prefix` tinyint(1) NOT NULL DEFAULT '0',
  `metakey_prefix` varchar(400) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `purchase_type` tinyint(4) NOT NULL DEFAULT '-1',
  `track_clicks` tinyint(4) NOT NULL DEFAULT '-1',
  `track_impressions` tinyint(4) NOT NULL DEFAULT '-1',
  `checked_out` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `reset` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `language` char(7) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `created_by` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `version` int(10) UNSIGNED NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `jm_banner_clients`
--
-- Создание: Мар 30 2018 г., 11:27
--

DROP TABLE IF EXISTS `jm_banner_clients`;
CREATE TABLE `jm_banner_clients` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `contact` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `extrainfo` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `checked_out` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `metakey` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `own_prefix` tinyint(4) NOT NULL DEFAULT '0',
  `metakey_prefix` varchar(400) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `purchase_type` tinyint(4) NOT NULL DEFAULT '-1',
  `track_clicks` tinyint(4) NOT NULL DEFAULT '-1',
  `track_impressions` tinyint(4) NOT NULL DEFAULT '-1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `jm_banner_tracks`
--
-- Создание: Мар 30 2018 г., 11:27
--

DROP TABLE IF EXISTS `jm_banner_tracks`;
CREATE TABLE `jm_banner_tracks` (
  `track_date` datetime NOT NULL,
  `track_type` int(10) UNSIGNED NOT NULL,
  `banner_id` int(10) UNSIGNED NOT NULL,
  `count` int(10) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `jm_categories`
--
-- Создание: Мар 30 2018 г., 11:27
--

DROP TABLE IF EXISTS `jm_categories`;
CREATE TABLE `jm_categories` (
  `id` int(11) NOT NULL,
  `asset_id` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `parent_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `lft` int(11) NOT NULL DEFAULT '0',
  `rgt` int(11) NOT NULL DEFAULT '0',
  `level` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `path` varchar(400) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `extension` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(400) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `note` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `params` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `metadesc` varchar(1024) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'The meta description for the page.',
  `metakey` varchar(1024) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'The meta keywords for the page.',
  `metadata` varchar(2048) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'JSON encoded metadata properties.',
  `created_user_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `created_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_user_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `modified_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `hits` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `language` char(7) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `version` int(10) UNSIGNED NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `jm_categories`
--

INSERT INTO `jm_categories` (`id`, `asset_id`, `parent_id`, `lft`, `rgt`, `level`, `path`, `extension`, `title`, `alias`, `note`, `description`, `published`, `checked_out`, `checked_out_time`, `access`, `params`, `metadesc`, `metakey`, `metadata`, `created_user_id`, `created_time`, `modified_user_id`, `modified_time`, `hits`, `language`, `version`) VALUES
(1, 0, 0, 0, 11, 0, '', 'system', 'ROOT', 'root', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{}', '', '', '{}', 494, '2017-10-19 14:54:23', 0, '0000-00-00 00:00:00', 0, '*', 1),
(2, 27, 1, 1, 2, 1, 'uncategorised', 'com_content', 'Uncategorised', 'uncategorised', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{\"category_layout\":\"\",\"image\":\"\"}', '', '', '{\"author\":\"\",\"robots\":\"\"}', 494, '2017-10-19 14:54:23', 0, '0000-00-00 00:00:00', 0, '*', 1),
(3, 28, 1, 3, 4, 1, 'uncategorised', 'com_banners', 'Uncategorised', 'uncategorised', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{\"category_layout\":\"\",\"image\":\"\"}', '', '', '{\"author\":\"\",\"robots\":\"\"}', 494, '2017-10-19 14:54:23', 0, '0000-00-00 00:00:00', 0, '*', 1),
(4, 29, 1, 5, 6, 1, 'uncategorised', 'com_contact', 'Uncategorised', 'uncategorised', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{\"category_layout\":\"\",\"image\":\"\"}', '', '', '{\"author\":\"\",\"robots\":\"\"}', 494, '2017-10-19 14:54:23', 0, '0000-00-00 00:00:00', 0, '*', 1),
(5, 30, 1, 7, 8, 1, 'uncategorised', 'com_newsfeeds', 'Uncategorised', 'uncategorised', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{\"category_layout\":\"\",\"image\":\"\"}', '', '', '{\"author\":\"\",\"robots\":\"\"}', 494, '2017-10-19 14:54:23', 0, '0000-00-00 00:00:00', 0, '*', 1),
(7, 32, 1, 9, 10, 1, 'uncategorised', 'com_users', 'Uncategorised', 'uncategorised', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{\"category_layout\":\"\",\"image\":\"\"}', '', '', '{\"author\":\"\",\"robots\":\"\"}', 494, '2017-10-19 14:54:23', 0, '0000-00-00 00:00:00', 0, '*', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `jm_contact_details`
--
-- Создание: Мар 30 2018 г., 11:27
--

DROP TABLE IF EXISTS `jm_contact_details`;
CREATE TABLE `jm_contact_details` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(400) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `con_position` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `suburb` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postcode` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telephone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fax` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `misc` mediumtext COLLATE utf8mb4_unicode_ci,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_to` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `default_con` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `params` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `catid` int(11) NOT NULL DEFAULT '0',
  `access` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `mobile` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `webpage` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `sortname1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `sortname2` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `sortname3` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `language` varchar(7) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `metakey` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `metadesc` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `metadata` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `featured` tinyint(3) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'Set if contact is featured.',
  `xreference` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'A reference to enable linkages to external data sets.',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `version` int(10) UNSIGNED NOT NULL DEFAULT '1',
  `hits` int(10) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `jm_content`
--
-- Создание: Мар 30 2018 г., 11:33
-- Последнее обновление: Апр 11 2018 г., 09:27
--

DROP TABLE IF EXISTS `jm_content`;
CREATE TABLE `jm_content` (
  `id` int(10) UNSIGNED NOT NULL,
  `asset_id` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(400) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `introtext` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `fulltext` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `catid` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `checked_out` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `images` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `urls` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `attribs` varchar(5120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `version` int(10) UNSIGNED NOT NULL DEFAULT '1',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `metakey` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `metadesc` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `access` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `hits` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `metadata` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `featured` tinyint(3) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'Set if article is featured.',
  `language` char(7) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The language code for the article.',
  `xreference` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'A reference to enable linkages to external data sets.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `jm_content`
--

INSERT INTO `jm_content` (`id`, `asset_id`, `title`, `alias`, `introtext`, `fulltext`, `state`, `catid`, `created`, `created_by`, `created_by_alias`, `modified`, `modified_by`, `checked_out`, `checked_out_time`, `publish_up`, `publish_down`, `images`, `urls`, `attribs`, `version`, `ordering`, `metakey`, `metadesc`, `access`, `hits`, `metadata`, `featured`, `language`, `xreference`) VALUES
(1, 61, 'Getting Started', 'getting-started', '<p>It\'s easy to get started creating your website. Knowing some of the basics will help.</p><h3>What is a Content Management System?</h3><p>A content management system is software that allows you to create and manage webpages easily by separating the creation of your content from the mechanics required to present it on the web.</p><p>In this site, the content is stored in a <em>database</em>. The look and feel are created by a <em>template</em>. Joomla! brings together the template and your content to create web pages.</p><h3>Logging in</h3><p>To login to your site use the user name and password that were created as part of the installation process. Once logged-in you will be able to create and edit articles and modify some settings.</p><h3>Creating an article</h3><p>Once you are logged-in, a new menu will be visible. To create a new article, click on the \"Submit Article\" link on that menu.</p><p>The new article interface gives you a lot of options, but all you need to do is add a title and put something in the content area. To make it easy to find, set the state to published.</p><div>You can edit an existing article by clicking on the edit icon (this only displays to users who have the right to edit).</div><h3>Template, site settings, and modules</h3><p>The look and feel of your site is controlled by a template. You can change the site name, background colour, highlights colour and more by editing the template settings. Click the \"Template Settings\" in the user menu.</p><p>The boxes around the main content of the site are called modules. You can modify modules on the current page by moving your cursor to the module and clicking the edit link. Always be sure to save and close any module you edit.</p><p>You can change some site settings such as the site name and description by clicking on the \"Site Settings\" link.</p><p>More advanced options for templates, site settings, modules, and more are available in the site administrator.</p><h3>Site and Administrator</h3><p>Your site actually has two separate sites. The site (also called the front end) is what visitors to your site will see. The administrator (also called the back end) is only used by people managing your site. You can access the administrator by clicking the \"Site Administrator\" link on the \"User Menu\" menu (visible once you login) or by adding /administrator to the end of your domain name. The same user name and password are used for both sites.</p><h3>Learn more</h3><p>There is much more to learn about how to use Joomla! to create the website you envision. You can learn much more at the <a href=\"https://docs.joomla.org/\" target=\"_blank\">Joomla! documentation site</a> and on the<a href=\"https://forum.joomla.org/\" target=\"_blank\"> Joomla! forums</a>.</p>', '', 1, 2, '2017-10-19 14:54:23', 494, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2017-10-19 14:54:23', '0000-00-00 00:00:00', '{\"image_intro\":\"\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}', '{\"urla\":false,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":false,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":false,\"urlctext\":\"\",\"targetc\":\"\"}', '{\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}', 1, 0, '', '', 1, 169, '{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}', 0, '*', '');

-- --------------------------------------------------------

--
-- Структура таблицы `jm_contentitem_tag_map`
--
-- Создание: Мар 30 2018 г., 11:27
--

DROP TABLE IF EXISTS `jm_contentitem_tag_map`;
CREATE TABLE `jm_contentitem_tag_map` (
  `type_alias` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `core_content_id` int(10) UNSIGNED NOT NULL COMMENT 'PK from the core content table',
  `content_item_id` int(11) NOT NULL COMMENT 'PK from the content type table',
  `tag_id` int(10) UNSIGNED NOT NULL COMMENT 'PK from the tag table',
  `tag_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Date of most recent save for this tag-item',
  `type_id` mediumint(8) NOT NULL COMMENT 'PK from the content_type table'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Maps items from content tables to tags';

--
-- Дамп данных таблицы `jm_contentitem_tag_map`
--

INSERT INTO `jm_contentitem_tag_map` (`type_alias`, `core_content_id`, `content_item_id`, `tag_id`, `tag_date`, `type_id`) VALUES
('com_content.article', 1, 1, 2, '2017-10-19 14:54:23', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `jm_content_frontpage`
--
-- Создание: Мар 30 2018 г., 11:27
--

DROP TABLE IF EXISTS `jm_content_frontpage`;
CREATE TABLE `jm_content_frontpage` (
  `content_id` int(11) NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `jm_content_rating`
--
-- Создание: Мар 30 2018 г., 11:27
--

DROP TABLE IF EXISTS `jm_content_rating`;
CREATE TABLE `jm_content_rating` (
  `content_id` int(11) NOT NULL DEFAULT '0',
  `rating_sum` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `rating_count` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `lastip` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `jm_content_types`
--
-- Создание: Мар 30 2018 г., 11:27
--

DROP TABLE IF EXISTS `jm_content_types`;
CREATE TABLE `jm_content_types` (
  `type_id` int(10) UNSIGNED NOT NULL,
  `type_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `type_alias` varchar(400) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `table` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `rules` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `field_mappings` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `router` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `content_history_options` varchar(5120) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'JSON string for com_contenthistory options'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `jm_content_types`
--

INSERT INTO `jm_content_types` (`type_id`, `type_title`, `type_alias`, `table`, `rules`, `field_mappings`, `router`, `content_history_options`) VALUES
(1, 'Article', 'com_content.article', '{\"special\":{\"dbtable\":\"#__content\",\"key\":\"id\",\"type\":\"Content\",\"prefix\":\"JTable\",\"config\":\"array()\"},\"common\":{\"dbtable\":\"#__ucm_content\",\"key\":\"ucm_id\",\"type\":\"Corecontent\",\"prefix\":\"JTable\",\"config\":\"array()\"}}', '', '{\"common\":{\"core_content_item_id\":\"id\",\"core_title\":\"title\",\"core_state\":\"state\",\"core_alias\":\"alias\",\"core_created_time\":\"created\",\"core_modified_time\":\"modified\",\"core_body\":\"introtext\", \"core_hits\":\"hits\",\"core_publish_up\":\"publish_up\",\"core_publish_down\":\"publish_down\",\"core_access\":\"access\", \"core_params\":\"attribs\", \"core_featured\":\"featured\", \"core_metadata\":\"metadata\", \"core_language\":\"language\", \"core_images\":\"images\", \"core_urls\":\"urls\", \"core_version\":\"version\", \"core_ordering\":\"ordering\", \"core_metakey\":\"metakey\", \"core_metadesc\":\"metadesc\", \"core_catid\":\"catid\", \"core_xreference\":\"xreference\", \"asset_id\":\"asset_id\"}, \"special\":{\"fulltext\":\"fulltext\"}}', 'ContentHelperRoute::getArticleRoute', '{\"formFile\":\"administrator\\/components\\/com_content\\/models\\/forms\\/article.xml\", \"hideFields\":[\"asset_id\",\"checked_out\",\"checked_out_time\",\"version\"],\"ignoreChanges\":[\"modified_by\", \"modified\", \"checked_out\", \"checked_out_time\", \"version\", \"hits\"],\"convertToInt\":[\"publish_up\", \"publish_down\", \"featured\", \"ordering\"],\"displayLookup\":[{\"sourceColumn\":\"catid\",\"targetTable\":\"#__categories\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"},{\"sourceColumn\":\"created_by\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"},{\"sourceColumn\":\"access\",\"targetTable\":\"#__viewlevels\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"},{\"sourceColumn\":\"modified_by\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"} ]}'),
(2, 'Contact', 'com_contact.contact', '{\"special\":{\"dbtable\":\"#__contact_details\",\"key\":\"id\",\"type\":\"Contact\",\"prefix\":\"ContactTable\",\"config\":\"array()\"},\"common\":{\"dbtable\":\"#__ucm_content\",\"key\":\"ucm_id\",\"type\":\"Corecontent\",\"prefix\":\"JTable\",\"config\":\"array()\"}}', '', '{\"common\":{\"core_content_item_id\":\"id\",\"core_title\":\"name\",\"core_state\":\"published\",\"core_alias\":\"alias\",\"core_created_time\":\"created\",\"core_modified_time\":\"modified\",\"core_body\":\"address\", \"core_hits\":\"hits\",\"core_publish_up\":\"publish_up\",\"core_publish_down\":\"publish_down\",\"core_access\":\"access\", \"core_params\":\"params\", \"core_featured\":\"featured\", \"core_metadata\":\"metadata\", \"core_language\":\"language\", \"core_images\":\"image\", \"core_urls\":\"webpage\", \"core_version\":\"version\", \"core_ordering\":\"ordering\", \"core_metakey\":\"metakey\", \"core_metadesc\":\"metadesc\", \"core_catid\":\"catid\", \"core_xreference\":\"xreference\", \"asset_id\":\"null\"}, \"special\":{\"con_position\":\"con_position\",\"suburb\":\"suburb\",\"state\":\"state\",\"country\":\"country\",\"postcode\":\"postcode\",\"telephone\":\"telephone\",\"fax\":\"fax\",\"misc\":\"misc\",\"email_to\":\"email_to\",\"default_con\":\"default_con\",\"user_id\":\"user_id\",\"mobile\":\"mobile\",\"sortname1\":\"sortname1\",\"sortname2\":\"sortname2\",\"sortname3\":\"sortname3\"}}', 'ContactHelperRoute::getContactRoute', '{\"formFile\":\"administrator\\/components\\/com_contact\\/models\\/forms\\/contact.xml\",\"hideFields\":[\"default_con\",\"checked_out\",\"checked_out_time\",\"version\",\"xreference\"],\"ignoreChanges\":[\"modified_by\", \"modified\", \"checked_out\", \"checked_out_time\", \"version\", \"hits\"],\"convertToInt\":[\"publish_up\", \"publish_down\", \"featured\", \"ordering\"], \"displayLookup\":[ {\"sourceColumn\":\"created_by\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"},{\"sourceColumn\":\"catid\",\"targetTable\":\"#__categories\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"},{\"sourceColumn\":\"modified_by\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"},{\"sourceColumn\":\"access\",\"targetTable\":\"#__viewlevels\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"},{\"sourceColumn\":\"user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"} ] }'),
(3, 'Newsfeed', 'com_newsfeeds.newsfeed', '{\"special\":{\"dbtable\":\"#__newsfeeds\",\"key\":\"id\",\"type\":\"Newsfeed\",\"prefix\":\"NewsfeedsTable\",\"config\":\"array()\"},\"common\":{\"dbtable\":\"#__ucm_content\",\"key\":\"ucm_id\",\"type\":\"Corecontent\",\"prefix\":\"JTable\",\"config\":\"array()\"}}', '', '{\"common\":{\"core_content_item_id\":\"id\",\"core_title\":\"name\",\"core_state\":\"published\",\"core_alias\":\"alias\",\"core_created_time\":\"created\",\"core_modified_time\":\"modified\",\"core_body\":\"description\", \"core_hits\":\"hits\",\"core_publish_up\":\"publish_up\",\"core_publish_down\":\"publish_down\",\"core_access\":\"access\", \"core_params\":\"params\", \"core_featured\":\"featured\", \"core_metadata\":\"metadata\", \"core_language\":\"language\", \"core_images\":\"images\", \"core_urls\":\"link\", \"core_version\":\"version\", \"core_ordering\":\"ordering\", \"core_metakey\":\"metakey\", \"core_metadesc\":\"metadesc\", \"core_catid\":\"catid\", \"core_xreference\":\"xreference\", \"asset_id\":\"null\"}, \"special\":{\"numarticles\":\"numarticles\",\"cache_time\":\"cache_time\",\"rtl\":\"rtl\"}}', 'NewsfeedsHelperRoute::getNewsfeedRoute', '{\"formFile\":\"administrator\\/components\\/com_newsfeeds\\/models\\/forms\\/newsfeed.xml\",\"hideFields\":[\"asset_id\",\"checked_out\",\"checked_out_time\",\"version\"],\"ignoreChanges\":[\"modified_by\", \"modified\", \"checked_out\", \"checked_out_time\", \"version\", \"hits\"],\"convertToInt\":[\"publish_up\", \"publish_down\", \"featured\", \"ordering\"],\"displayLookup\":[{\"sourceColumn\":\"catid\",\"targetTable\":\"#__categories\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"},{\"sourceColumn\":\"created_by\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"},{\"sourceColumn\":\"access\",\"targetTable\":\"#__viewlevels\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"},{\"sourceColumn\":\"modified_by\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"} ]}'),
(4, 'User', 'com_users.user', '{\"special\":{\"dbtable\":\"#__users\",\"key\":\"id\",\"type\":\"User\",\"prefix\":\"JTable\",\"config\":\"array()\"},\"common\":{\"dbtable\":\"#__ucm_content\",\"key\":\"ucm_id\",\"type\":\"Corecontent\",\"prefix\":\"JTable\",\"config\":\"array()\"}}', '', '{\"common\":{\"core_content_item_id\":\"id\",\"core_title\":\"name\",\"core_state\":\"null\",\"core_alias\":\"username\",\"core_created_time\":\"registerdate\",\"core_modified_time\":\"lastvisitDate\",\"core_body\":\"null\", \"core_hits\":\"null\",\"core_publish_up\":\"null\",\"core_publish_down\":\"null\",\"access\":\"null\", \"core_params\":\"params\", \"core_featured\":\"null\", \"core_metadata\":\"null\", \"core_language\":\"null\", \"core_images\":\"null\", \"core_urls\":\"null\", \"core_version\":\"null\", \"core_ordering\":\"null\", \"core_metakey\":\"null\", \"core_metadesc\":\"null\", \"core_catid\":\"null\", \"core_xreference\":\"null\", \"asset_id\":\"null\"}, \"special\":{}}', 'UsersHelperRoute::getUserRoute', ''),
(5, 'Article Category', 'com_content.category', '{\"special\":{\"dbtable\":\"#__categories\",\"key\":\"id\",\"type\":\"Category\",\"prefix\":\"JTable\",\"config\":\"array()\"},\"common\":{\"dbtable\":\"#__ucm_content\",\"key\":\"ucm_id\",\"type\":\"Corecontent\",\"prefix\":\"JTable\",\"config\":\"array()\"}}', '', '{\"common\":{\"core_content_item_id\":\"id\",\"core_title\":\"title\",\"core_state\":\"published\",\"core_alias\":\"alias\",\"core_created_time\":\"created_time\",\"core_modified_time\":\"modified_time\",\"core_body\":\"description\", \"core_hits\":\"hits\",\"core_publish_up\":\"null\",\"core_publish_down\":\"null\",\"core_access\":\"access\", \"core_params\":\"params\", \"core_featured\":\"null\", \"core_metadata\":\"metadata\", \"core_language\":\"language\", \"core_images\":\"null\", \"core_urls\":\"null\", \"core_version\":\"version\", \"core_ordering\":\"null\", \"core_metakey\":\"metakey\", \"core_metadesc\":\"metadesc\", \"core_catid\":\"parent_id\", \"core_xreference\":\"null\", \"asset_id\":\"asset_id\"}, \"special\":{\"parent_id\":\"parent_id\",\"lft\":\"lft\",\"rgt\":\"rgt\",\"level\":\"level\",\"path\":\"path\",\"extension\":\"extension\",\"note\":\"note\"}}', 'ContentHelperRoute::getCategoryRoute', '{\"formFile\":\"administrator\\/components\\/com_categories\\/models\\/forms\\/category.xml\", \"hideFields\":[\"asset_id\",\"checked_out\",\"checked_out_time\",\"version\",\"lft\",\"rgt\",\"level\",\"path\",\"extension\"], \"ignoreChanges\":[\"modified_user_id\", \"modified_time\", \"checked_out\", \"checked_out_time\", \"version\", \"hits\", \"path\"],\"convertToInt\":[\"publish_up\", \"publish_down\"], \"displayLookup\":[{\"sourceColumn\":\"created_user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"},{\"sourceColumn\":\"access\",\"targetTable\":\"#__viewlevels\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"},{\"sourceColumn\":\"modified_user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"},{\"sourceColumn\":\"parent_id\",\"targetTable\":\"#__categories\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"}]}'),
(6, 'Contact Category', 'com_contact.category', '{\"special\":{\"dbtable\":\"#__categories\",\"key\":\"id\",\"type\":\"Category\",\"prefix\":\"JTable\",\"config\":\"array()\"},\"common\":{\"dbtable\":\"#__ucm_content\",\"key\":\"ucm_id\",\"type\":\"Corecontent\",\"prefix\":\"JTable\",\"config\":\"array()\"}}', '', '{\"common\":{\"core_content_item_id\":\"id\",\"core_title\":\"title\",\"core_state\":\"published\",\"core_alias\":\"alias\",\"core_created_time\":\"created_time\",\"core_modified_time\":\"modified_time\",\"core_body\":\"description\", \"core_hits\":\"hits\",\"core_publish_up\":\"null\",\"core_publish_down\":\"null\",\"core_access\":\"access\", \"core_params\":\"params\", \"core_featured\":\"null\", \"core_metadata\":\"metadata\", \"core_language\":\"language\", \"core_images\":\"null\", \"core_urls\":\"null\", \"core_version\":\"version\", \"core_ordering\":\"null\", \"core_metakey\":\"metakey\", \"core_metadesc\":\"metadesc\", \"core_catid\":\"parent_id\", \"core_xreference\":\"null\", \"asset_id\":\"asset_id\"}, \"special\":{\"parent_id\":\"parent_id\",\"lft\":\"lft\",\"rgt\":\"rgt\",\"level\":\"level\",\"path\":\"path\",\"extension\":\"extension\",\"note\":\"note\"}}', 'ContactHelperRoute::getCategoryRoute', '{\"formFile\":\"administrator\\/components\\/com_categories\\/models\\/forms\\/category.xml\", \"hideFields\":[\"asset_id\",\"checked_out\",\"checked_out_time\",\"version\",\"lft\",\"rgt\",\"level\",\"path\",\"extension\"], \"ignoreChanges\":[\"modified_user_id\", \"modified_time\", \"checked_out\", \"checked_out_time\", \"version\", \"hits\", \"path\"],\"convertToInt\":[\"publish_up\", \"publish_down\"], \"displayLookup\":[{\"sourceColumn\":\"created_user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"},{\"sourceColumn\":\"access\",\"targetTable\":\"#__viewlevels\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"},{\"sourceColumn\":\"modified_user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"},{\"sourceColumn\":\"parent_id\",\"targetTable\":\"#__categories\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"}]}'),
(7, 'Newsfeeds Category', 'com_newsfeeds.category', '{\"special\":{\"dbtable\":\"#__categories\",\"key\":\"id\",\"type\":\"Category\",\"prefix\":\"JTable\",\"config\":\"array()\"},\"common\":{\"dbtable\":\"#__ucm_content\",\"key\":\"ucm_id\",\"type\":\"Corecontent\",\"prefix\":\"JTable\",\"config\":\"array()\"}}', '', '{\"common\":{\"core_content_item_id\":\"id\",\"core_title\":\"title\",\"core_state\":\"published\",\"core_alias\":\"alias\",\"core_created_time\":\"created_time\",\"core_modified_time\":\"modified_time\",\"core_body\":\"description\", \"core_hits\":\"hits\",\"core_publish_up\":\"null\",\"core_publish_down\":\"null\",\"core_access\":\"access\", \"core_params\":\"params\", \"core_featured\":\"null\", \"core_metadata\":\"metadata\", \"core_language\":\"language\", \"core_images\":\"null\", \"core_urls\":\"null\", \"core_version\":\"version\", \"core_ordering\":\"null\", \"core_metakey\":\"metakey\", \"core_metadesc\":\"metadesc\", \"core_catid\":\"parent_id\", \"core_xreference\":\"null\", \"asset_id\":\"asset_id\"}, \"special\":{\"parent_id\":\"parent_id\",\"lft\":\"lft\",\"rgt\":\"rgt\",\"level\":\"level\",\"path\":\"path\",\"extension\":\"extension\",\"note\":\"note\"}}', 'NewsfeedsHelperRoute::getCategoryRoute', '{\"formFile\":\"administrator\\/components\\/com_categories\\/models\\/forms\\/category.xml\", \"hideFields\":[\"asset_id\",\"checked_out\",\"checked_out_time\",\"version\",\"lft\",\"rgt\",\"level\",\"path\",\"extension\"], \"ignoreChanges\":[\"modified_user_id\", \"modified_time\", \"checked_out\", \"checked_out_time\", \"version\", \"hits\", \"path\"],\"convertToInt\":[\"publish_up\", \"publish_down\"], \"displayLookup\":[{\"sourceColumn\":\"created_user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"},{\"sourceColumn\":\"access\",\"targetTable\":\"#__viewlevels\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"},{\"sourceColumn\":\"modified_user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"},{\"sourceColumn\":\"parent_id\",\"targetTable\":\"#__categories\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"}]}'),
(8, 'Tag', 'com_tags.tag', '{\"special\":{\"dbtable\":\"#__tags\",\"key\":\"tag_id\",\"type\":\"Tag\",\"prefix\":\"TagsTable\",\"config\":\"array()\"},\"common\":{\"dbtable\":\"#__ucm_content\",\"key\":\"ucm_id\",\"type\":\"Corecontent\",\"prefix\":\"JTable\",\"config\":\"array()\"}}', '', '{\"common\":{\"core_content_item_id\":\"id\",\"core_title\":\"title\",\"core_state\":\"published\",\"core_alias\":\"alias\",\"core_created_time\":\"created_time\",\"core_modified_time\":\"modified_time\",\"core_body\":\"description\", \"core_hits\":\"hits\",\"core_publish_up\":\"null\",\"core_publish_down\":\"null\",\"core_access\":\"access\", \"core_params\":\"params\", \"core_featured\":\"featured\", \"core_metadata\":\"metadata\", \"core_language\":\"language\", \"core_images\":\"images\", \"core_urls\":\"urls\", \"core_version\":\"version\", \"core_ordering\":\"null\", \"core_metakey\":\"metakey\", \"core_metadesc\":\"metadesc\", \"core_catid\":\"null\", \"core_xreference\":\"null\", \"asset_id\":\"null\"}, \"special\":{\"parent_id\":\"parent_id\",\"lft\":\"lft\",\"rgt\":\"rgt\",\"level\":\"level\",\"path\":\"path\"}}', 'TagsHelperRoute::getTagRoute', '{\"formFile\":\"administrator\\/components\\/com_tags\\/models\\/forms\\/tag.xml\", \"hideFields\":[\"checked_out\",\"checked_out_time\",\"version\", \"lft\", \"rgt\", \"level\", \"path\", \"urls\", \"publish_up\", \"publish_down\"],\"ignoreChanges\":[\"modified_user_id\", \"modified_time\", \"checked_out\", \"checked_out_time\", \"version\", \"hits\", \"path\"],\"convertToInt\":[\"publish_up\", \"publish_down\"], \"displayLookup\":[{\"sourceColumn\":\"created_user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"}, {\"sourceColumn\":\"access\",\"targetTable\":\"#__viewlevels\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"}, {\"sourceColumn\":\"modified_user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"}]}'),
(9, 'Banner', 'com_banners.banner', '{\"special\":{\"dbtable\":\"#__banners\",\"key\":\"id\",\"type\":\"Banner\",\"prefix\":\"BannersTable\",\"config\":\"array()\"},\"common\":{\"dbtable\":\"#__ucm_content\",\"key\":\"ucm_id\",\"type\":\"Corecontent\",\"prefix\":\"JTable\",\"config\":\"array()\"}}', '', '{\"common\":{\"core_content_item_id\":\"id\",\"core_title\":\"name\",\"core_state\":\"published\",\"core_alias\":\"alias\",\"core_created_time\":\"created\",\"core_modified_time\":\"modified\",\"core_body\":\"description\", \"core_hits\":\"null\",\"core_publish_up\":\"publish_up\",\"core_publish_down\":\"publish_down\",\"core_access\":\"access\", \"core_params\":\"params\", \"core_featured\":\"null\", \"core_metadata\":\"metadata\", \"core_language\":\"language\", \"core_images\":\"images\", \"core_urls\":\"link\", \"core_version\":\"version\", \"core_ordering\":\"ordering\", \"core_metakey\":\"metakey\", \"core_metadesc\":\"metadesc\", \"core_catid\":\"catid\", \"core_xreference\":\"null\", \"asset_id\":\"null\"}, \"special\":{\"imptotal\":\"imptotal\", \"impmade\":\"impmade\", \"clicks\":\"clicks\", \"clickurl\":\"clickurl\", \"custombannercode\":\"custombannercode\", \"cid\":\"cid\", \"purchase_type\":\"purchase_type\", \"track_impressions\":\"track_impressions\", \"track_clicks\":\"track_clicks\"}}', '', '{\"formFile\":\"administrator\\/components\\/com_banners\\/models\\/forms\\/banner.xml\", \"hideFields\":[\"checked_out\",\"checked_out_time\",\"version\", \"reset\"],\"ignoreChanges\":[\"modified_by\", \"modified\", \"checked_out\", \"checked_out_time\", \"version\", \"imptotal\", \"impmade\", \"reset\"], \"convertToInt\":[\"publish_up\", \"publish_down\", \"ordering\"], \"displayLookup\":[{\"sourceColumn\":\"catid\",\"targetTable\":\"#__categories\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"}, {\"sourceColumn\":\"cid\",\"targetTable\":\"#__banner_clients\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"}, {\"sourceColumn\":\"created_by\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"},{\"sourceColumn\":\"modified_by\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"} ]}'),
(10, 'Banners Category', 'com_banners.category', '{\"special\":{\"dbtable\":\"#__categories\",\"key\":\"id\",\"type\":\"Category\",\"prefix\":\"JTable\",\"config\":\"array()\"},\"common\":{\"dbtable\":\"#__ucm_content\",\"key\":\"ucm_id\",\"type\":\"Corecontent\",\"prefix\":\"JTable\",\"config\":\"array()\"}}', '', '{\"common\":{\"core_content_item_id\":\"id\",\"core_title\":\"title\",\"core_state\":\"published\",\"core_alias\":\"alias\",\"core_created_time\":\"created_time\",\"core_modified_time\":\"modified_time\",\"core_body\":\"description\", \"core_hits\":\"hits\",\"core_publish_up\":\"null\",\"core_publish_down\":\"null\",\"core_access\":\"access\", \"core_params\":\"params\", \"core_featured\":\"null\", \"core_metadata\":\"metadata\", \"core_language\":\"language\", \"core_images\":\"null\", \"core_urls\":\"null\", \"core_version\":\"version\", \"core_ordering\":\"null\", \"core_metakey\":\"metakey\", \"core_metadesc\":\"metadesc\", \"core_catid\":\"parent_id\", \"core_xreference\":\"null\", \"asset_id\":\"asset_id\"}, \"special\": {\"parent_id\":\"parent_id\",\"lft\":\"lft\",\"rgt\":\"rgt\",\"level\":\"level\",\"path\":\"path\",\"extension\":\"extension\",\"note\":\"note\"}}', '', '{\"formFile\":\"administrator\\/components\\/com_categories\\/models\\/forms\\/category.xml\", \"hideFields\":[\"asset_id\",\"checked_out\",\"checked_out_time\",\"version\",\"lft\",\"rgt\",\"level\",\"path\",\"extension\"], \"ignoreChanges\":[\"modified_user_id\", \"modified_time\", \"checked_out\", \"checked_out_time\", \"version\", \"hits\", \"path\"], \"convertToInt\":[\"publish_up\", \"publish_down\"], \"displayLookup\":[{\"sourceColumn\":\"created_user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"},{\"sourceColumn\":\"access\",\"targetTable\":\"#__viewlevels\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"},{\"sourceColumn\":\"modified_user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"},{\"sourceColumn\":\"parent_id\",\"targetTable\":\"#__categories\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"}]}'),
(11, 'Banner Client', 'com_banners.client', '{\"special\":{\"dbtable\":\"#__banner_clients\",\"key\":\"id\",\"type\":\"Client\",\"prefix\":\"BannersTable\"}}', '', '', '', '{\"formFile\":\"administrator\\/components\\/com_banners\\/models\\/forms\\/client.xml\", \"hideFields\":[\"checked_out\",\"checked_out_time\"], \"ignoreChanges\":[\"checked_out\", \"checked_out_time\"], \"convertToInt\":[], \"displayLookup\":[]}'),
(12, 'User Notes', 'com_users.note', '{\"special\":{\"dbtable\":\"#__user_notes\",\"key\":\"id\",\"type\":\"Note\",\"prefix\":\"UsersTable\"}}', '', '', '', '{\"formFile\":\"administrator\\/components\\/com_users\\/models\\/forms\\/note.xml\", \"hideFields\":[\"checked_out\",\"checked_out_time\", \"publish_up\", \"publish_down\"],\"ignoreChanges\":[\"modified_user_id\", \"modified_time\", \"checked_out\", \"checked_out_time\"], \"convertToInt\":[\"publish_up\", \"publish_down\"],\"displayLookup\":[{\"sourceColumn\":\"catid\",\"targetTable\":\"#__categories\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"}, {\"sourceColumn\":\"created_user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"}, {\"sourceColumn\":\"user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"}, {\"sourceColumn\":\"modified_user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"}]}'),
(13, 'User Notes Category', 'com_users.category', '{\"special\":{\"dbtable\":\"#__categories\",\"key\":\"id\",\"type\":\"Category\",\"prefix\":\"JTable\",\"config\":\"array()\"},\"common\":{\"dbtable\":\"#__ucm_content\",\"key\":\"ucm_id\",\"type\":\"Corecontent\",\"prefix\":\"JTable\",\"config\":\"array()\"}}', '', '{\"common\":{\"core_content_item_id\":\"id\",\"core_title\":\"title\",\"core_state\":\"published\",\"core_alias\":\"alias\",\"core_created_time\":\"created_time\",\"core_modified_time\":\"modified_time\",\"core_body\":\"description\", \"core_hits\":\"hits\",\"core_publish_up\":\"null\",\"core_publish_down\":\"null\",\"core_access\":\"access\", \"core_params\":\"params\", \"core_featured\":\"null\", \"core_metadata\":\"metadata\", \"core_language\":\"language\", \"core_images\":\"null\", \"core_urls\":\"null\", \"core_version\":\"version\", \"core_ordering\":\"null\", \"core_metakey\":\"metakey\", \"core_metadesc\":\"metadesc\", \"core_catid\":\"parent_id\", \"core_xreference\":\"null\", \"asset_id\":\"asset_id\"}, \"special\":{\"parent_id\":\"parent_id\",\"lft\":\"lft\",\"rgt\":\"rgt\",\"level\":\"level\",\"path\":\"path\",\"extension\":\"extension\",\"note\":\"note\"}}', '', '{\"formFile\":\"administrator\\/components\\/com_categories\\/models\\/forms\\/category.xml\", \"hideFields\":[\"checked_out\",\"checked_out_time\",\"version\",\"lft\",\"rgt\",\"level\",\"path\",\"extension\"], \"ignoreChanges\":[\"modified_user_id\", \"modified_time\", \"checked_out\", \"checked_out_time\", \"version\", \"hits\", \"path\"], \"convertToInt\":[\"publish_up\", \"publish_down\"], \"displayLookup\":[{\"sourceColumn\":\"created_user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"}, {\"sourceColumn\":\"access\",\"targetTable\":\"#__viewlevels\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"},{\"sourceColumn\":\"modified_user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"},{\"sourceColumn\":\"parent_id\",\"targetTable\":\"#__categories\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"}]}');

-- --------------------------------------------------------

--
-- Структура таблицы `jm_core_log_searches`
--
-- Создание: Мар 30 2018 г., 11:27
--

DROP TABLE IF EXISTS `jm_core_log_searches`;
CREATE TABLE `jm_core_log_searches` (
  `search_term` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `hits` int(10) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `jm_extensions`
--
-- Создание: Мар 30 2018 г., 11:27
-- Последнее обновление: Апр 11 2018 г., 08:14
--

DROP TABLE IF EXISTS `jm_extensions`;
CREATE TABLE `jm_extensions` (
  `extension_id` int(11) NOT NULL,
  `package_id` int(11) NOT NULL DEFAULT '0' COMMENT 'Parent package ID for extensions installed as a package.',
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `element` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `folder` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `client_id` tinyint(3) NOT NULL,
  `enabled` tinyint(3) NOT NULL DEFAULT '0',
  `access` int(10) UNSIGNED NOT NULL DEFAULT '1',
  `protected` tinyint(3) NOT NULL DEFAULT '0',
  `manifest_cache` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `params` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `custom_data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `system_data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `checked_out` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) DEFAULT '0',
  `state` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `jm_extensions`
--

INSERT INTO `jm_extensions` (`extension_id`, `package_id`, `name`, `type`, `element`, `folder`, `client_id`, `enabled`, `access`, `protected`, `manifest_cache`, `params`, `custom_data`, `system_data`, `checked_out`, `checked_out_time`, `ordering`, `state`) VALUES
(1, 0, 'com_mailto', 'component', 'com_mailto', '', 0, 1, 1, 1, '{\"name\":\"com_mailto\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2018 Open Source Matters. All rights reserved.\\t\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_MAILTO_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mailto\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(2, 0, 'com_wrapper', 'component', 'com_wrapper', '', 0, 1, 1, 1, '{\"name\":\"com_wrapper\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2018 Open Source Matters. All rights reserved.\\n\\t\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_WRAPPER_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"wrapper\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(3, 0, 'com_admin', 'component', 'com_admin', '', 1, 1, 1, 1, '{\"name\":\"com_admin\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_ADMIN_XML_DESCRIPTION\",\"group\":\"\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(4, 0, 'com_banners', 'component', 'com_banners', '', 1, 1, 1, 0, '{\"name\":\"com_banners\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_BANNERS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"banners\"}', '{\"purchase_type\":\"3\",\"track_impressions\":\"0\",\"track_clicks\":\"0\",\"metakey_prefix\":\"\",\"save_history\":\"1\",\"history_limit\":10}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(5, 0, 'com_cache', 'component', 'com_cache', '', 1, 1, 1, 1, '{\"name\":\"com_cache\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_CACHE_XML_DESCRIPTION\",\"group\":\"\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(6, 0, 'com_categories', 'component', 'com_categories', '', 1, 1, 1, 1, '{\"name\":\"com_categories\",\"type\":\"component\",\"creationDate\":\"December 2007\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_CATEGORIES_XML_DESCRIPTION\",\"group\":\"\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(7, 0, 'com_checkin', 'component', 'com_checkin', '', 1, 1, 1, 1, '{\"name\":\"com_checkin\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_CHECKIN_XML_DESCRIPTION\",\"group\":\"\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(8, 0, 'com_contact', 'component', 'com_contact', '', 1, 1, 1, 0, '{\"name\":\"com_contact\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_CONTACT_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"contact\"}', '{\"contact_layout\":\"_:default\",\"show_contact_category\":\"hide\",\"save_history\":\"1\",\"history_limit\":10,\"show_contact_list\":\"0\",\"presentation_style\":\"sliders\",\"show_tags\":\"1\",\"show_info\":\"1\",\"show_name\":\"1\",\"show_position\":\"1\",\"show_email\":\"0\",\"show_street_address\":\"1\",\"show_suburb\":\"1\",\"show_state\":\"1\",\"show_postcode\":\"1\",\"show_country\":\"1\",\"show_telephone\":\"1\",\"show_mobile\":\"1\",\"show_fax\":\"1\",\"show_webpage\":\"1\",\"show_image\":\"1\",\"show_misc\":\"1\",\"image\":\"\",\"allow_vcard\":\"0\",\"show_articles\":\"0\",\"articles_display_num\":\"10\",\"show_profile\":\"0\",\"show_user_custom_fields\":[\"-1\"],\"show_links\":\"0\",\"linka_name\":\"\",\"linkb_name\":\"\",\"linkc_name\":\"\",\"linkd_name\":\"\",\"linke_name\":\"\",\"contact_icons\":\"0\",\"icon_address\":\"\",\"icon_email\":\"\",\"icon_telephone\":\"\",\"icon_mobile\":\"\",\"icon_fax\":\"\",\"icon_misc\":\"\",\"category_layout\":\"_:default\",\"show_category_title\":\"1\",\"show_description\":\"1\",\"show_description_image\":\"0\",\"maxLevel\":\"-1\",\"show_subcat_desc\":\"1\",\"show_empty_categories\":\"0\",\"show_cat_items\":\"1\",\"show_cat_tags\":\"1\",\"show_base_description\":\"1\",\"maxLevelcat\":\"-1\",\"show_subcat_desc_cat\":\"1\",\"show_empty_categories_cat\":\"0\",\"show_cat_items_cat\":\"1\",\"filter_field\":\"0\",\"show_pagination_limit\":\"0\",\"show_headings\":\"1\",\"show_image_heading\":\"0\",\"show_position_headings\":\"1\",\"show_email_headings\":\"0\",\"show_telephone_headings\":\"1\",\"show_mobile_headings\":\"0\",\"show_fax_headings\":\"0\",\"show_suburb_headings\":\"1\",\"show_state_headings\":\"1\",\"show_country_headings\":\"1\",\"show_pagination\":\"2\",\"show_pagination_results\":\"1\",\"initial_sort\":\"ordering\",\"captcha\":\"\",\"show_email_form\":\"1\",\"show_email_copy\":\"0\",\"banned_email\":\"\",\"banned_subject\":\"\",\"banned_text\":\"\",\"validate_session\":\"1\",\"custom_reply\":\"0\",\"redirect\":\"\",\"show_feed_link\":\"1\",\"sef_advanced\":0,\"sef_ids\":0,\"custom_fields_enable\":\"1\"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(9, 0, 'com_cpanel', 'component', 'com_cpanel', '', 1, 1, 1, 1, '{\"name\":\"com_cpanel\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_CPANEL_XML_DESCRIPTION\",\"group\":\"\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10, 0, 'com_installer', 'component', 'com_installer', '', 1, 1, 1, 1, '{\"name\":\"com_installer\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_INSTALLER_XML_DESCRIPTION\",\"group\":\"\"}', '{\"show_jed_info\":\"1\",\"cachetimeout\":\"6\",\"minimum_stability\":\"4\"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(11, 0, 'com_languages', 'component', 'com_languages', '', 1, 1, 1, 1, '{\"name\":\"com_languages\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_LANGUAGES_XML_DESCRIPTION\",\"group\":\"\"}', '{\"administrator\":\"ru-RU\",\"site\":\"ru-RU\"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(12, 0, 'com_login', 'component', 'com_login', '', 1, 1, 1, 1, '{\"name\":\"com_login\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_LOGIN_XML_DESCRIPTION\",\"group\":\"\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(13, 0, 'com_media', 'component', 'com_media', '', 1, 1, 0, 1, '{\"name\":\"com_media\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_MEDIA_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"media\"}', '{\"upload_extensions\":\"bmp,csv,doc,gif,ico,jpg,jpeg,odg,odp,ods,odt,pdf,png,ppt,txt,xcf,xls,BMP,CSV,DOC,GIF,ICO,JPG,JPEG,ODG,ODP,ODS,ODT,PDF,PNG,PPT,TXT,XCF,XLS\",\"upload_maxsize\":\"10\",\"file_path\":\"images\",\"image_path\":\"images\",\"restrict_uploads\":\"1\",\"allowed_media_usergroup\":\"3\",\"check_mime\":\"1\",\"image_extensions\":\"bmp,gif,jpg,png\",\"ignore_extensions\":\"\",\"upload_mime\":\"image\\/jpeg,image\\/gif,image\\/png,image\\/bmp,application\\/msword,application\\/excel,application\\/pdf,application\\/powerpoint,text\\/plain,application\\/x-zip\",\"upload_mime_illegal\":\"text\\/html\"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(14, 0, 'com_menus', 'component', 'com_menus', '', 1, 1, 1, 1, '{\"name\":\"com_menus\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_MENUS_XML_DESCRIPTION\",\"group\":\"\"}', '{\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(15, 0, 'com_messages', 'component', 'com_messages', '', 1, 1, 1, 1, '{\"name\":\"com_messages\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_MESSAGES_XML_DESCRIPTION\",\"group\":\"\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(16, 0, 'com_modules', 'component', 'com_modules', '', 1, 1, 1, 1, '{\"name\":\"com_modules\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_MODULES_XML_DESCRIPTION\",\"group\":\"\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(17, 0, 'com_newsfeeds', 'component', 'com_newsfeeds', '', 1, 1, 1, 0, '{\"name\":\"com_newsfeeds\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_NEWSFEEDS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"newsfeeds\"}', '{\"newsfeed_layout\":\"_:default\",\"save_history\":\"1\",\"history_limit\":5,\"show_feed_image\":\"1\",\"show_feed_description\":\"1\",\"show_item_description\":\"1\",\"feed_character_count\":\"0\",\"feed_display_order\":\"des\",\"float_first\":\"right\",\"float_second\":\"right\",\"show_tags\":\"1\",\"category_layout\":\"_:default\",\"show_category_title\":\"1\",\"show_description\":\"1\",\"show_description_image\":\"1\",\"maxLevel\":\"-1\",\"show_empty_categories\":\"0\",\"show_subcat_desc\":\"1\",\"show_cat_items\":\"1\",\"show_cat_tags\":\"1\",\"show_base_description\":\"1\",\"maxLevelcat\":\"-1\",\"show_empty_categories_cat\":\"0\",\"show_subcat_desc_cat\":\"1\",\"show_cat_items_cat\":\"1\",\"filter_field\":\"1\",\"show_pagination_limit\":\"1\",\"show_headings\":\"1\",\"show_articles\":\"0\",\"show_link\":\"1\",\"show_pagination\":\"1\",\"show_pagination_results\":\"1\"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(18, 0, 'com_plugins', 'component', 'com_plugins', '', 1, 1, 1, 1, '{\"name\":\"com_plugins\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_PLUGINS_XML_DESCRIPTION\",\"group\":\"\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(19, 0, 'com_search', 'component', 'com_search', '', 1, 1, 1, 0, '{\"name\":\"com_search\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_SEARCH_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"search\"}', '{\"enabled\":\"0\",\"search_phrases\":\"1\",\"search_areas\":\"1\",\"show_date\":\"1\",\"opensearch_name\":\"\",\"opensearch_description\":\"\"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(20, 0, 'com_templates', 'component', 'com_templates', '', 1, 1, 1, 1, '{\"name\":\"com_templates\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_TEMPLATES_XML_DESCRIPTION\",\"group\":\"\"}', '{\"template_positions_display\":\"1\",\"upload_limit\":\"10\",\"image_formats\":\"gif,bmp,jpg,jpeg,png\",\"source_formats\":\"txt,less,ini,xml,js,php,css,scss,sass\",\"font_formats\":\"woff,ttf,otf\",\"compressed_formats\":\"zip\"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(22, 0, 'com_content', 'component', 'com_content', '', 1, 1, 0, 1, '{\"name\":\"com_content\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_CONTENT_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"content\"}', '{\"article_layout\":\"_:default\",\"show_title\":\"1\",\"link_titles\":\"1\",\"show_intro\":\"1\",\"show_category\":\"1\",\"link_category\":\"1\",\"show_parent_category\":\"0\",\"link_parent_category\":\"0\",\"show_author\":\"1\",\"link_author\":\"0\",\"show_create_date\":\"0\",\"show_modify_date\":\"0\",\"show_publish_date\":\"1\",\"show_item_navigation\":\"1\",\"show_vote\":\"0\",\"show_readmore\":\"1\",\"show_readmore_title\":\"1\",\"readmore_limit\":\"100\",\"show_icons\":\"1\",\"show_print_icon\":\"1\",\"show_email_icon\":\"1\",\"show_hits\":\"1\",\"show_noauth\":\"0\",\"show_publishing_options\":\"1\",\"show_article_options\":\"1\",\"save_history\":\"1\",\"history_limit\":10,\"show_urls_images_frontend\":\"0\",\"show_urls_images_backend\":\"1\",\"targeta\":0,\"targetb\":0,\"targetc\":0,\"float_intro\":\"left\",\"float_fulltext\":\"left\",\"category_layout\":\"_:blog\",\"show_category_title\":\"0\",\"show_description\":\"0\",\"show_description_image\":\"0\",\"maxLevel\":\"1\",\"show_empty_categories\":\"0\",\"show_no_articles\":\"1\",\"show_subcat_desc\":\"1\",\"show_cat_num_articles\":\"0\",\"show_base_description\":\"1\",\"maxLevelcat\":\"-1\",\"show_empty_categories_cat\":\"0\",\"show_subcat_desc_cat\":\"1\",\"show_cat_num_articles_cat\":\"1\",\"num_leading_articles\":\"1\",\"num_intro_articles\":\"4\",\"num_columns\":\"2\",\"num_links\":\"4\",\"multi_column_order\":\"0\",\"show_subcategory_content\":\"0\",\"show_pagination_limit\":\"1\",\"filter_field\":\"hide\",\"show_headings\":\"1\",\"list_show_date\":\"0\",\"date_format\":\"\",\"list_show_hits\":\"1\",\"list_show_author\":\"1\",\"orderby_pri\":\"order\",\"orderby_sec\":\"rdate\",\"order_date\":\"published\",\"show_pagination\":\"2\",\"show_pagination_results\":\"1\",\"show_feed_link\":\"1\",\"feed_summary\":\"0\"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(23, 0, 'com_config', 'component', 'com_config', '', 1, 1, 0, 1, '{\"name\":\"com_config\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_CONFIG_XML_DESCRIPTION\",\"group\":\"\"}', '{\"filters\":{\"1\":{\"filter_type\":\"NH\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"9\":{\"filter_type\":\"BL\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"6\":{\"filter_type\":\"BL\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"7\":{\"filter_type\":\"NONE\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"2\":{\"filter_type\":\"NH\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"3\":{\"filter_type\":\"BL\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"4\":{\"filter_type\":\"BL\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"5\":{\"filter_type\":\"BL\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"8\":{\"filter_type\":\"NONE\",\"filter_tags\":\"\",\"filter_attributes\":\"\"}}}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(24, 0, 'com_redirect', 'component', 'com_redirect', '', 1, 1, 0, 1, '{\"name\":\"com_redirect\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_REDIRECT_XML_DESCRIPTION\",\"group\":\"\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(25, 0, 'com_users', 'component', 'com_users', '', 1, 1, 0, 1, '{\"name\":\"com_users\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_USERS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"users\"}', '{\"allowUserRegistration\":\"0\",\"new_usertype\":\"2\",\"guest_usergroup\":\"9\",\"sendpassword\":\"1\",\"useractivation\":\"2\",\"mail_to_admin\":\"1\",\"captcha\":\"\",\"frontend_userparams\":\"1\",\"site_language\":\"0\",\"change_login_name\":\"0\",\"reset_count\":\"10\",\"reset_time\":\"1\",\"minimum_length\":\"4\",\"minimum_integers\":\"0\",\"minimum_symbols\":\"0\",\"minimum_uppercase\":\"0\",\"save_history\":\"1\",\"history_limit\":5,\"mailSubjectPrefix\":\"\",\"mailBodySuffix\":\"\"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(27, 0, 'com_finder', 'component', 'com_finder', '', 1, 1, 0, 0, '{\"name\":\"com_finder\",\"type\":\"component\",\"creationDate\":\"August 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_FINDER_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"finder\"}', '{\"enabled\":\"0\",\"show_description\":\"1\",\"description_length\":255,\"allow_empty_query\":\"0\",\"show_url\":\"1\",\"show_autosuggest\":\"1\",\"show_suggested_query\":\"1\",\"show_explained_query\":\"1\",\"show_advanced\":\"1\",\"show_advanced_tips\":\"1\",\"expand_advanced\":\"0\",\"show_date_filters\":\"0\",\"sort_order\":\"relevance\",\"sort_direction\":\"desc\",\"highlight_terms\":\"1\",\"opensearch_name\":\"\",\"opensearch_description\":\"\",\"batch_size\":\"50\",\"memory_table_limit\":30000,\"title_multiplier\":\"1.7\",\"text_multiplier\":\"0.7\",\"meta_multiplier\":\"1.2\",\"path_multiplier\":\"2.0\",\"misc_multiplier\":\"0.3\",\"stem\":\"1\",\"stemmer\":\"snowball\",\"enable_logging\":\"0\"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(28, 0, 'com_joomlaupdate', 'component', 'com_joomlaupdate', '', 1, 1, 0, 1, '{\"name\":\"com_joomlaupdate\",\"type\":\"component\",\"creationDate\":\"February 2012\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.6.2\",\"description\":\"COM_JOOMLAUPDATE_XML_DESCRIPTION\",\"group\":\"\"}', '{\"updatesource\":\"default\",\"customurl\":\"\"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(29, 0, 'com_tags', 'component', 'com_tags', '', 1, 1, 1, 1, '{\"name\":\"com_tags\",\"type\":\"component\",\"creationDate\":\"December 2013\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.1.0\",\"description\":\"COM_TAGS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"tags\"}', '{\"tag_layout\":\"_:default\",\"save_history\":\"1\",\"history_limit\":5,\"show_tag_title\":\"0\",\"tag_list_show_tag_image\":\"0\",\"tag_list_show_tag_description\":\"0\",\"tag_list_image\":\"\",\"tag_list_orderby\":\"title\",\"tag_list_orderby_direction\":\"ASC\",\"show_headings\":\"0\",\"tag_list_show_date\":\"0\",\"tag_list_show_item_image\":\"0\",\"tag_list_show_item_description\":\"0\",\"tag_list_item_maximum_characters\":0,\"return_any_or_all\":\"1\",\"include_children\":\"0\",\"maximum\":200,\"tag_list_language_filter\":\"all\",\"tags_layout\":\"_:default\",\"all_tags_orderby\":\"title\",\"all_tags_orderby_direction\":\"ASC\",\"all_tags_show_tag_image\":\"0\",\"all_tags_show_tag_descripion\":\"0\",\"all_tags_tag_maximum_characters\":20,\"all_tags_show_tag_hits\":\"0\",\"filter_field\":\"1\",\"show_pagination_limit\":\"1\",\"show_pagination\":\"2\",\"show_pagination_results\":\"1\",\"tag_field_ajax_mode\":\"1\",\"show_feed_link\":\"1\"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(30, 0, 'com_contenthistory', 'component', 'com_contenthistory', '', 1, 1, 1, 0, '{\"name\":\"com_contenthistory\",\"type\":\"component\",\"creationDate\":\"May 2013\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.2.0\",\"description\":\"COM_CONTENTHISTORY_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"contenthistory\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(31, 0, 'com_ajax', 'component', 'com_ajax', '', 1, 1, 1, 1, '{\"name\":\"com_ajax\",\"type\":\"component\",\"creationDate\":\"August 2013\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.2.0\",\"description\":\"COM_AJAX_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"ajax\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(32, 0, 'com_postinstall', 'component', 'com_postinstall', '', 1, 1, 1, 1, '{\"name\":\"com_postinstall\",\"type\":\"component\",\"creationDate\":\"September 2013\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.2.0\",\"description\":\"COM_POSTINSTALL_XML_DESCRIPTION\",\"group\":\"\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(33, 0, 'com_fields', 'component', 'com_fields', '', 1, 1, 1, 0, '{\"name\":\"com_fields\",\"type\":\"component\",\"creationDate\":\"March 2016\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.7.0\",\"description\":\"COM_FIELDS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"fields\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(34, 0, 'com_associations', 'component', 'com_associations', '', 1, 1, 1, 0, '{\"name\":\"com_associations\",\"type\":\"component\",\"creationDate\":\"Januar 2017\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.7.0\",\"description\":\"COM_ASSOCIATIONS_XML_DESCRIPTION\",\"group\":\"\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(102, 0, 'LIB_PHPUTF8', 'library', 'phputf8', '', 0, 1, 1, 1, '{\"name\":\"LIB_PHPUTF8\",\"type\":\"library\",\"creationDate\":\"2006\",\"author\":\"Harry Fuecks\",\"copyright\":\"Copyright various authors\",\"authorEmail\":\"hfuecks@gmail.com\",\"authorUrl\":\"http:\\/\\/sourceforge.net\\/projects\\/phputf8\",\"version\":\"0.5\",\"description\":\"LIB_PHPUTF8_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"phputf8\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(103, 0, 'LIB_JOOMLA', 'library', 'joomla', '', 0, 1, 1, 1, '{\"name\":\"LIB_JOOMLA\",\"type\":\"library\",\"creationDate\":\"2008\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"https:\\/\\/www.joomla.org\",\"version\":\"13.1\",\"description\":\"LIB_JOOMLA_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"joomla\"}', '{\"mediaversion\":\"a54451ae556f058a69eb0c9196fae197\"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(104, 0, 'LIB_IDNA', 'library', 'idna_convert', '', 0, 1, 1, 1, '{\"name\":\"LIB_IDNA\",\"type\":\"library\",\"creationDate\":\"2004\",\"author\":\"phlyLabs\",\"copyright\":\"2004-2011 phlyLabs Berlin, http:\\/\\/phlylabs.de\",\"authorEmail\":\"phlymail@phlylabs.de\",\"authorUrl\":\"http:\\/\\/phlylabs.de\",\"version\":\"0.8.0\",\"description\":\"LIB_IDNA_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"idna_convert\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(105, 0, 'FOF', 'library', 'fof', '', 0, 1, 1, 1, '{\"name\":\"FOF\",\"type\":\"library\",\"creationDate\":\"2015-04-22 13:15:32\",\"author\":\"Nicholas K. Dionysopoulos \\/ Akeeba Ltd\",\"copyright\":\"(C)2011-2015 Nicholas K. Dionysopoulos\",\"authorEmail\":\"nicholas@akeebabackup.com\",\"authorUrl\":\"https:\\/\\/www.akeebabackup.com\",\"version\":\"2.4.3\",\"description\":\"LIB_FOF_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"fof\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(106, 0, 'LIB_PHPASS', 'library', 'phpass', '', 0, 1, 1, 1, '{\"name\":\"LIB_PHPASS\",\"type\":\"library\",\"creationDate\":\"2004-2006\",\"author\":\"Solar Designer\",\"copyright\":\"\",\"authorEmail\":\"solar@openwall.com\",\"authorUrl\":\"http:\\/\\/www.openwall.com\\/phpass\\/\",\"version\":\"0.3\",\"description\":\"LIB_PHPASS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"phpass\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(200, 0, 'mod_articles_archive', 'module', 'mod_articles_archive', '', 0, 1, 1, 0, '{\"name\":\"mod_articles_archive\",\"type\":\"module\",\"creationDate\":\"July 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_ARTICLES_ARCHIVE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_articles_archive\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(201, 0, 'mod_articles_latest', 'module', 'mod_articles_latest', '', 0, 1, 1, 0, '{\"name\":\"mod_articles_latest\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_LATEST_NEWS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_articles_latest\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(202, 0, 'mod_articles_popular', 'module', 'mod_articles_popular', '', 0, 1, 1, 0, '{\"name\":\"mod_articles_popular\",\"type\":\"module\",\"creationDate\":\"July 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_POPULAR_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_articles_popular\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(203, 0, 'mod_banners', 'module', 'mod_banners', '', 0, 1, 1, 0, '{\"name\":\"mod_banners\",\"type\":\"module\",\"creationDate\":\"July 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_BANNERS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_banners\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(204, 0, 'mod_breadcrumbs', 'module', 'mod_breadcrumbs', '', 0, 1, 1, 1, '{\"name\":\"mod_breadcrumbs\",\"type\":\"module\",\"creationDate\":\"July 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_BREADCRUMBS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_breadcrumbs\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(205, 0, 'mod_custom', 'module', 'mod_custom', '', 0, 1, 1, 1, '{\"name\":\"mod_custom\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_CUSTOM_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_custom\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(206, 0, 'mod_feed', 'module', 'mod_feed', '', 0, 1, 1, 0, '{\"name\":\"mod_feed\",\"type\":\"module\",\"creationDate\":\"July 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_FEED_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_feed\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(207, 0, 'mod_footer', 'module', 'mod_footer', '', 0, 1, 1, 0, '{\"name\":\"mod_footer\",\"type\":\"module\",\"creationDate\":\"July 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_FOOTER_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_footer\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(208, 0, 'mod_login', 'module', 'mod_login', '', 0, 1, 1, 1, '{\"name\":\"mod_login\",\"type\":\"module\",\"creationDate\":\"July 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_LOGIN_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_login\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(209, 0, 'mod_menu', 'module', 'mod_menu', '', 0, 1, 1, 1, '{\"name\":\"mod_menu\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_MENU_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_menu\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(210, 0, 'mod_articles_news', 'module', 'mod_articles_news', '', 0, 1, 1, 0, '{\"name\":\"mod_articles_news\",\"type\":\"module\",\"creationDate\":\"July 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_ARTICLES_NEWS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_articles_news\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(211, 0, 'mod_random_image', 'module', 'mod_random_image', '', 0, 1, 1, 0, '{\"name\":\"mod_random_image\",\"type\":\"module\",\"creationDate\":\"July 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_RANDOM_IMAGE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_random_image\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(212, 0, 'mod_related_items', 'module', 'mod_related_items', '', 0, 1, 1, 0, '{\"name\":\"mod_related_items\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_RELATED_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_related_items\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(213, 0, 'mod_search', 'module', 'mod_search', '', 0, 1, 1, 0, '{\"name\":\"mod_search\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_SEARCH_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_search\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(214, 0, 'mod_stats', 'module', 'mod_stats', '', 0, 1, 1, 0, '{\"name\":\"mod_stats\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_STATS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_stats\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(215, 0, 'mod_syndicate', 'module', 'mod_syndicate', '', 0, 1, 1, 1, '{\"name\":\"mod_syndicate\",\"type\":\"module\",\"creationDate\":\"May 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_SYNDICATE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_syndicate\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(216, 0, 'mod_users_latest', 'module', 'mod_users_latest', '', 0, 1, 1, 0, '{\"name\":\"mod_users_latest\",\"type\":\"module\",\"creationDate\":\"December 2009\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_USERS_LATEST_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_users_latest\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(218, 0, 'mod_whosonline', 'module', 'mod_whosonline', '', 0, 1, 1, 0, '{\"name\":\"mod_whosonline\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_WHOSONLINE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_whosonline\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(219, 0, 'mod_wrapper', 'module', 'mod_wrapper', '', 0, 1, 1, 0, '{\"name\":\"mod_wrapper\",\"type\":\"module\",\"creationDate\":\"October 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_WRAPPER_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_wrapper\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(220, 0, 'mod_articles_category', 'module', 'mod_articles_category', '', 0, 1, 1, 0, '{\"name\":\"mod_articles_category\",\"type\":\"module\",\"creationDate\":\"February 2010\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_ARTICLES_CATEGORY_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_articles_category\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(221, 0, 'mod_articles_categories', 'module', 'mod_articles_categories', '', 0, 1, 1, 0, '{\"name\":\"mod_articles_categories\",\"type\":\"module\",\"creationDate\":\"February 2010\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_ARTICLES_CATEGORIES_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_articles_categories\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(222, 0, 'mod_languages', 'module', 'mod_languages', '', 0, 1, 1, 1, '{\"name\":\"mod_languages\",\"type\":\"module\",\"creationDate\":\"February 2010\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.5.0\",\"description\":\"MOD_LANGUAGES_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_languages\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(223, 0, 'mod_finder', 'module', 'mod_finder', '', 0, 1, 0, 0, '{\"name\":\"mod_finder\",\"type\":\"module\",\"creationDate\":\"August 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_FINDER_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_finder\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(300, 0, 'mod_custom', 'module', 'mod_custom', '', 1, 1, 1, 1, '{\"name\":\"mod_custom\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_CUSTOM_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_custom\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(301, 0, 'mod_feed', 'module', 'mod_feed', '', 1, 1, 1, 0, '{\"name\":\"mod_feed\",\"type\":\"module\",\"creationDate\":\"July 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_FEED_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_feed\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(302, 0, 'mod_latest', 'module', 'mod_latest', '', 1, 1, 1, 0, '{\"name\":\"mod_latest\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_LATEST_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_latest\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(303, 0, 'mod_logged', 'module', 'mod_logged', '', 1, 1, 1, 0, '{\"name\":\"mod_logged\",\"type\":\"module\",\"creationDate\":\"January 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_LOGGED_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_logged\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(304, 0, 'mod_login', 'module', 'mod_login', '', 1, 1, 1, 1, '{\"name\":\"mod_login\",\"type\":\"module\",\"creationDate\":\"March 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_LOGIN_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_login\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(305, 0, 'mod_menu', 'module', 'mod_menu', '', 1, 1, 1, 0, '{\"name\":\"mod_menu\",\"type\":\"module\",\"creationDate\":\"March 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_MENU_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_menu\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(307, 0, 'mod_popular', 'module', 'mod_popular', '', 1, 1, 1, 0, '{\"name\":\"mod_popular\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_POPULAR_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_popular\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(308, 0, 'mod_quickicon', 'module', 'mod_quickicon', '', 1, 1, 1, 1, '{\"name\":\"mod_quickicon\",\"type\":\"module\",\"creationDate\":\"Nov 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_QUICKICON_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_quickicon\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(309, 0, 'mod_status', 'module', 'mod_status', '', 1, 1, 1, 0, '{\"name\":\"mod_status\",\"type\":\"module\",\"creationDate\":\"Feb 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_STATUS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_status\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(310, 0, 'mod_submenu', 'module', 'mod_submenu', '', 1, 1, 1, 0, '{\"name\":\"mod_submenu\",\"type\":\"module\",\"creationDate\":\"Feb 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_SUBMENU_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_submenu\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(311, 0, 'mod_title', 'module', 'mod_title', '', 1, 1, 1, 0, '{\"name\":\"mod_title\",\"type\":\"module\",\"creationDate\":\"Nov 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_TITLE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_title\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(312, 0, 'mod_toolbar', 'module', 'mod_toolbar', '', 1, 1, 1, 1, '{\"name\":\"mod_toolbar\",\"type\":\"module\",\"creationDate\":\"Nov 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_TOOLBAR_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_toolbar\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(313, 0, 'mod_multilangstatus', 'module', 'mod_multilangstatus', '', 1, 1, 1, 0, '{\"name\":\"mod_multilangstatus\",\"type\":\"module\",\"creationDate\":\"September 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_MULTILANGSTATUS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_multilangstatus\"}', '{\"cache\":\"0\"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(314, 0, 'mod_version', 'module', 'mod_version', '', 1, 1, 1, 0, '{\"name\":\"mod_version\",\"type\":\"module\",\"creationDate\":\"January 2012\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_VERSION_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_version\"}', '{\"format\":\"short\",\"product\":\"1\",\"cache\":\"0\"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(315, 0, 'mod_stats_admin', 'module', 'mod_stats_admin', '', 1, 1, 1, 0, '{\"name\":\"mod_stats_admin\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_STATS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_stats_admin\"}', '{\"serverinfo\":\"0\",\"siteinfo\":\"0\",\"counter\":\"0\",\"increase\":\"0\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(316, 0, 'mod_tags_popular', 'module', 'mod_tags_popular', '', 0, 1, 1, 0, '{\"name\":\"mod_tags_popular\",\"type\":\"module\",\"creationDate\":\"January 2013\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.1.0\",\"description\":\"MOD_TAGS_POPULAR_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_tags_popular\"}', '{\"maximum\":\"5\",\"timeframe\":\"alltime\",\"owncache\":\"1\"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(317, 0, 'mod_tags_similar', 'module', 'mod_tags_similar', '', 0, 1, 1, 0, '{\"name\":\"mod_tags_similar\",\"type\":\"module\",\"creationDate\":\"January 2013\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.1.0\",\"description\":\"MOD_TAGS_SIMILAR_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_tags_similar\"}', '{\"maximum\":\"5\",\"matchtype\":\"any\",\"owncache\":\"1\"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(318, 0, 'mod_sampledata', 'module', 'mod_sampledata', '', 1, 1, 1, 0, '{\"name\":\"mod_sampledata\",\"type\":\"module\",\"creationDate\":\"July 2017\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.8.0\",\"description\":\"MOD_SAMPLEDATA_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_sampledata\"}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(400, 0, 'plg_authentication_gmail', 'plugin', 'gmail', 'authentication', 0, 0, 1, 0, '{\"name\":\"plg_authentication_gmail\",\"type\":\"plugin\",\"creationDate\":\"February 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_GMAIL_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"gmail\"}', '{\"applysuffix\":\"0\",\"suffix\":\"\",\"verifypeer\":\"1\",\"user_blacklist\":\"\"}', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(401, 0, 'plg_authentication_joomla', 'plugin', 'joomla', 'authentication', 0, 1, 1, 1, '{\"name\":\"plg_authentication_joomla\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_AUTH_JOOMLA_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"joomla\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(402, 0, 'plg_authentication_ldap', 'plugin', 'ldap', 'authentication', 0, 0, 1, 0, '{\"name\":\"plg_authentication_ldap\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_LDAP_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"ldap\"}', '{\"host\":\"\",\"port\":\"389\",\"use_ldapV3\":\"0\",\"negotiate_tls\":\"0\",\"no_referrals\":\"0\",\"auth_method\":\"bind\",\"base_dn\":\"\",\"search_string\":\"\",\"users_dn\":\"\",\"username\":\"admin\",\"password\":\"bobby7\",\"ldap_fullname\":\"fullName\",\"ldap_email\":\"mail\",\"ldap_uid\":\"uid\"}', '', '', 0, '0000-00-00 00:00:00', 3, 0);
INSERT INTO `jm_extensions` (`extension_id`, `package_id`, `name`, `type`, `element`, `folder`, `client_id`, `enabled`, `access`, `protected`, `manifest_cache`, `params`, `custom_data`, `system_data`, `checked_out`, `checked_out_time`, `ordering`, `state`) VALUES
(403, 0, 'plg_content_contact', 'plugin', 'contact', 'content', 0, 1, 1, 0, '{\"name\":\"plg_content_contact\",\"type\":\"plugin\",\"creationDate\":\"January 2014\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.2.2\",\"description\":\"PLG_CONTENT_CONTACT_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"contact\"}', '', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(404, 0, 'plg_content_emailcloak', 'plugin', 'emailcloak', 'content', 0, 1, 1, 0, '{\"name\":\"plg_content_emailcloak\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_CONTENT_EMAILCLOAK_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"emailcloak\"}', '{\"mode\":\"1\"}', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(406, 0, 'plg_content_loadmodule', 'plugin', 'loadmodule', 'content', 0, 1, 1, 0, '{\"name\":\"plg_content_loadmodule\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_LOADMODULE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"loadmodule\"}', '{\"style\":\"xhtml\"}', '', '', 0, '2011-09-18 15:22:50', 0, 0),
(407, 0, 'plg_content_pagebreak', 'plugin', 'pagebreak', 'content', 0, 1, 1, 0, '{\"name\":\"plg_content_pagebreak\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_CONTENT_PAGEBREAK_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"pagebreak\"}', '{\"title\":\"1\",\"multipage_toc\":\"1\",\"showall\":\"1\"}', '', '', 0, '0000-00-00 00:00:00', 4, 0),
(408, 0, 'plg_content_pagenavigation', 'plugin', 'pagenavigation', 'content', 0, 1, 1, 0, '{\"name\":\"plg_content_pagenavigation\",\"type\":\"plugin\",\"creationDate\":\"January 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_PAGENAVIGATION_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"pagenavigation\"}', '{\"position\":\"1\"}', '', '', 0, '0000-00-00 00:00:00', 5, 0),
(409, 0, 'plg_content_vote', 'plugin', 'vote', 'content', 0, 0, 1, 0, '{\"name\":\"plg_content_vote\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_VOTE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"vote\"}', '', '', '', 0, '0000-00-00 00:00:00', 6, 0),
(410, 0, 'plg_editors_codemirror', 'plugin', 'codemirror', 'editors', 0, 1, 1, 1, '{\"name\":\"plg_editors_codemirror\",\"type\":\"plugin\",\"creationDate\":\"28 March 2011\",\"author\":\"Marijn Haverbeke\",\"copyright\":\"Copyright (C) 2014 - 2017 by Marijn Haverbeke <marijnh@gmail.com> and others\",\"authorEmail\":\"marijnh@gmail.com\",\"authorUrl\":\"http:\\/\\/codemirror.net\\/\",\"version\":\"5.34.0\",\"description\":\"PLG_CODEMIRROR_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"codemirror\"}', '{\"lineNumbers\":\"1\",\"lineWrapping\":\"1\",\"matchTags\":\"1\",\"matchBrackets\":\"1\",\"marker-gutter\":\"1\",\"autoCloseTags\":\"1\",\"autoCloseBrackets\":\"1\",\"autoFocus\":\"1\",\"theme\":\"default\",\"tabmode\":\"indent\"}', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(411, 0, 'plg_editors_none', 'plugin', 'none', 'editors', 0, 1, 1, 1, '{\"name\":\"plg_editors_none\",\"type\":\"plugin\",\"creationDate\":\"September 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_NONE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"none\"}', '', '', '', 0, '0000-00-00 00:00:00', 2, 0),
(412, 0, 'plg_editors_tinymce', 'plugin', 'tinymce', 'editors', 0, 1, 1, 0, '{\"name\":\"plg_editors_tinymce\",\"type\":\"plugin\",\"creationDate\":\"2005-2017\",\"author\":\"Ephox Corporation\",\"copyright\":\"Ephox Corporation\",\"authorEmail\":\"N\\/A\",\"authorUrl\":\"http:\\/\\/www.tinymce.com\",\"version\":\"4.5.8\",\"description\":\"PLG_TINY_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"tinymce\"}', '{\"configuration\":{\"toolbars\":{\"2\":{\"toolbar1\":[\"bold\",\"underline\",\"strikethrough\",\"|\",\"undo\",\"redo\",\"|\",\"bullist\",\"numlist\",\"|\",\"pastetext\"]},\"1\":{\"menu\":[\"edit\",\"insert\",\"view\",\"format\",\"table\",\"tools\"],\"toolbar1\":[\"bold\",\"italic\",\"underline\",\"strikethrough\",\"|\",\"alignleft\",\"aligncenter\",\"alignright\",\"alignjustify\",\"|\",\"formatselect\",\"|\",\"bullist\",\"numlist\",\"|\",\"outdent\",\"indent\",\"|\",\"undo\",\"redo\",\"|\",\"link\",\"unlink\",\"anchor\",\"code\",\"|\",\"hr\",\"table\",\"|\",\"subscript\",\"superscript\",\"|\",\"charmap\",\"pastetext\",\"preview\"]},\"0\":{\"menu\":[\"edit\",\"insert\",\"view\",\"format\",\"table\",\"tools\"],\"toolbar1\":[\"bold\",\"italic\",\"underline\",\"strikethrough\",\"|\",\"alignleft\",\"aligncenter\",\"alignright\",\"alignjustify\",\"|\",\"styleselect\",\"|\",\"formatselect\",\"fontselect\",\"fontsizeselect\",\"|\",\"searchreplace\",\"|\",\"bullist\",\"numlist\",\"|\",\"outdent\",\"indent\",\"|\",\"undo\",\"redo\",\"|\",\"link\",\"unlink\",\"anchor\",\"image\",\"|\",\"code\",\"|\",\"forecolor\",\"backcolor\",\"|\",\"fullscreen\",\"|\",\"table\",\"|\",\"subscript\",\"superscript\",\"|\",\"charmap\",\"emoticons\",\"media\",\"hr\",\"ltr\",\"rtl\",\"|\",\"cut\",\"copy\",\"paste\",\"pastetext\",\"|\",\"visualchars\",\"visualblocks\",\"nonbreaking\",\"blockquote\",\"template\",\"|\",\"print\",\"preview\",\"codesample\",\"insertdatetime\",\"removeformat\"]}},\"setoptions\":{\"2\":{\"access\":[\"1\"],\"skin\":\"0\",\"skin_admin\":\"0\",\"mobile\":\"0\",\"drag_drop\":\"1\",\"path\":\"\",\"entity_encoding\":\"raw\",\"lang_mode\":\"1\",\"text_direction\":\"ltr\",\"content_css\":\"1\",\"content_css_custom\":\"\",\"relative_urls\":\"1\",\"newlines\":\"0\",\"use_config_textfilters\":\"0\",\"invalid_elements\":\"script,applet,iframe\",\"valid_elements\":\"\",\"extended_elements\":\"\",\"resizing\":\"1\",\"resize_horizontal\":\"1\",\"element_path\":\"1\",\"wordcount\":\"1\",\"image_advtab\":\"0\",\"advlist\":\"1\",\"autosave\":\"1\",\"contextmenu\":\"1\",\"custom_plugin\":\"\",\"custom_button\":\"\"},\"1\":{\"access\":[\"6\",\"2\"],\"skin\":\"0\",\"skin_admin\":\"0\",\"mobile\":\"0\",\"drag_drop\":\"1\",\"path\":\"\",\"entity_encoding\":\"raw\",\"lang_mode\":\"1\",\"text_direction\":\"ltr\",\"content_css\":\"1\",\"content_css_custom\":\"\",\"relative_urls\":\"1\",\"newlines\":\"0\",\"use_config_textfilters\":\"0\",\"invalid_elements\":\"script,applet,iframe\",\"valid_elements\":\"\",\"extended_elements\":\"\",\"resizing\":\"1\",\"resize_horizontal\":\"1\",\"element_path\":\"1\",\"wordcount\":\"1\",\"image_advtab\":\"0\",\"advlist\":\"1\",\"autosave\":\"1\",\"contextmenu\":\"1\",\"custom_plugin\":\"\",\"custom_button\":\"\"},\"0\":{\"access\":[\"7\",\"4\",\"8\"],\"skin\":\"0\",\"skin_admin\":\"0\",\"mobile\":\"0\",\"drag_drop\":\"1\",\"path\":\"\",\"entity_encoding\":\"raw\",\"lang_mode\":\"1\",\"text_direction\":\"ltr\",\"content_css\":\"1\",\"content_css_custom\":\"\",\"relative_urls\":\"1\",\"newlines\":\"0\",\"use_config_textfilters\":\"0\",\"invalid_elements\":\"script,applet,iframe\",\"valid_elements\":\"\",\"extended_elements\":\"\",\"resizing\":\"1\",\"resize_horizontal\":\"1\",\"element_path\":\"1\",\"wordcount\":\"1\",\"image_advtab\":\"1\",\"advlist\":\"1\",\"autosave\":\"1\",\"contextmenu\":\"1\",\"custom_plugin\":\"\",\"custom_button\":\"\"}}},\"sets_amount\":3,\"html_height\":\"550\",\"html_width\":\"750\"}', '', '', 0, '0000-00-00 00:00:00', 3, 0),
(413, 0, 'plg_editors-xtd_article', 'plugin', 'article', 'editors-xtd', 0, 1, 1, 0, '{\"name\":\"plg_editors-xtd_article\",\"type\":\"plugin\",\"creationDate\":\"October 2009\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_ARTICLE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"article\"}', '', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(414, 0, 'plg_editors-xtd_image', 'plugin', 'image', 'editors-xtd', 0, 1, 1, 0, '{\"name\":\"plg_editors-xtd_image\",\"type\":\"plugin\",\"creationDate\":\"August 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_IMAGE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"image\"}', '', '', '', 0, '0000-00-00 00:00:00', 2, 0),
(415, 0, 'plg_editors-xtd_pagebreak', 'plugin', 'pagebreak', 'editors-xtd', 0, 1, 1, 0, '{\"name\":\"plg_editors-xtd_pagebreak\",\"type\":\"plugin\",\"creationDate\":\"August 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_EDITORSXTD_PAGEBREAK_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"pagebreak\"}', '', '', '', 0, '0000-00-00 00:00:00', 3, 0),
(416, 0, 'plg_editors-xtd_readmore', 'plugin', 'readmore', 'editors-xtd', 0, 1, 1, 0, '{\"name\":\"plg_editors-xtd_readmore\",\"type\":\"plugin\",\"creationDate\":\"March 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_READMORE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"readmore\"}', '', '', '', 0, '0000-00-00 00:00:00', 4, 0),
(417, 0, 'plg_search_categories', 'plugin', 'categories', 'search', 0, 1, 1, 0, '{\"name\":\"plg_search_categories\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_SEARCH_CATEGORIES_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"categories\"}', '{\"search_limit\":\"50\",\"search_content\":\"1\",\"search_archived\":\"1\"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(418, 0, 'plg_search_contacts', 'plugin', 'contacts', 'search', 0, 1, 1, 0, '{\"name\":\"plg_search_contacts\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_SEARCH_CONTACTS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"contacts\"}', '{\"search_limit\":\"50\",\"search_content\":\"1\",\"search_archived\":\"1\"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(419, 0, 'plg_search_content', 'plugin', 'content', 'search', 0, 1, 1, 0, '{\"name\":\"plg_search_content\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_SEARCH_CONTENT_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"content\"}', '{\"search_limit\":\"50\",\"search_content\":\"1\",\"search_archived\":\"1\"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(420, 0, 'plg_search_newsfeeds', 'plugin', 'newsfeeds', 'search', 0, 1, 1, 0, '{\"name\":\"plg_search_newsfeeds\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_SEARCH_NEWSFEEDS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"newsfeeds\"}', '{\"search_limit\":\"50\",\"search_content\":\"1\",\"search_archived\":\"1\"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(422, 0, 'plg_system_languagefilter', 'plugin', 'languagefilter', 'system', 0, 0, 1, 1, '{\"name\":\"plg_system_languagefilter\",\"type\":\"plugin\",\"creationDate\":\"July 2010\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_SYSTEM_LANGUAGEFILTER_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"languagefilter\"}', '', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(423, 0, 'plg_system_p3p', 'plugin', 'p3p', 'system', 0, 0, 1, 0, '{\"name\":\"plg_system_p3p\",\"type\":\"plugin\",\"creationDate\":\"September 2010\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_P3P_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"p3p\"}', '{\"headers\":\"NOI ADM DEV PSAi COM NAV OUR OTRo STP IND DEM\"}', '', '', 0, '0000-00-00 00:00:00', 2, 0),
(424, 0, 'plg_system_cache', 'plugin', 'cache', 'system', 0, 0, 1, 1, '{\"name\":\"plg_system_cache\",\"type\":\"plugin\",\"creationDate\":\"February 2007\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_CACHE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"cache\"}', '{\"browsercache\":\"0\",\"cachetime\":\"15\"}', '', '', 0, '0000-00-00 00:00:00', 9, 0),
(425, 0, 'plg_system_debug', 'plugin', 'debug', 'system', 0, 1, 1, 0, '{\"name\":\"plg_system_debug\",\"type\":\"plugin\",\"creationDate\":\"December 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_DEBUG_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"debug\"}', '{\"profile\":\"1\",\"queries\":\"1\",\"memory\":\"1\",\"language_files\":\"1\",\"language_strings\":\"1\",\"strip-first\":\"1\",\"strip-prefix\":\"\",\"strip-suffix\":\"\"}', '', '', 0, '0000-00-00 00:00:00', 4, 0),
(426, 0, 'plg_system_log', 'plugin', 'log', 'system', 0, 1, 1, 1, '{\"name\":\"plg_system_log\",\"type\":\"plugin\",\"creationDate\":\"April 2007\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_LOG_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"log\"}', '', '', '', 0, '0000-00-00 00:00:00', 5, 0),
(427, 0, 'plg_system_redirect', 'plugin', 'redirect', 'system', 0, 0, 1, 1, '{\"name\":\"plg_system_redirect\",\"type\":\"plugin\",\"creationDate\":\"April 2009\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_SYSTEM_REDIRECT_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"redirect\"}', '', '', '', 0, '0000-00-00 00:00:00', 6, 0),
(428, 0, 'plg_system_remember', 'plugin', 'remember', 'system', 0, 1, 1, 1, '{\"name\":\"plg_system_remember\",\"type\":\"plugin\",\"creationDate\":\"April 2007\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_REMEMBER_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"remember\"}', '', '', '', 0, '0000-00-00 00:00:00', 7, 0),
(429, 0, 'plg_system_sef', 'plugin', 'sef', 'system', 0, 1, 1, 0, '{\"name\":\"plg_system_sef\",\"type\":\"plugin\",\"creationDate\":\"December 2007\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_SEF_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"sef\"}', '', '', '', 0, '0000-00-00 00:00:00', 8, 0),
(430, 0, 'plg_system_logout', 'plugin', 'logout', 'system', 0, 1, 1, 1, '{\"name\":\"plg_system_logout\",\"type\":\"plugin\",\"creationDate\":\"April 2009\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_SYSTEM_LOGOUT_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"logout\"}', '', '', '', 0, '0000-00-00 00:00:00', 3, 0),
(431, 0, 'plg_user_contactcreator', 'plugin', 'contactcreator', 'user', 0, 0, 1, 0, '{\"name\":\"plg_user_contactcreator\",\"type\":\"plugin\",\"creationDate\":\"August 2009\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_CONTACTCREATOR_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"contactcreator\"}', '{\"autowebpage\":\"\",\"category\":\"34\",\"autopublish\":\"0\"}', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(432, 0, 'plg_user_joomla', 'plugin', 'joomla', 'user', 0, 1, 1, 0, '{\"name\":\"plg_user_joomla\",\"type\":\"plugin\",\"creationDate\":\"December 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_USER_JOOMLA_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"joomla\"}', '{\"autoregister\":\"1\",\"mail_to_user\":\"1\",\"forceLogout\":\"1\"}', '', '', 0, '0000-00-00 00:00:00', 2, 0),
(433, 0, 'plg_user_profile', 'plugin', 'profile', 'user', 0, 0, 1, 0, '{\"name\":\"plg_user_profile\",\"type\":\"plugin\",\"creationDate\":\"January 2008\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_USER_PROFILE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"profile\"}', '{\"register-require_address1\":\"1\",\"register-require_address2\":\"1\",\"register-require_city\":\"1\",\"register-require_region\":\"1\",\"register-require_country\":\"1\",\"register-require_postal_code\":\"1\",\"register-require_phone\":\"1\",\"register-require_website\":\"1\",\"register-require_favoritebook\":\"1\",\"register-require_aboutme\":\"1\",\"register-require_tos\":\"1\",\"register-require_dob\":\"1\",\"profile-require_address1\":\"1\",\"profile-require_address2\":\"1\",\"profile-require_city\":\"1\",\"profile-require_region\":\"1\",\"profile-require_country\":\"1\",\"profile-require_postal_code\":\"1\",\"profile-require_phone\":\"1\",\"profile-require_website\":\"1\",\"profile-require_favoritebook\":\"1\",\"profile-require_aboutme\":\"1\",\"profile-require_tos\":\"1\",\"profile-require_dob\":\"1\"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(434, 0, 'plg_extension_joomla', 'plugin', 'joomla', 'extension', 0, 1, 1, 1, '{\"name\":\"plg_extension_joomla\",\"type\":\"plugin\",\"creationDate\":\"May 2010\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_EXTENSION_JOOMLA_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"joomla\"}', '', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(435, 0, 'plg_content_joomla', 'plugin', 'joomla', 'content', 0, 1, 1, 0, '{\"name\":\"plg_content_joomla\",\"type\":\"plugin\",\"creationDate\":\"November 2010\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_CONTENT_JOOMLA_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"joomla\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(436, 0, 'plg_system_languagecode', 'plugin', 'languagecode', 'system', 0, 0, 1, 0, '{\"name\":\"plg_system_languagecode\",\"type\":\"plugin\",\"creationDate\":\"November 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_SYSTEM_LANGUAGECODE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"languagecode\"}', '', '', '', 0, '0000-00-00 00:00:00', 10, 0),
(437, 0, 'plg_quickicon_joomlaupdate', 'plugin', 'joomlaupdate', 'quickicon', 0, 1, 1, 1, '{\"name\":\"plg_quickicon_joomlaupdate\",\"type\":\"plugin\",\"creationDate\":\"August 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_QUICKICON_JOOMLAUPDATE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"joomlaupdate\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(438, 0, 'plg_quickicon_extensionupdate', 'plugin', 'extensionupdate', 'quickicon', 0, 1, 1, 1, '{\"name\":\"plg_quickicon_extensionupdate\",\"type\":\"plugin\",\"creationDate\":\"August 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_QUICKICON_EXTENSIONUPDATE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"extensionupdate\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(439, 0, 'plg_captcha_recaptcha', 'plugin', 'recaptcha', 'captcha', 0, 0, 1, 0, '{\"name\":\"plg_captcha_recaptcha\",\"type\":\"plugin\",\"creationDate\":\"December 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.4.0\",\"description\":\"PLG_CAPTCHA_RECAPTCHA_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"recaptcha\"}', '{\"public_key\":\"\",\"private_key\":\"\",\"theme\":\"clean\"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(440, 0, 'plg_system_highlight', 'plugin', 'highlight', 'system', 0, 1, 1, 0, '{\"name\":\"plg_system_highlight\",\"type\":\"plugin\",\"creationDate\":\"August 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_SYSTEM_HIGHLIGHT_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"highlight\"}', '', '', '', 0, '0000-00-00 00:00:00', 7, 0),
(441, 0, 'plg_content_finder', 'plugin', 'finder', 'content', 0, 0, 1, 0, '{\"name\":\"plg_content_finder\",\"type\":\"plugin\",\"creationDate\":\"December 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_CONTENT_FINDER_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"finder\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(442, 0, 'plg_finder_categories', 'plugin', 'categories', 'finder', 0, 1, 1, 0, '{\"name\":\"plg_finder_categories\",\"type\":\"plugin\",\"creationDate\":\"August 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_FINDER_CATEGORIES_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"categories\"}', '', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(443, 0, 'plg_finder_contacts', 'plugin', 'contacts', 'finder', 0, 1, 1, 0, '{\"name\":\"plg_finder_contacts\",\"type\":\"plugin\",\"creationDate\":\"August 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_FINDER_CONTACTS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"contacts\"}', '', '', '', 0, '0000-00-00 00:00:00', 2, 0),
(444, 0, 'plg_finder_content', 'plugin', 'content', 'finder', 0, 1, 1, 0, '{\"name\":\"plg_finder_content\",\"type\":\"plugin\",\"creationDate\":\"August 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_FINDER_CONTENT_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"content\"}', '', '', '', 0, '0000-00-00 00:00:00', 3, 0),
(445, 0, 'plg_finder_newsfeeds', 'plugin', 'newsfeeds', 'finder', 0, 1, 1, 0, '{\"name\":\"plg_finder_newsfeeds\",\"type\":\"plugin\",\"creationDate\":\"August 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_FINDER_NEWSFEEDS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"newsfeeds\"}', '', '', '', 0, '0000-00-00 00:00:00', 4, 0),
(447, 0, 'plg_finder_tags', 'plugin', 'tags', 'finder', 0, 1, 1, 0, '{\"name\":\"plg_finder_tags\",\"type\":\"plugin\",\"creationDate\":\"February 2013\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_FINDER_TAGS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"tags\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(448, 0, 'plg_twofactorauth_totp', 'plugin', 'totp', 'twofactorauth', 0, 0, 1, 0, '{\"name\":\"plg_twofactorauth_totp\",\"type\":\"plugin\",\"creationDate\":\"August 2013\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.2.0\",\"description\":\"PLG_TWOFACTORAUTH_TOTP_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"totp\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(449, 0, 'plg_authentication_cookie', 'plugin', 'cookie', 'authentication', 0, 1, 1, 0, '{\"name\":\"plg_authentication_cookie\",\"type\":\"plugin\",\"creationDate\":\"July 2013\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_AUTH_COOKIE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"cookie\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(450, 0, 'plg_twofactorauth_yubikey', 'plugin', 'yubikey', 'twofactorauth', 0, 0, 1, 0, '{\"name\":\"plg_twofactorauth_yubikey\",\"type\":\"plugin\",\"creationDate\":\"September 2013\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.2.0\",\"description\":\"PLG_TWOFACTORAUTH_YUBIKEY_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"yubikey\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(451, 0, 'plg_search_tags', 'plugin', 'tags', 'search', 0, 1, 1, 0, '{\"name\":\"plg_search_tags\",\"type\":\"plugin\",\"creationDate\":\"March 2014\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_SEARCH_TAGS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"tags\"}', '{\"search_limit\":\"50\",\"show_tagged_items\":\"1\"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(452, 0, 'plg_system_updatenotification', 'plugin', 'updatenotification', 'system', 0, 1, 1, 0, '{\"name\":\"plg_system_updatenotification\",\"type\":\"plugin\",\"creationDate\":\"May 2015\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.5.0\",\"description\":\"PLG_SYSTEM_UPDATENOTIFICATION_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"updatenotification\"}', '{\"lastrun\":1523434467}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(453, 0, 'plg_editors-xtd_module', 'plugin', 'module', 'editors-xtd', 0, 1, 1, 0, '{\"name\":\"plg_editors-xtd_module\",\"type\":\"plugin\",\"creationDate\":\"October 2015\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.5.0\",\"description\":\"PLG_MODULE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"module\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(454, 0, 'plg_system_stats', 'plugin', 'stats', 'system', 0, 1, 1, 0, '{\"name\":\"plg_system_stats\",\"type\":\"plugin\",\"creationDate\":\"November 2013\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.5.0\",\"description\":\"PLG_SYSTEM_STATS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"stats\"}', '{\"mode\":3,\"lastrun\":\"\",\"unique_id\":\"5980a2594f755afd316aacfada92b29a52b7abdd\",\"interval\":12}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(455, 0, 'plg_installer_packageinstaller', 'plugin', 'packageinstaller', 'installer', 0, 1, 1, 1, '{\"name\":\"plg_installer_packageinstaller\",\"type\":\"plugin\",\"creationDate\":\"May 2016\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.6.0\",\"description\":\"PLG_INSTALLER_PACKAGEINSTALLER_PLUGIN_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"packageinstaller\"}', '', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(456, 0, 'PLG_INSTALLER_FOLDERINSTALLER', 'plugin', 'folderinstaller', 'installer', 0, 1, 1, 1, '{\"name\":\"PLG_INSTALLER_FOLDERINSTALLER\",\"type\":\"plugin\",\"creationDate\":\"May 2016\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.6.0\",\"description\":\"PLG_INSTALLER_FOLDERINSTALLER_PLUGIN_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"folderinstaller\"}', '', '', '', 0, '0000-00-00 00:00:00', 2, 0),
(457, 0, 'PLG_INSTALLER_URLINSTALLER', 'plugin', 'urlinstaller', 'installer', 0, 1, 1, 1, '{\"name\":\"PLG_INSTALLER_URLINSTALLER\",\"type\":\"plugin\",\"creationDate\":\"May 2016\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.6.0\",\"description\":\"PLG_INSTALLER_URLINSTALLER_PLUGIN_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"urlinstaller\"}', '', '', '', 0, '0000-00-00 00:00:00', 3, 0),
(458, 0, 'plg_quickicon_phpversioncheck', 'plugin', 'phpversioncheck', 'quickicon', 0, 1, 1, 1, '{\"name\":\"plg_quickicon_phpversioncheck\",\"type\":\"plugin\",\"creationDate\":\"August 2016\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.7.0\",\"description\":\"PLG_QUICKICON_PHPVERSIONCHECK_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"phpversioncheck\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(459, 0, 'plg_editors-xtd_menu', 'plugin', 'menu', 'editors-xtd', 0, 1, 1, 0, '{\"name\":\"plg_editors-xtd_menu\",\"type\":\"plugin\",\"creationDate\":\"August 2016\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.7.0\",\"description\":\"PLG_EDITORS-XTD_MENU_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"menu\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(460, 0, 'plg_editors-xtd_contact', 'plugin', 'contact', 'editors-xtd', 0, 1, 1, 0, '{\"name\":\"plg_editors-xtd_contact\",\"type\":\"plugin\",\"creationDate\":\"October 2016\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.7.0\",\"description\":\"PLG_EDITORS-XTD_CONTACT_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"contact\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(461, 0, 'plg_system_fields', 'plugin', 'fields', 'system', 0, 1, 1, 0, '{\"name\":\"plg_system_fields\",\"type\":\"plugin\",\"creationDate\":\"March 2016\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.7.0\",\"description\":\"PLG_SYSTEM_FIELDS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"fields\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(462, 0, 'plg_fields_calendar', 'plugin', 'calendar', 'fields', 0, 1, 1, 0, '{\"name\":\"plg_fields_calendar\",\"type\":\"plugin\",\"creationDate\":\"March 2016\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.7.0\",\"description\":\"PLG_FIELDS_CALENDAR_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"calendar\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(463, 0, 'plg_fields_checkboxes', 'plugin', 'checkboxes', 'fields', 0, 1, 1, 0, '{\"name\":\"plg_fields_checkboxes\",\"type\":\"plugin\",\"creationDate\":\"March 2016\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.7.0\",\"description\":\"PLG_FIELDS_CHECKBOXES_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"checkboxes\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(464, 0, 'plg_fields_color', 'plugin', 'color', 'fields', 0, 1, 1, 0, '{\"name\":\"plg_fields_color\",\"type\":\"plugin\",\"creationDate\":\"March 2016\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.7.0\",\"description\":\"PLG_FIELDS_COLOR_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"color\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(465, 0, 'plg_fields_editor', 'plugin', 'editor', 'fields', 0, 1, 1, 0, '{\"name\":\"plg_fields_editor\",\"type\":\"plugin\",\"creationDate\":\"March 2016\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.7.0\",\"description\":\"PLG_FIELDS_EDITOR_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"editor\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(466, 0, 'plg_fields_imagelist', 'plugin', 'imagelist', 'fields', 0, 1, 1, 0, '{\"name\":\"plg_fields_imagelist\",\"type\":\"plugin\",\"creationDate\":\"March 2016\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.7.0\",\"description\":\"PLG_FIELDS_IMAGELIST_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"imagelist\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(467, 0, 'plg_fields_integer', 'plugin', 'integer', 'fields', 0, 1, 1, 0, '{\"name\":\"plg_fields_integer\",\"type\":\"plugin\",\"creationDate\":\"March 2016\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.7.0\",\"description\":\"PLG_FIELDS_INTEGER_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"integer\"}', '{\"multiple\":\"0\",\"first\":\"1\",\"last\":\"100\",\"step\":\"1\"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(468, 0, 'plg_fields_list', 'plugin', 'list', 'fields', 0, 1, 1, 0, '{\"name\":\"plg_fields_list\",\"type\":\"plugin\",\"creationDate\":\"March 2016\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.7.0\",\"description\":\"PLG_FIELDS_LIST_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"list\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(469, 0, 'plg_fields_media', 'plugin', 'media', 'fields', 0, 1, 1, 0, '{\"name\":\"plg_fields_media\",\"type\":\"plugin\",\"creationDate\":\"March 2016\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.7.0\",\"description\":\"PLG_FIELDS_MEDIA_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"media\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(470, 0, 'plg_fields_radio', 'plugin', 'radio', 'fields', 0, 1, 1, 0, '{\"name\":\"plg_fields_radio\",\"type\":\"plugin\",\"creationDate\":\"March 2016\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.7.0\",\"description\":\"PLG_FIELDS_RADIO_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"radio\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(471, 0, 'plg_fields_sql', 'plugin', 'sql', 'fields', 0, 1, 1, 0, '{\"name\":\"plg_fields_sql\",\"type\":\"plugin\",\"creationDate\":\"March 2016\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.7.0\",\"description\":\"PLG_FIELDS_SQL_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"sql\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(472, 0, 'plg_fields_text', 'plugin', 'text', 'fields', 0, 1, 1, 0, '{\"name\":\"plg_fields_text\",\"type\":\"plugin\",\"creationDate\":\"March 2016\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.7.0\",\"description\":\"PLG_FIELDS_TEXT_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"text\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(473, 0, 'plg_fields_textarea', 'plugin', 'textarea', 'fields', 0, 1, 1, 0, '{\"name\":\"plg_fields_textarea\",\"type\":\"plugin\",\"creationDate\":\"March 2016\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.7.0\",\"description\":\"PLG_FIELDS_TEXTAREA_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"textarea\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(474, 0, 'plg_fields_url', 'plugin', 'url', 'fields', 0, 1, 1, 0, '{\"name\":\"plg_fields_url\",\"type\":\"plugin\",\"creationDate\":\"March 2016\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.7.0\",\"description\":\"PLG_FIELDS_URL_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"url\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(475, 0, 'plg_fields_user', 'plugin', 'user', 'fields', 0, 1, 1, 0, '{\"name\":\"plg_fields_user\",\"type\":\"plugin\",\"creationDate\":\"March 2016\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.7.0\",\"description\":\"PLG_FIELDS_USER_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"user\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(476, 0, 'plg_fields_usergrouplist', 'plugin', 'usergrouplist', 'fields', 0, 1, 1, 0, '{\"name\":\"plg_fields_usergrouplist\",\"type\":\"plugin\",\"creationDate\":\"March 2016\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.7.0\",\"description\":\"PLG_FIELDS_USERGROUPLIST_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"usergrouplist\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(477, 0, 'plg_content_fields', 'plugin', 'fields', 'content', 0, 1, 1, 0, '{\"name\":\"plg_content_fields\",\"type\":\"plugin\",\"creationDate\":\"February 2017\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.7.0\",\"description\":\"PLG_CONTENT_FIELDS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"fields\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(478, 0, 'plg_editors-xtd_fields', 'plugin', 'fields', 'editors-xtd', 0, 1, 1, 0, '{\"name\":\"plg_editors-xtd_fields\",\"type\":\"plugin\",\"creationDate\":\"February 2017\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.7.0\",\"description\":\"PLG_EDITORS-XTD_FIELDS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"fields\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(479, 0, 'plg_sampledata_blog', 'plugin', 'blog', 'sampledata', 0, 1, 1, 0, '{\"name\":\"plg_sampledata_blog\",\"type\":\"plugin\",\"creationDate\":\"July 2017\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.8.0\",\"description\":\"PLG_SAMPLEDATA_BLOG_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"blog\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(480, 0, 'plg_system_sessiongc', 'plugin', 'sessiongc', 'system', 0, 1, 1, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(503, 0, 'beez3', 'template', 'beez3', '', 0, 1, 1, 0, '{\"name\":\"beez3\",\"type\":\"template\",\"creationDate\":\"25 November 2009\",\"author\":\"Angie Radtke\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters, Inc. All rights reserved.\",\"authorEmail\":\"a.radtke@derauftritt.de\",\"authorUrl\":\"http:\\/\\/www.der-auftritt.de\",\"version\":\"3.1.0\",\"description\":\"TPL_BEEZ3_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"templateDetails\"}', '{\"wrapperSmall\":\"53\",\"wrapperLarge\":\"72\",\"sitetitle\":\"\",\"sitedescription\":\"\",\"navposition\":\"center\",\"templatecolor\":\"nature\"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(504, 0, 'hathor', 'template', 'hathor', '', 1, 1, 1, 0, '{\"name\":\"hathor\",\"type\":\"template\",\"creationDate\":\"May 2010\",\"author\":\"Andrea Tarr\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters, Inc. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"\",\"version\":\"3.0.0\",\"description\":\"TPL_HATHOR_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"templateDetails\"}', '{\"showSiteName\":\"0\",\"colourChoice\":\"0\",\"boldText\":\"0\"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(506, 0, 'protostar', 'template', 'protostar', '', 0, 1, 1, 0, '{\"name\":\"protostar\",\"type\":\"template\",\"creationDate\":\"4\\/30\\/2012\",\"author\":\"Kyle Ledbetter\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters, Inc. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"\",\"version\":\"1.0\",\"description\":\"TPL_PROTOSTAR_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"templateDetails\"}', '{\"templateColor\":\"\",\"logoFile\":\"\",\"googleFont\":\"1\",\"googleFontName\":\"Open+Sans\",\"fluidContainer\":\"0\"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(507, 0, 'isis', 'template', 'isis', '', 1, 1, 1, 0, '{\"name\":\"isis\",\"type\":\"template\",\"creationDate\":\"3\\/30\\/2012\",\"author\":\"Kyle Ledbetter\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters, Inc. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"\",\"version\":\"1.0\",\"description\":\"TPL_ISIS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"templateDetails\"}', '{\"templateColor\":\"\",\"logoFile\":\"\"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(600, 802, 'English (en-GB)', 'language', 'en-GB', '', 0, 1, 1, 1, '{\"name\":\"English (en-GB)\",\"type\":\"language\",\"creationDate\":\"March 2018\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.8.6\",\"description\":\"en-GB site language\",\"group\":\"\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(601, 802, 'English (en-GB)', 'language', 'en-GB', '', 1, 1, 1, 1, '{\"name\":\"English (en-GB)\",\"type\":\"language\",\"creationDate\":\"March 2018\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.8.6\",\"description\":\"en-GB administrator language\",\"group\":\"\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(700, 0, 'files_joomla', 'file', 'joomla', '', 0, 1, 1, 1, '{\"name\":\"files_joomla\",\"type\":\"file\",\"creationDate\":\"March 2018\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2018 Open Source Matters. All rights reserved\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.8.6\",\"description\":\"FILES_JOOMLA_XML_DESCRIPTION\",\"group\":\"\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(802, 0, 'English (en-GB) Language Pack', 'package', 'pkg_en-GB', '', 0, 1, 1, 1, '{\"name\":\"English (en-GB) Language Pack\",\"type\":\"package\",\"creationDate\":\"March 2018\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2018 Open Source Matters, Inc. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.8.6.1\",\"description\":\"en-GB language pack\",\"group\":\"\",\"filename\":\"pkg_en-GB\"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10000, 10002, 'Russian', 'language', 'ru-RU', '', 0, 1, 0, 0, '{\"name\":\"Russian\",\"type\":\"language\",\"creationDate\":\"2017-11-07\",\"author\":\"Russian Translation Team\",\"copyright\":\"Copyright (C) 2005 - 2017 Open Source Matters. All rights reserved.\",\"authorEmail\":\"smart@joomlaportal.ru\",\"authorUrl\":\"www.joomlaportal.ru\",\"version\":\"3.8.2.1\",\"description\":\"Russian language pack (site) for Joomla! 3.8.2\",\"group\":\"\",\"filename\":\"install\"}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10001, 10002, 'ru-RU', 'language', 'ru-RU', '', 1, 1, 0, 0, '{\"name\":\"\\u0420\\u0443\\u0441\\u0441\\u043a\\u0438\\u0439 (ru-RU)\",\"type\":\"language\",\"creationDate\":\"2017-11-07\",\"author\":\"Russian Translation Team\",\"copyright\":\"Copyright (C) 2005 - 2017 Open Source Matters. All rights reserved.\",\"authorEmail\":\"smart@joomlaportal.ru\",\"authorUrl\":\"www.joomlaportal.ru\",\"version\":\"3.8.2.1\",\"description\":\"Russian language pack (administrator) for Joomla! 3.8.2\",\"group\":\"\",\"filename\":\"install\"}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0);
INSERT INTO `jm_extensions` (`extension_id`, `package_id`, `name`, `type`, `element`, `folder`, `client_id`, `enabled`, `access`, `protected`, `manifest_cache`, `params`, `custom_data`, `system_data`, `checked_out`, `checked_out_time`, `ordering`, `state`) VALUES
(10002, 0, 'Russian (ru-RU) Language Pack', 'package', 'pkg_ru-RU', '', 0, 1, 1, 0, '{\"name\":\"Russian (ru-RU) Language Pack\",\"type\":\"package\",\"creationDate\":\"2017-11-07\",\"author\":\"Russian Translation Team\",\"copyright\":\"Copyright (C) 2005 - 2017 Open Source Matters, Inc. All rights reserved.\",\"authorEmail\":\"smart@joomlaportal.ru\",\"authorUrl\":\"www.joomlaportal.ru\",\"version\":\"3.8.2.1\",\"description\":\"Joomla 3.8 Russian Language Package\",\"group\":\"\",\"filename\":\"pkg_ru-RU\"}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10003, 0, 'plg_installer_webinstaller', 'plugin', 'webinstaller', 'installer', 0, 1, 1, 0, '{\"name\":\"plg_installer_webinstaller\",\"type\":\"plugin\",\"creationDate\":\"28 April 2017\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2013-2017 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"1.1.1\",\"description\":\"PLG_INSTALLER_WEBINSTALLER_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"webinstaller\"}', '{\"tab_position\":\"0\"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10004, 0, 'purity_III', 'template', 'purity_iii', '', 0, 1, 1, 0, '{\"name\":\"purity_III\",\"type\":\"template\",\"creationDate\":\"19 May 2017\",\"author\":\"JoomlArt.com\",\"copyright\":\"Copyright (C), J.O.O.M Solutions Co., Ltd. All Rights Reserved.\",\"authorEmail\":\"webmaster@joomlart.com\",\"authorUrl\":\"http:\\/\\/www.t3-framework.org\",\"version\":\"1.2.0\",\"description\":\"\\n\\t\\t\\n\\t\\t<div align=\\\"center\\\">\\n\\t\\t\\t<div class=\\\"alert alert-success\\\" style=\\\"background-color:#DFF0D8;border-color:#D6E9C6;color: #468847;padding: 1px 0;\\\">\\n\\t\\t\\t\\t<h2>Purity III Template references<\\/h2>\\n\\t\\t\\t\\t<h4><a href=\\\"http:\\/\\/joomla-templates.joomlart.com\\/purity_iii\\/\\\" title=\\\"Purity III Template demo\\\">Live Demo<\\/a> | <a href=\\\"http:\\/\\/www.joomlart.com\\/documentation\\/joomla-templates\\/purity-iii\\\" title=\\\"purity iii template documentation\\\">Documentation<\\/a> | <a href=\\\"http:\\/\\/www.joomlart.com\\/forums\\/forumdisplay.php?542-Purity-III\\\" title=\\\"purity iii forum\\\">Forum<\\/a> | <a href=\\\"http:\\/\\/www.joomlart.com\\/joomla\\/templates\\/purity-iii\\\" title=\\\"Purity III template more info\\\">More Info<\\/a><\\/h4>\\n\\t\\t\\t\\t<p> <\\/p>\\n\\t\\t\\t\\t<span style=\\\"color:#FF0000\\\">Note: Purity III requires T3 plugin to be installed and enabled.<\\/span>\\n\\t\\t\\t\\t<p> <\\/p>\\n\\t\\t\\t\\t<p>Copyright 2004 - 2017 <a href=\'http:\\/\\/www.joomlart.com\\/\' title=\'Visit Joomlart.com!\'>JoomlArt.com<\\/a>.<\\/p>\\n\\t\\t\\t<\\/div>\\n\\t\\t\\t<style>table.adminform{width: 100%;}<\\/style>\\n\\t\\t<\\/div>\\n\\t\\t\\n\\t\",\"group\":\"\",\"filename\":\"templateDetails\"}', '{\"tpl_article_info_datetime_format\":\"d M Y\"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10005, 0, 'T3 Framework', 'plugin', 't3', 'system', 0, 1, 1, 0, '{\"name\":\"T3 Framework\",\"type\":\"plugin\",\"creationDate\":\"July 21, 2017\",\"author\":\"JoomlArt.com\",\"copyright\":\"Copyright (C) 2005 - 2017 Open Source Matters. All rights reserved.\",\"authorEmail\":\"info@joomlart.com\",\"authorUrl\":\"http:\\/\\/www.t3-framework.org\",\"version\":\"2.6.6\",\"description\":\"\\n\\t\\n\\t<div align=\\\"center\\\">\\n\\t\\t<div class=\\\"alert alert-success\\\" style=\\\"background-color:#DFF0D8;border-color:#D6E9C6;color: #468847;padding: 1px 0;\\\">\\n\\t\\t\\t\\t<a href=\\\"http:\\/\\/t3-framework.org\\/\\\"><img src=\\\"http:\\/\\/static.joomlart.com\\/images\\/jat3v3-documents\\/message-installation\\/logo.png\\\" alt=\\\"some_text\\\" width=\\\"300\\\" height=\\\"99\\\"><\\/a>\\n\\t\\t\\t\\t<h4><a href=\\\"http:\\/\\/t3-framework.org\\/\\\" title=\\\"\\\">Home<\\/a> | <a href=\\\"http:\\/\\/demo.t3-framework.org\\/\\\" title=\\\"\\\">Demo<\\/a> | <a href=\\\"http:\\/\\/t3-framework.org\\/documentation\\\" title=\\\"\\\">Document<\\/a> | <a href=\\\"https:\\/\\/github.com\\/t3framework\\/t3\\/blob\\/master\\/CHANGELOG.md\\\" title=\\\"\\\">Changelog<\\/a><\\/h4>\\n\\t\\t<p> <\\/p>\\n\\t\\t<p>Copyright 2004 - 2017 <a href=\'http:\\/\\/www.joomlart.com\\/\' title=\'Visit Joomlart.com!\'>JoomlArt.com<\\/a>.<\\/p>\\n\\t\\t<\\/div>\\n     <style>table.adminform{width: 100%;}<\\/style>\\n\\t <\\/div>\\n\\t\\t\\n\\t\",\"group\":\"\",\"filename\":\"t3\"}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `jm_fields`
--
-- Создание: Мар 30 2018 г., 11:27
--

DROP TABLE IF EXISTS `jm_fields`;
CREATE TABLE `jm_fields` (
  `id` int(10) UNSIGNED NOT NULL,
  `asset_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `context` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `group_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `default_value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'text',
  `note` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` tinyint(1) NOT NULL DEFAULT '0',
  `required` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(11) NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `params` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `fieldparams` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `language` char(7) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `created_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_user_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `modified_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `access` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `jm_fields_categories`
--
-- Создание: Мар 30 2018 г., 11:27
--

DROP TABLE IF EXISTS `jm_fields_categories`;
CREATE TABLE `jm_fields_categories` (
  `field_id` int(11) NOT NULL DEFAULT '0',
  `category_id` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `jm_fields_groups`
--
-- Создание: Мар 30 2018 г., 11:27
--

DROP TABLE IF EXISTS `jm_fields_groups`;
CREATE TABLE `jm_fields_groups` (
  `id` int(10) UNSIGNED NOT NULL,
  `asset_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `context` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `note` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(11) NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `params` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `language` char(7) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `access` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `jm_fields_values`
--
-- Создание: Мар 30 2018 г., 11:27
--

DROP TABLE IF EXISTS `jm_fields_values`;
CREATE TABLE `jm_fields_values` (
  `field_id` int(10) UNSIGNED NOT NULL,
  `item_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Allow references to items which have strings as ids, eg. none db systems.',
  `value` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `jm_finder_filters`
--
-- Создание: Мар 30 2018 г., 11:27
--

DROP TABLE IF EXISTS `jm_finder_filters`;
CREATE TABLE `jm_finder_filters` (
  `filter_id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `state` tinyint(1) NOT NULL DEFAULT '1',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) UNSIGNED NOT NULL,
  `created_by_alias` varchar(255) NOT NULL,
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `checked_out` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `map_count` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `data` text NOT NULL,
  `params` mediumtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Структура таблицы `jm_finder_links`
--
-- Создание: Мар 30 2018 г., 11:27
--

DROP TABLE IF EXISTS `jm_finder_links`;
CREATE TABLE `jm_finder_links` (
  `link_id` int(10) UNSIGNED NOT NULL,
  `url` varchar(255) NOT NULL,
  `route` varchar(255) NOT NULL,
  `title` varchar(400) DEFAULT NULL,
  `description` text,
  `indexdate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `md5sum` varchar(32) DEFAULT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '1',
  `state` int(5) DEFAULT '1',
  `access` int(5) DEFAULT '0',
  `language` varchar(8) NOT NULL,
  `publish_start_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_end_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `start_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `end_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `list_price` double UNSIGNED NOT NULL DEFAULT '0',
  `sale_price` double UNSIGNED NOT NULL DEFAULT '0',
  `type_id` int(11) NOT NULL,
  `object` mediumblob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Структура таблицы `jm_finder_links_terms0`
--
-- Создание: Мар 30 2018 г., 11:27
--

DROP TABLE IF EXISTS `jm_finder_links_terms0`;
CREATE TABLE `jm_finder_links_terms0` (
  `link_id` int(10) UNSIGNED NOT NULL,
  `term_id` int(10) UNSIGNED NOT NULL,
  `weight` float UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Структура таблицы `jm_finder_links_terms1`
--
-- Создание: Мар 30 2018 г., 11:27
--

DROP TABLE IF EXISTS `jm_finder_links_terms1`;
CREATE TABLE `jm_finder_links_terms1` (
  `link_id` int(10) UNSIGNED NOT NULL,
  `term_id` int(10) UNSIGNED NOT NULL,
  `weight` float UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Структура таблицы `jm_finder_links_terms2`
--
-- Создание: Мар 30 2018 г., 11:27
--

DROP TABLE IF EXISTS `jm_finder_links_terms2`;
CREATE TABLE `jm_finder_links_terms2` (
  `link_id` int(10) UNSIGNED NOT NULL,
  `term_id` int(10) UNSIGNED NOT NULL,
  `weight` float UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Структура таблицы `jm_finder_links_terms3`
--
-- Создание: Мар 30 2018 г., 11:27
--

DROP TABLE IF EXISTS `jm_finder_links_terms3`;
CREATE TABLE `jm_finder_links_terms3` (
  `link_id` int(10) UNSIGNED NOT NULL,
  `term_id` int(10) UNSIGNED NOT NULL,
  `weight` float UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Структура таблицы `jm_finder_links_terms4`
--
-- Создание: Мар 30 2018 г., 11:27
--

DROP TABLE IF EXISTS `jm_finder_links_terms4`;
CREATE TABLE `jm_finder_links_terms4` (
  `link_id` int(10) UNSIGNED NOT NULL,
  `term_id` int(10) UNSIGNED NOT NULL,
  `weight` float UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Структура таблицы `jm_finder_links_terms5`
--
-- Создание: Мар 30 2018 г., 11:27
--

DROP TABLE IF EXISTS `jm_finder_links_terms5`;
CREATE TABLE `jm_finder_links_terms5` (
  `link_id` int(10) UNSIGNED NOT NULL,
  `term_id` int(10) UNSIGNED NOT NULL,
  `weight` float UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Структура таблицы `jm_finder_links_terms6`
--
-- Создание: Мар 30 2018 г., 11:27
--

DROP TABLE IF EXISTS `jm_finder_links_terms6`;
CREATE TABLE `jm_finder_links_terms6` (
  `link_id` int(10) UNSIGNED NOT NULL,
  `term_id` int(10) UNSIGNED NOT NULL,
  `weight` float UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Структура таблицы `jm_finder_links_terms7`
--
-- Создание: Мар 30 2018 г., 11:27
--

DROP TABLE IF EXISTS `jm_finder_links_terms7`;
CREATE TABLE `jm_finder_links_terms7` (
  `link_id` int(10) UNSIGNED NOT NULL,
  `term_id` int(10) UNSIGNED NOT NULL,
  `weight` float UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Структура таблицы `jm_finder_links_terms8`
--
-- Создание: Мар 30 2018 г., 11:27
--

DROP TABLE IF EXISTS `jm_finder_links_terms8`;
CREATE TABLE `jm_finder_links_terms8` (
  `link_id` int(10) UNSIGNED NOT NULL,
  `term_id` int(10) UNSIGNED NOT NULL,
  `weight` float UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Структура таблицы `jm_finder_links_terms9`
--
-- Создание: Мар 30 2018 г., 11:27
--

DROP TABLE IF EXISTS `jm_finder_links_terms9`;
CREATE TABLE `jm_finder_links_terms9` (
  `link_id` int(10) UNSIGNED NOT NULL,
  `term_id` int(10) UNSIGNED NOT NULL,
  `weight` float UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Структура таблицы `jm_finder_links_termsa`
--
-- Создание: Мар 30 2018 г., 11:27
--

DROP TABLE IF EXISTS `jm_finder_links_termsa`;
CREATE TABLE `jm_finder_links_termsa` (
  `link_id` int(10) UNSIGNED NOT NULL,
  `term_id` int(10) UNSIGNED NOT NULL,
  `weight` float UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Структура таблицы `jm_finder_links_termsb`
--
-- Создание: Мар 30 2018 г., 11:27
--

DROP TABLE IF EXISTS `jm_finder_links_termsb`;
CREATE TABLE `jm_finder_links_termsb` (
  `link_id` int(10) UNSIGNED NOT NULL,
  `term_id` int(10) UNSIGNED NOT NULL,
  `weight` float UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Структура таблицы `jm_finder_links_termsc`
--
-- Создание: Мар 30 2018 г., 11:27
--

DROP TABLE IF EXISTS `jm_finder_links_termsc`;
CREATE TABLE `jm_finder_links_termsc` (
  `link_id` int(10) UNSIGNED NOT NULL,
  `term_id` int(10) UNSIGNED NOT NULL,
  `weight` float UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Структура таблицы `jm_finder_links_termsd`
--
-- Создание: Мар 30 2018 г., 11:27
--

DROP TABLE IF EXISTS `jm_finder_links_termsd`;
CREATE TABLE `jm_finder_links_termsd` (
  `link_id` int(10) UNSIGNED NOT NULL,
  `term_id` int(10) UNSIGNED NOT NULL,
  `weight` float UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Структура таблицы `jm_finder_links_termse`
--
-- Создание: Мар 30 2018 г., 11:27
--

DROP TABLE IF EXISTS `jm_finder_links_termse`;
CREATE TABLE `jm_finder_links_termse` (
  `link_id` int(10) UNSIGNED NOT NULL,
  `term_id` int(10) UNSIGNED NOT NULL,
  `weight` float UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Структура таблицы `jm_finder_links_termsf`
--
-- Создание: Мар 30 2018 г., 11:27
--

DROP TABLE IF EXISTS `jm_finder_links_termsf`;
CREATE TABLE `jm_finder_links_termsf` (
  `link_id` int(10) UNSIGNED NOT NULL,
  `term_id` int(10) UNSIGNED NOT NULL,
  `weight` float UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Структура таблицы `jm_finder_taxonomy`
--
-- Создание: Мар 30 2018 г., 11:27
--

DROP TABLE IF EXISTS `jm_finder_taxonomy`;
CREATE TABLE `jm_finder_taxonomy` (
  `id` int(10) UNSIGNED NOT NULL,
  `parent_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `state` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `access` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `ordering` tinyint(1) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `jm_finder_taxonomy`
--

INSERT INTO `jm_finder_taxonomy` (`id`, `parent_id`, `title`, `state`, `access`, `ordering`) VALUES
(1, 0, 'ROOT', 0, 0, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `jm_finder_taxonomy_map`
--
-- Создание: Мар 30 2018 г., 11:27
--

DROP TABLE IF EXISTS `jm_finder_taxonomy_map`;
CREATE TABLE `jm_finder_taxonomy_map` (
  `link_id` int(10) UNSIGNED NOT NULL,
  `node_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Структура таблицы `jm_finder_terms`
--
-- Создание: Мар 30 2018 г., 11:27
--

DROP TABLE IF EXISTS `jm_finder_terms`;
CREATE TABLE `jm_finder_terms` (
  `term_id` int(10) UNSIGNED NOT NULL,
  `term` varchar(75) NOT NULL,
  `stem` varchar(75) NOT NULL,
  `common` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `phrase` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `weight` float UNSIGNED NOT NULL DEFAULT '0',
  `soundex` varchar(75) NOT NULL,
  `links` int(10) NOT NULL DEFAULT '0',
  `language` char(3) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Структура таблицы `jm_finder_terms_common`
--
-- Создание: Мар 30 2018 г., 11:27
--

DROP TABLE IF EXISTS `jm_finder_terms_common`;
CREATE TABLE `jm_finder_terms_common` (
  `term` varchar(75) NOT NULL,
  `language` varchar(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `jm_finder_terms_common`
--

INSERT INTO `jm_finder_terms_common` (`term`, `language`) VALUES
('a', 'en'),
('about', 'en'),
('after', 'en'),
('ago', 'en'),
('all', 'en'),
('am', 'en'),
('an', 'en'),
('and', 'en'),
('any', 'en'),
('are', 'en'),
('aren\'t', 'en'),
('as', 'en'),
('at', 'en'),
('be', 'en'),
('but', 'en'),
('by', 'en'),
('for', 'en'),
('from', 'en'),
('get', 'en'),
('go', 'en'),
('how', 'en'),
('if', 'en'),
('in', 'en'),
('into', 'en'),
('is', 'en'),
('isn\'t', 'en'),
('it', 'en'),
('its', 'en'),
('me', 'en'),
('more', 'en'),
('most', 'en'),
('must', 'en'),
('my', 'en'),
('new', 'en'),
('no', 'en'),
('none', 'en'),
('not', 'en'),
('nothing', 'en'),
('of', 'en'),
('off', 'en'),
('often', 'en'),
('old', 'en'),
('on', 'en'),
('onc', 'en'),
('once', 'en'),
('only', 'en'),
('or', 'en'),
('other', 'en'),
('our', 'en'),
('ours', 'en'),
('out', 'en'),
('over', 'en'),
('page', 'en'),
('she', 'en'),
('should', 'en'),
('small', 'en'),
('so', 'en'),
('some', 'en'),
('than', 'en'),
('thank', 'en'),
('that', 'en'),
('the', 'en'),
('their', 'en'),
('theirs', 'en'),
('them', 'en'),
('then', 'en'),
('there', 'en'),
('these', 'en'),
('they', 'en'),
('this', 'en'),
('those', 'en'),
('thus', 'en'),
('time', 'en'),
('times', 'en'),
('to', 'en'),
('too', 'en'),
('true', 'en'),
('under', 'en'),
('until', 'en'),
('up', 'en'),
('upon', 'en'),
('use', 'en'),
('user', 'en'),
('users', 'en'),
('version', 'en'),
('very', 'en'),
('via', 'en'),
('want', 'en'),
('was', 'en'),
('way', 'en'),
('were', 'en'),
('what', 'en'),
('when', 'en'),
('where', 'en'),
('which', 'en'),
('who', 'en'),
('whom', 'en'),
('whose', 'en'),
('why', 'en'),
('wide', 'en'),
('will', 'en'),
('with', 'en'),
('within', 'en'),
('without', 'en'),
('would', 'en'),
('yes', 'en'),
('yet', 'en'),
('you', 'en'),
('your', 'en'),
('yours', 'en');

-- --------------------------------------------------------

--
-- Структура таблицы `jm_finder_tokens`
--
-- Создание: Апр 09 2018 г., 06:38
--

DROP TABLE IF EXISTS `jm_finder_tokens`;
CREATE TABLE `jm_finder_tokens` (
  `term` varchar(75) NOT NULL,
  `stem` varchar(75) NOT NULL,
  `common` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `phrase` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `weight` float UNSIGNED NOT NULL DEFAULT '1',
  `context` tinyint(1) UNSIGNED NOT NULL DEFAULT '2',
  `language` char(3) NOT NULL DEFAULT ''
) ENGINE=MEMORY DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Структура таблицы `jm_finder_tokens_aggregate`
--
-- Создание: Апр 09 2018 г., 06:38
--

DROP TABLE IF EXISTS `jm_finder_tokens_aggregate`;
CREATE TABLE `jm_finder_tokens_aggregate` (
  `term_id` int(10) UNSIGNED NOT NULL,
  `map_suffix` char(1) NOT NULL,
  `term` varchar(75) NOT NULL,
  `stem` varchar(75) NOT NULL,
  `common` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `phrase` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `term_weight` float UNSIGNED NOT NULL,
  `context` tinyint(1) UNSIGNED NOT NULL DEFAULT '2',
  `context_weight` float UNSIGNED NOT NULL,
  `total_weight` float UNSIGNED NOT NULL,
  `language` char(3) NOT NULL DEFAULT ''
) ENGINE=MEMORY DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Структура таблицы `jm_finder_types`
--
-- Создание: Мар 30 2018 г., 11:27
--

DROP TABLE IF EXISTS `jm_finder_types`;
CREATE TABLE `jm_finder_types` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(100) NOT NULL,
  `mime` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Структура таблицы `jm_languages`
--
-- Создание: Мар 30 2018 г., 11:27
--

DROP TABLE IF EXISTS `jm_languages`;
CREATE TABLE `jm_languages` (
  `lang_id` int(11) UNSIGNED NOT NULL,
  `asset_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `lang_code` char(7) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `title` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_native` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sef` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(512) COLLATE utf8mb4_unicode_ci NOT NULL,
  `metakey` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `metadesc` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `sitename` varchar(1024) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `published` int(11) NOT NULL DEFAULT '0',
  `access` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `jm_languages`
--

INSERT INTO `jm_languages` (`lang_id`, `asset_id`, `lang_code`, `title`, `title_native`, `sef`, `image`, `description`, `metakey`, `metadesc`, `sitename`, `published`, `access`, `ordering`) VALUES
(1, 0, 'en-GB', 'English (en-GB)', 'English (United Kingdom)', 'en', 'en_gb', '', '', '', '', 1, 1, 2),
(2, 63, 'ru-RU', 'Русский (Россия)', 'Russian (Russia)', 'ru', 'ru_ru', '', '', '', '', 1, 1, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `jm_menu`
--
-- Создание: Мар 30 2018 г., 11:27
-- Последнее обновление: Апр 11 2018 г., 08:40
--

DROP TABLE IF EXISTS `jm_menu`;
CREATE TABLE `jm_menu` (
  `id` int(11) NOT NULL,
  `menutype` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The type of menu this item belongs to. FK to #__menu_types.menutype',
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The display title of the menu item.',
  `alias` varchar(400) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT 'The SEF alias of the menu item.',
  `note` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `path` varchar(1024) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The computed path of the menu item based on the alias field.',
  `link` varchar(1024) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The actually link the menu item refers to.',
  `type` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The type of link: Component, URL, Alias, Separator',
  `published` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'The published state of the menu link.',
  `parent_id` int(10) UNSIGNED NOT NULL DEFAULT '1' COMMENT 'The parent menu item in the menu tree.',
  `level` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'The relative level in the tree.',
  `component_id` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'FK to #__extensions.id',
  `checked_out` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'FK to #__users.id',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'The time the menu item was checked out.',
  `browserNav` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'The click behaviour of the link.',
  `access` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'The access level required to view the menu item.',
  `img` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The image of the menu item.',
  `template_style_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `params` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'JSON encoded data for the menu item.',
  `lft` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set lft.',
  `rgt` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set rgt.',
  `home` tinyint(3) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'Indicates if this menu item is the home or default page.',
  `language` char(7) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `client_id` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `jm_menu`
--

INSERT INTO `jm_menu` (`id`, `menutype`, `title`, `alias`, `note`, `path`, `link`, `type`, `published`, `parent_id`, `level`, `component_id`, `checked_out`, `checked_out_time`, `browserNav`, `access`, `img`, `template_style_id`, `params`, `lft`, `rgt`, `home`, `language`, `client_id`) VALUES
(1, '', 'Menu_Item_Root', 'root', '', '', '', '', 1, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, 0, '', 0, '', 0, 57, 0, '*', 0),
(2, 'main', 'com_banners', 'Banners', '', 'Banners', 'index.php?option=com_banners', 'component', 1, 1, 1, 4, 0, '0000-00-00 00:00:00', 0, 0, 'class:banners', 0, '', 1, 10, 0, '*', 1),
(3, 'main', 'com_banners', 'Banners', '', 'Banners/Banners', 'index.php?option=com_banners', 'component', 1, 2, 2, 4, 0, '0000-00-00 00:00:00', 0, 0, 'class:banners', 0, '', 2, 3, 0, '*', 1),
(4, 'main', 'com_banners_categories', 'Categories', '', 'Banners/Categories', 'index.php?option=com_categories&extension=com_banners', 'component', 1, 2, 2, 6, 0, '0000-00-00 00:00:00', 0, 0, 'class:banners-cat', 0, '', 4, 5, 0, '*', 1),
(5, 'main', 'com_banners_clients', 'Clients', '', 'Banners/Clients', 'index.php?option=com_banners&view=clients', 'component', 1, 2, 2, 4, 0, '0000-00-00 00:00:00', 0, 0, 'class:banners-clients', 0, '', 6, 7, 0, '*', 1),
(6, 'main', 'com_banners_tracks', 'Tracks', '', 'Banners/Tracks', 'index.php?option=com_banners&view=tracks', 'component', 1, 2, 2, 4, 0, '0000-00-00 00:00:00', 0, 0, 'class:banners-tracks', 0, '', 8, 9, 0, '*', 1),
(7, 'main', 'com_contact', 'Contacts', '', 'Contacts', 'index.php?option=com_contact', 'component', 1, 1, 1, 8, 0, '0000-00-00 00:00:00', 0, 0, 'class:contact', 0, '', 11, 16, 0, '*', 1),
(8, 'main', 'com_contact_contacts', 'Contacts', '', 'Contacts/Contacts', 'index.php?option=com_contact', 'component', 1, 7, 2, 8, 0, '0000-00-00 00:00:00', 0, 0, 'class:contact', 0, '', 12, 13, 0, '*', 1),
(9, 'main', 'com_contact_categories', 'Categories', '', 'Contacts/Categories', 'index.php?option=com_categories&extension=com_contact', 'component', 1, 7, 2, 6, 0, '0000-00-00 00:00:00', 0, 0, 'class:contact-cat', 0, '', 14, 15, 0, '*', 1),
(10, 'main', 'com_messages', 'Messaging', '', 'Messaging', 'index.php?option=com_messages', 'component', 1, 1, 1, 15, 0, '0000-00-00 00:00:00', 0, 0, 'class:messages', 0, '', 21, 24, 0, '*', 1),
(11, 'main', 'com_messages_add', 'New Private Message', '', 'Messaging/New Private Message', 'index.php?option=com_messages&task=message.add', 'component', 1, 10, 2, 15, 0, '0000-00-00 00:00:00', 0, 0, 'class:messages-add', 0, '', 22, 23, 0, '*', 1),
(13, 'main', 'com_newsfeeds', 'News Feeds', '', 'News Feeds', 'index.php?option=com_newsfeeds', 'component', 1, 1, 1, 17, 0, '0000-00-00 00:00:00', 0, 0, 'class:newsfeeds', 0, '', 31, 36, 0, '*', 1),
(14, 'main', 'com_newsfeeds_feeds', 'Feeds', '', 'News Feeds/Feeds', 'index.php?option=com_newsfeeds', 'component', 1, 13, 2, 17, 0, '0000-00-00 00:00:00', 0, 0, 'class:newsfeeds', 0, '', 32, 33, 0, '*', 1),
(15, 'main', 'com_newsfeeds_categories', 'Categories', '', 'News Feeds/Categories', 'index.php?option=com_categories&extension=com_newsfeeds', 'component', 1, 13, 2, 6, 0, '0000-00-00 00:00:00', 0, 0, 'class:newsfeeds-cat', 0, '', 34, 35, 0, '*', 1),
(16, 'main', 'com_redirect', 'Redirect', '', 'Redirect', 'index.php?option=com_redirect', 'component', 1, 1, 1, 24, 0, '0000-00-00 00:00:00', 0, 0, 'class:redirect', 0, '', 37, 38, 0, '*', 1),
(17, 'main', 'com_search', 'Basic Search', '', 'Basic Search', 'index.php?option=com_search', 'component', 1, 1, 1, 19, 0, '0000-00-00 00:00:00', 0, 0, 'class:search', 0, '', 39, 40, 0, '*', 1),
(18, 'main', 'com_finder', 'Smart Search', '', 'Smart Search', 'index.php?option=com_finder', 'component', 1, 1, 1, 27, 0, '0000-00-00 00:00:00', 0, 0, 'class:finder', 0, '', 41, 42, 0, '*', 1),
(19, 'main', 'com_joomlaupdate', 'Joomla! Update', '', 'Joomla! Update', 'index.php?option=com_joomlaupdate', 'component', 1, 1, 1, 28, 0, '0000-00-00 00:00:00', 0, 0, 'class:joomlaupdate', 0, '', 43, 44, 0, '*', 1),
(20, 'main', 'com_tags', 'Tags', '', 'Tags', 'index.php?option=com_tags', 'component', 1, 1, 1, 29, 0, '0000-00-00 00:00:00', 0, 1, 'class:tags', 0, '', 45, 46, 0, '', 1),
(21, 'main', 'com_postinstall', 'Post-installation messages', '', 'Post-installation messages', 'index.php?option=com_postinstall', 'component', 1, 1, 1, 32, 0, '0000-00-00 00:00:00', 0, 1, 'class:postinstall', 0, '', 47, 48, 0, '*', 1),
(22, 'main', 'com_associations', 'Multilingual Associations', '', 'Multilingual Associations', 'index.php?option=com_associations', 'component', 1, 1, 1, 34, 0, '0000-00-00 00:00:00', 0, 0, 'class:associations', 0, '', 49, 50, 0, '*', 1),
(101, 'mainmenu', 'Home', 'homepage', '', 'homepage', 'index.php?option=com_content&view=article&id=1', 'component', 1, 1, 1, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{\"show_title\":\"1\",\"link_titles\":\"\",\"show_intro\":\"\",\"info_block_position\":\"0\",\"show_category\":\"0\",\"link_category\":\"0\",\"show_parent_category\":\"0\",\"link_parent_category\":\"0\",\"show_author\":\"0\",\"link_author\":\"0\",\"show_create_date\":\"0\",\"show_modify_date\":\"0\",\"show_publish_date\":\"0\",\"show_item_navigation\":\"0\",\"show_vote\":\"\",\"show_tags\":\"\",\"show_icons\":\"0\",\"show_print_icon\":\"0\",\"show_email_icon\":\"0\",\"show_hits\":\"0\",\"show_noauth\":\"\",\"urls_position\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}', 51, 52, 0, '*', 0),
(102, 'usermenu', 'Your Profile', 'your-profile', '', 'your-profile', 'index.php?option=com_users&view=profile&layout=edit', 'component', 1, 1, 1, 25, 0, '0000-00-00 00:00:00', 0, 2, '', 0, '{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}', 17, 18, 0, '*', 0),
(103, 'usermenu', 'Site Administrator', '2013-11-16-23-26-41', '', '2013-11-16-23-26-41', 'administrator', 'url', 1, 1, 1, 0, 0, '0000-00-00 00:00:00', 0, 6, '', 0, '{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1}', 25, 26, 0, '*', 0),
(104, 'usermenu', 'Submit an Article', 'submit-an-article', '', 'submit-an-article', 'index.php?option=com_content&view=form&layout=edit', 'component', 1, 1, 1, 22, 0, '0000-00-00 00:00:00', 0, 3, '', 0, '{\"enable_category\":\"0\",\"catid\":\"2\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}', 19, 20, 0, '*', 0),
(106, 'usermenu', 'Template Settings', 'template-settings', '', 'template-settings', 'index.php?option=com_config&view=templates&controller=config.display.templates', 'component', 1, 1, 1, 23, 0, '0000-00-00 00:00:00', 0, 6, '', 0, '{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}', 27, 28, 0, '*', 0),
(107, 'usermenu', 'Site Settings', 'site-settings', '', 'site-settings', 'index.php?option=com_config&view=config&controller=config.display.config', 'component', 1, 1, 1, 23, 0, '0000-00-00 00:00:00', 0, 6, '', 0, '{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}', 29, 30, 0, '*', 0),
(108, 'test', 'Моё новое меню', '2018-04-09-06-51-57', 'Моё новое меню - примечание', '2018-04-09-06-51-57', 'index.php?option=com_content&view=article&id=1', 'component', 1, 1, 1, 22, 494, '2018-04-09 07:13:10', 1, 1, ' ', 0, '{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"info_block_show_title\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_associations\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_tags\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_image_css\":\"\",\"menu_text\":1,\"menu_show\":1,\"page_title\":\"\",\"show_page_heading\":\"\",\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}', 53, 54, 0, 'en-GB', 0),
(109, 'test-menu-2', 'test menu 2', 'test-menu-2', '', 'test-menu-2', 'index.php?option=com_content&view=article&id=1', 'component', 1, 1, 1, 22, 0, '0000-00-00 00:00:00', 0, 1, ' ', 0, '{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"info_block_show_title\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_associations\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_tags\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_image_css\":\"\",\"menu_text\":1,\"menu_show\":1,\"page_title\":\"\",\"show_page_heading\":\"\",\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}', 55, 56, 1, '*', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `jm_menu_types`
--
-- Создание: Мар 30 2018 г., 11:27
-- Последнее обновление: Апр 11 2018 г., 08:37
--

DROP TABLE IF EXISTS `jm_menu_types`;
CREATE TABLE `jm_menu_types` (
  `id` int(10) UNSIGNED NOT NULL,
  `asset_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `menutype` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(48) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `client_id` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `jm_menu_types`
--

INSERT INTO `jm_menu_types` (`id`, `asset_id`, `menutype`, `title`, `description`, `client_id`) VALUES
(1, 0, 'mainmenu', 'Main Menu', 'The main menu for the site', 0),
(2, 0, 'usermenu', 'User Menu', 'A Menu for logged-in Users', 0),
(3, 66, 'test', 'Test', '', 0),
(4, 69, 'test-menu-2', 'test menu 2', 'test menu 2', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `jm_messages`
--
-- Создание: Мар 30 2018 г., 11:27
--

DROP TABLE IF EXISTS `jm_messages`;
CREATE TABLE `jm_messages` (
  `message_id` int(10) UNSIGNED NOT NULL,
  `user_id_from` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `user_id_to` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `folder_id` tinyint(3) UNSIGNED NOT NULL DEFAULT '0',
  `date_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `state` tinyint(1) NOT NULL DEFAULT '0',
  `priority` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `jm_messages_cfg`
--
-- Создание: Мар 30 2018 г., 11:27
--

DROP TABLE IF EXISTS `jm_messages_cfg`;
CREATE TABLE `jm_messages_cfg` (
  `user_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `cfg_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `cfg_value` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `jm_modules`
--
-- Создание: Мар 30 2018 г., 11:27
-- Последнее обновление: Апр 11 2018 г., 09:27
--

DROP TABLE IF EXISTS `jm_modules`;
CREATE TABLE `jm_modules` (
  `id` int(11) NOT NULL,
  `asset_id` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `title` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `note` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `ordering` int(11) NOT NULL DEFAULT '0',
  `position` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `checked_out` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `module` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `access` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `showtitle` tinyint(3) UNSIGNED NOT NULL DEFAULT '1',
  `params` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `client_id` tinyint(4) NOT NULL DEFAULT '0',
  `language` char(7) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `jm_modules`
--

INSERT INTO `jm_modules` (`id`, `asset_id`, `title`, `note`, `content`, `ordering`, `position`, `checked_out`, `checked_out_time`, `publish_up`, `publish_down`, `published`, `module`, `access`, `showtitle`, `params`, `client_id`, `language`) VALUES
(1, 39, 'Main Menu', '', '', 1, 'position-1', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_menu', 1, 1, '{\"menutype\":\"mainmenu\",\"base\":\"\",\"startLevel\":\"1\",\"endLevel\":\"0\",\"showAllChildren\":\"1\",\"tag_id\":\"\",\"class_sfx\":\" nav-pills\",\"window_open\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"_menu\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"itemid\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}', 0, '*'),
(2, 40, 'Login', '', '', 1, 'login', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_login', 1, 1, '', 1, '*'),
(3, 41, 'Popular Articles', '', '', 3, 'cpanel', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_popular', 3, 1, '{\"count\":\"5\",\"catid\":\"\",\"user_id\":\"0\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"0\"}', 1, '*'),
(4, 42, 'Recently Added Articles', '', '', 4, 'cpanel', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_latest', 3, 1, '{\"count\":\"5\",\"ordering\":\"c_dsc\",\"catid\":\"\",\"user_id\":\"0\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"0\"}', 1, '*'),
(8, 43, 'Toolbar', '', '', 1, 'toolbar', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_toolbar', 3, 1, '', 1, '*'),
(9, 44, 'Quick Icons', '', '', 1, 'icon', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_quickicon', 3, 1, '', 1, '*'),
(10, 45, 'Logged-in Users', '', '', 2, 'cpanel', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_logged', 3, 1, '{\"count\":\"5\",\"name\":\"1\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"0\"}', 1, '*'),
(12, 46, 'Admin Menu', '', '', 1, 'menu', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_menu', 3, 1, '{\"layout\":\"\",\"moduleclass_sfx\":\"\",\"shownew\":\"1\",\"showhelp\":\"1\",\"cache\":\"0\"}', 1, '*'),
(13, 47, 'Admin Submenu', '', '', 1, 'submenu', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_submenu', 3, 1, '', 1, '*'),
(14, 48, 'User Status', '', '', 2, 'status', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_status', 3, 1, '', 1, '*'),
(15, 49, 'Title', '', '', 1, 'title', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_title', 3, 1, '', 1, '*'),
(16, 50, 'Login Form', '', '', 7, 'position-7', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_login', 1, 1, '{\"greeting\":\"1\",\"name\":\"0\"}', 0, '*'),
(17, 51, 'Breadcrumbs', '', '', 1, 'position-2', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_breadcrumbs', 1, 1, '{\"moduleclass_sfx\":\"\",\"showHome\":\"1\",\"homeText\":\"\",\"showComponent\":\"1\",\"separator\":\"\",\"cache\":\"0\",\"cache_time\":\"0\",\"cachemode\":\"itemid\"}', 0, '*'),
(79, 52, 'Multilanguage status', '', '', 1, 'status', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_multilangstatus', 3, 1, '{\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"0\"}', 1, '*'),
(86, 53, 'Joomla Version', '', '', 1, 'footer', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_version', 3, 1, '{\"format\":\"short\",\"product\":\"1\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"0\"}', 1, '*'),
(87, 54, 'Popular Tags', '', '', 1, 'position-7', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_tags_popular', 1, 1, '{\"maximum\":\"10\",\"timeframe\":\"alltime\",\"order_value\":\"count\",\"order_direction\":\"1\",\"display_count\":0,\"no_results_text\":\"0\",\"minsize\":1,\"maxsize\":2,\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"owncache\":\"1\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}', 0, '*'),
(88, 55, 'Site Information', '', '', 3, 'cpanel', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_stats_admin', 3, 1, '{\"serverinfo\":\"1\",\"siteinfo\":\"1\",\"counter\":\"0\",\"increase\":\"0\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}', 1, '*'),
(89, 56, 'Release News', '', '', 0, 'postinstall', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_feed', 1, 1, '{\"rssurl\":\"https:\\/\\/www.joomla.org\\/announcements\\/release-news.feed\",\"rssrtl\":\"0\",\"rsstitle\":\"1\",\"rssdesc\":\"1\",\"rssimage\":\"1\",\"rssitems\":\"3\",\"rssitemdesc\":\"1\",\"word_count\":\"0\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}', 1, '*'),
(90, 57, 'Latest Articles', '', '', 1, 'position-7', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_articles_latest', 1, 1, '{\"catid\":[\"\"],\"count\":\"5\",\"show_featured\":\"\",\"ordering\":\"c_dsc\",\"user_id\":\"0\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}', 0, '*'),
(91, 58, 'User Menu', '', '', 3, 'position-7', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_menu', 1, 1, '{\"menutype\":\"usermenu\",\"base\":\"\",\"startLevel\":\"1\",\"endLevel\":\"0\",\"showAllChildren\":\"1\",\"tag_id\":\"\",\"class_sfx\":\"\",\"window_open\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"_menu\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"itemid\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}', 0, '*'),
(92, 59, 'Image Module', '', '<p><img src=\"images/headers/blue-flower.jpg\" alt=\"Blue Flower\" /></p>', 0, 'position-3', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 0, '{\"prepare_content\":\"1\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}', 0, '*'),
(93, 60, 'Search', '', '', 0, 'position-0', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_search', 1, 1, '{\"label\":\"\",\"width\":\"20\",\"text\":\"\",\"button\":\"0\",\"button_pos\":\"right\",\"imagebutton\":\"1\",\"button_text\":\"\",\"opensearch\":\"1\",\"opensearch_title\":\"\",\"set_itemid\":\"0\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"itemid\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}', 0, '*'),
(94, 67, 'new test menu', '', '', 1, 'banner', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_menu', 1, 0, '{\"menutype\":\"test\",\"base\":\"\",\"startLevel\":\"1\",\"endLevel\":\"0\",\"showAllChildren\":\"1\",\"tag_id\":\"\",\"class_sfx\":\"\",\"window_open\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"itemid\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}', 0, '*'),
(95, 68, 'Навигатор сайта (хлебные крошки)', '', '', 1, 'banner', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_breadcrumbs', 1, 0, '{\"showHere\":\"0\",\"showHome\":\"1\",\"homeText\":\"\\u041a\\u0430\\u0442\\u0430\\u043b\\u043e\\u0433\",\"showLast\":\"1\",\"separator\":\"U+2744\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"0\",\"cache_time\":\"0\",\"cachemode\":\"itemid\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}', 0, '*'),
(96, 70, 'test menu 2', '', '', 1, '', 0, '0000-00-00 00:00:00', '2018-04-11 08:49:19', '0000-00-00 00:00:00', -2, 'mod_menu', 1, 1, '{\"menutype\":\"test-menu-2\",\"base\":\"\",\"startLevel\":\"1\",\"endLevel\":\"0\",\"showAllChildren\":\"1\",\"tag_id\":\"\",\"class_sfx\":\"\",\"window_open\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"itemid\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}', 0, '*'),
(97, 71, 'HTML-код', '', '<h1>HTML-код h1</h1>\r\n<p>paragraph</p>', 4, 'banner', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 1, '{\"prepare_content\":\"0\",\"backgroundimage\":\"images\\/pexels-photo-457881.jpeg\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"testhtml\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"8\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}', 0, '*'),
(98, 72, 'rss korr', '', '', 1, 'banner', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_feed', 1, 1, '{\"rssurl\":\"http:\\/\\/k.img.com.ua\\/rss\\/ru\\/all_news2.0.xml\",\"rssrtl\":\"0\",\"rsstitle\":\"1\",\"rssdesc\":\"1\",\"rssimage\":\"1\",\"rssitems\":\"3\",\"rssitemdesc\":\"1\",\"word_count\":\"0\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}', 0, '*'),
(99, 73, 'banner', '', '', 1, 'banner', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_banners', 1, 1, '{\"target\":\"0\",\"count\":5,\"cid\":\"0\",\"catid\":[\"\"],\"tag_search\":\"1\",\"ordering\":\"0\",\"header_text\":\"\",\"footer_text\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}', 0, '*'),
(100, 74, 'enter here', '', '', 1, 'banner', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_login', 1, 1, '{\"pretext\":\"hi\",\"posttext\":\"by\",\"login\":\"102\",\"logout\":\"101\",\"greeting\":\"1\",\"name\":\"0\",\"profilelink\":\"0\",\"usesecure\":\"0\",\"usetext\":\"0\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"0\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}', 0, '*'),
(101, 75, 'kategorii', '', '', 1, 'banner', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_articles_categories', 1, 1, '{\"parent\":\"2\",\"show_description\":\"1\",\"numitems\":\"1\",\"show_children\":\"1\",\"count\":\"0\",\"maxlevel\":\"0\",\"layout\":\"_:default\",\"item_heading\":\"4\",\"moduleclass_sfx\":\"\",\"owncache\":\"1\",\"cache_time\":\"900\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}', 0, '*'),
(102, 76, 'who is here', '', '', 1, 'banner', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_whosonline', 1, 1, '{\"showmode\":\"0\",\"filter_groups\":\"0\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"0\",\"cache_time\":\"900\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}', 0, '*'),
(103, 77, 'rssssssssssssss', '', '', 1, 'banner', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_syndicate', 1, 1, '{\"display_text\":1,\"text\":\"rss of this page\",\"format\":\"rss\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"0\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}', 0, '*'),
(104, 78, 'archive', '', '', 1, 'banner', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_articles_archive', 1, 1, '{\"count\":\"10\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}', 0, '*'),
(105, 79, 'news', '', '', 11, 'banner', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_articles_news', 1, 1, '{\"catid\":[\"2\"],\"tag\":[\"2\"],\"image\":\"1\",\"item_title\":\"1\",\"link_titles\":\"\",\"item_heading\":\"h4\",\"triggerevents\":\"1\",\"showLastSeparator\":\"1\",\"show_introtext\":\"1\",\"readmore\":\"1\",\"count\":\"5\",\"show_featured\":\"\",\"ordering\":\"a.publish_up\",\"direction\":\"1\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"itemid\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}', 0, '*'),
(106, 80, 'last news', '', '', 1, 'banner', 494, '2018-04-11 09:17:08', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_articles_latest', 1, 1, '{\"catid\":[\"\"],\"count\":\"5\",\"show_featured\":\"\",\"ordering\":\"c_dsc\",\"user_id\":\"0\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}', 0, '*'),
(107, 81, 'most readeble', '', '', 1, 'banner', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_articles_popular', 1, 1, '{\"catid\":[\"\"],\"count\":\"5\",\"show_front\":\"1\",\"date_filtering\":\"off\",\"date_field\":\"a.created\",\"start_date_range\":\"\",\"end_date_range\":\"\",\"relative_date\":\"30\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}', 0, '*'),
(108, 82, 'the same', '', '', 1, 'banner', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_related_items', 1, 1, '{\"showDate\":\"1\",\"maximum\":\"5\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"owncache\":\"1\",\"cache_time\":\"900\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}', 0, '*'),
(109, 83, 'kateg', '', '', 14, 'banner', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_articles_category', 1, 1, '{\"mode\":\"normal\",\"show_on_article_page\":\"1\",\"count\":\"0\",\"show_front\":\"show\",\"category_filtering_type\":\"1\",\"catid\":[\"\"],\"show_child_category_articles\":\"0\",\"levels\":\"1\",\"filter_tag\":\"\",\"author_filtering_type\":\"1\",\"created_by\":[\"\"],\"author_alias_filtering_type\":\"1\",\"created_by_alias\":[\"\"],\"excluded_articles\":\"\",\"date_filtering\":\"off\",\"date_field\":\"a.created\",\"start_date_range\":\"\",\"end_date_range\":\"\",\"relative_date\":\"30\",\"article_ordering\":\"a.title\",\"article_ordering_direction\":\"ASC\",\"article_grouping\":\"none\",\"article_grouping_direction\":\"ksort\",\"month_year_format\":\"F Y\",\"link_titles\":\"1\",\"show_date\":\"0\",\"show_date_field\":\"created\",\"show_date_format\":\"Y-m-d H:i:s\",\"show_category\":\"0\",\"show_hits\":\"0\",\"show_author\":\"0\",\"show_introtext\":\"0\",\"introtext_limit\":\"100\",\"show_readmore\":\"0\",\"show_readmore_title\":\"1\",\"readmore_limit\":\"15\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"owncache\":\"1\",\"cache_time\":\"900\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}', 0, '*'),
(110, 84, 'footer 2', '', '', 15, 'banner', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_footer', 1, 1, '{\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}', 0, '*'),
(111, 85, 'last users registered', '', '', 16, 'banner', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_users_latest', 1, 1, '{\"shownumber\":\"5\",\"filter_groups\":\"0\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}', 0, '*'),
(112, 86, 'wrapper', '', '', 17, 'banner', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_wrapper', 1, 1, '{\"url\":\"http:\\/\\/klava.org\\/#eng_basic\",\"add\":\"1\",\"scrolling\":\"auto\",\"width\":\"100%\",\"height\":\"400\",\"height_auto\":\"1\",\"frameborder\":\"1\",\"target\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}', 0, '*'),
(113, 87, 'languages', '', '', 18, 'banner', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_languages', 1, 1, '{\"header_text\":\"start\",\"footer_text\":\"finish\",\"dropdown\":\"1\",\"dropdownimage\":\"1\",\"lineheight\":\"0\",\"image\":\"1\",\"show_active\":\"1\",\"full_name\":\"1\",\"inline\":\"1\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"0\",\"cache_time\":\"900\",\"cachemode\":\"itemid\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}', 0, '*'),
(114, 88, 'search here', '', '', 19, 'banner', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_search', 1, 1, '{\"label\":\"aa\",\"width\":\"29\",\"text\":\"asdsd\",\"button\":\"1\",\"button_pos\":\"bottom\",\"imagebutton\":\"0\",\"button_text\":\"butt\",\"opensearch\":\"1\",\"opensearch_title\":\"\",\"set_itemid\":\"0\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"itemid\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}', 0, '*'),
(115, 89, 'popular tags', '', '', 20, 'banner', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_tags_popular', 1, 1, '{\"parentTag\":[\"2\"],\"maximum\":\"5\",\"timeframe\":\"alltime\",\"order_value\":\"count\",\"order_direction\":\"1\",\"display_count\":1,\"no_results_text\":\"1\",\"minsize\":1,\"maxsize\":2,\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"owncache\":\"1\",\"cache_time\":\"900\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}', 0, '*'),
(116, 90, 'the same tags', '', '', 20, 'banner', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_tags_similar', 1, 1, '{\"maximum\":\"5\",\"matchtype\":\"any\",\"ordering\":\"count\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"owncache\":\"1\",\"cache_time\":\"900\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}', 0, '*'),
(117, 91, 'random img', '', '', 20, 'banner', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_random_image', 1, 1, '{\"type\":\"jpg\",\"folder\":\"img\",\"link\":\"\",\"width\":\"\",\"height\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"0\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}', 0, '*'),
(118, 92, 'statistic', '', '', 20, 'banner', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_stats', 1, 1, '{\"serverinfo\":\"1\",\"siteinfo\":\"1\",\"counter\":\"1\",\"increase\":\"0\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}', 0, '*'),
(119, 93, 'search good', '', '', 20, 'banner', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_finder', 1, 1, '{\"searchfilter\":\"\",\"show_autosuggest\":\"1\",\"show_advanced\":\"0\",\"field_size\":25,\"show_label\":\"1\",\"label_pos\":\"left\",\"alt_label\":\"\",\"show_button\":\"0\",\"button_pos\":\"left\",\"opensearch\":\"1\",\"opensearch_title\":\"\",\"set_itemid\":\"0\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}', 0, '*');

-- --------------------------------------------------------

--
-- Структура таблицы `jm_modules_menu`
--
-- Создание: Мар 30 2018 г., 11:27
-- Последнее обновление: Апр 11 2018 г., 09:27
--

DROP TABLE IF EXISTS `jm_modules_menu`;
CREATE TABLE `jm_modules_menu` (
  `moduleid` int(11) NOT NULL DEFAULT '0',
  `menuid` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `jm_modules_menu`
--

INSERT INTO `jm_modules_menu` (`moduleid`, `menuid`) VALUES
(1, 0),
(2, 0),
(3, 0),
(4, 0),
(6, 0),
(7, 0),
(8, 0),
(9, 0),
(10, 0),
(12, 0),
(13, 0),
(14, 0),
(15, 0),
(16, 0),
(17, 0),
(79, 0),
(86, 0),
(87, 0),
(88, 0),
(89, 0),
(90, 0),
(91, 0),
(92, 0),
(93, 0),
(94, 0),
(95, 0),
(96, 0),
(97, 0),
(98, 0),
(99, 0),
(100, 0),
(101, 0),
(102, 0),
(103, 0),
(104, 0),
(105, 0),
(106, 0),
(107, 0),
(108, 0),
(109, 0),
(110, 0),
(111, 0),
(112, 0),
(113, 0),
(114, 0),
(115, 0),
(116, 0),
(117, 0),
(118, 0),
(119, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `jm_newsfeeds`
--
-- Создание: Мар 30 2018 г., 11:27
--

DROP TABLE IF EXISTS `jm_newsfeeds`;
CREATE TABLE `jm_newsfeeds` (
  `catid` int(11) NOT NULL DEFAULT '0',
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(400) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `link` varchar(2048) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `numarticles` int(10) UNSIGNED NOT NULL DEFAULT '1',
  `cache_time` int(10) UNSIGNED NOT NULL DEFAULT '3600',
  `checked_out` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `rtl` tinyint(4) NOT NULL DEFAULT '0',
  `access` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `language` char(7) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `params` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `metakey` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `metadesc` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `metadata` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `xreference` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'A reference to enable linkages to external data sets.',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `version` int(10) UNSIGNED NOT NULL DEFAULT '1',
  `hits` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `images` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `jm_overrider`
--
-- Создание: Мар 30 2018 г., 11:27
--

DROP TABLE IF EXISTS `jm_overrider`;
CREATE TABLE `jm_overrider` (
  `id` int(10) NOT NULL COMMENT 'Primary Key',
  `constant` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `string` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `file` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `jm_overrider`
--

INSERT INTO `jm_overrider` (`id`, `constant`, `string`, `file`) VALUES
(1, 'COM_AJAX', 'Интерфейс Ajax', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_ajax.ini'),
(2, 'COM_AJAX_XML_DESCRIPTION', 'Расширяемый интерфейс Ajax для Joomla', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_ajax.ini'),
(3, 'COM_AJAX_SPECIFY_FORMAT', 'Пожалуйста, укажите корректный формат данных ответа (отличный от HTML, например json, raw, debug).', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_ajax.ini'),
(4, 'COM_AJAX_METHOD_NOT_EXISTS', 'Метод %s не существует', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_ajax.ini'),
(5, 'COM_AJAX_FILE_NOT_EXISTS', 'Файл %s не существует', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_ajax.ini'),
(6, 'COM_AJAX_MODULE_NOT_ACCESSIBLE', 'Модуль %s не опубликован, у вас остутствуют права доступа на модуль или модуль не назначен для текущего пункта меню', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_ajax.ini'),
(7, 'COM_AJAX_TEMPLATE_NOT_ACCESSIBLE', 'Шаблон %s не назначен текущему пункту меню.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_ajax.ini'),
(8, 'COM_CONFIG', 'Панель управления сайтом', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_config.ini'),
(9, 'COM_CONFIG_CONFIGURATION', 'Параметры конфигурации сайта', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_config.ini'),
(10, 'COM_CONFIG_ERROR_CONTROLLER_NOT_FOUND', 'Контроллер не найден!', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_config.ini'),
(11, 'COM_CONFIG_FIELD_DEFAULT_ACCESS_LEVEL_DESC', 'Выбор уровня доступа по умолчанию для новых материалов, пунктов меню и прочих элементов, создаваемых на сайте.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_config.ini'),
(12, 'COM_CONFIG_FIELD_DEFAULT_ACCESS_LEVEL_LABEL', 'Уровень доступа по&#160;умолчанию', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_config.ini'),
(13, 'COM_CONFIG_FIELD_DEFAULT_LIST_LIMIT_DESC', 'Устанавливает для всех пользователей значение длины списков объектов в рабочих областях менеджеров панели управления по умолчанию', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_config.ini'),
(14, 'COM_CONFIG_FIELD_DEFAULT_LIST_LIMIT_LABEL', 'Длина списка по&#160;умолчанию', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_config.ini'),
(15, 'COM_CONFIG_FIELD_METADESC_DESC', 'Введите общее описание веб-сайта, которое следует передавать поисковым системам. Как правило, оптимальным является описание длиной не более 20 слов.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_config.ini'),
(16, 'COM_CONFIG_FIELD_METADESC_LABEL', 'Мета-тег Description для сайта', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_config.ini'),
(17, 'COM_CONFIG_FIELD_METAKEYS_DESC', 'Введите ключевые слова и фразы, которые лучше всего описывают ваш сайт. Отдельные ключевые слова и фразы разделяйте с помощью запятой.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_config.ini'),
(18, 'COM_CONFIG_FIELD_METAKEYS_LABEL', 'Мета-тег Keywords', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_config.ini'),
(19, 'COM_CONFIG_FIELD_SEF_URL_DESC', 'Определяет, следует ли оптимизировать URL-адреса страниц для поисковых систем.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_config.ini'),
(20, 'COM_CONFIG_FIELD_SEF_URL_LABEL', 'Включить SEF (ЧПУ)', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_config.ini'),
(21, 'COM_CONFIG_FIELD_SITE_NAME_DESC', 'Введите название вашего веб-сайта. Введённое значение будет использоваться в различных местах (например, в заголовке панели управления и на странице <em>Сайт выключен</em>).', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_config.ini'),
(22, 'COM_CONFIG_FIELD_SITE_NAME_LABEL', 'Название сайта', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_config.ini'),
(23, 'COM_CONFIG_FIELD_VALUE_AFTER', 'После', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_config.ini'),
(24, 'COM_CONFIG_FIELD_VALUE_BEFORE', 'До', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_config.ini'),
(25, 'COM_CONFIG_FIELD_SITE_OFFLINE_DESC', 'Позволяет заблокировать доступ к сайту для всех пользователей. Если&#160;выбрать <strong>Да</strong>, на странице сайта будет отображаться сообщение, заданное в поле <strong>Сообщение при выключенном сайте</strong>.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_config.ini'),
(26, 'COM_CONFIG_FIELD_SITE_OFFLINE_LABEL', 'Сайт выключен (offline)', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_config.ini'),
(27, 'COM_CONFIG_FIELD_SITENAME_PAGETITLES_DESC', 'Включать название сайта в заголовки страниц (до или после названия текущей страницы). Например, Название сайта - Название материала.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_config.ini'),
(28, 'COM_CONFIG_FIELD_SITENAME_PAGETITLES_LABEL', 'Включать название сайта в&#160;заголовок страницы', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_config.ini'),
(29, 'COM_CONFIG_METADATA_SETTINGS', 'Параметры метаданных', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_config.ini'),
(30, 'COM_CONFIG_MODULES_MODULE_NAME', 'Название модуля', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_config.ini'),
(31, 'COM_CONFIG_MODULES_MODULE_TYPE', 'Тип модуля', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_config.ini'),
(32, 'COM_CONFIG_MODULES_SETTINGS_TITLE', 'Параметры модуля', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_config.ini'),
(33, 'COM_CONFIG_MODULES_SAVE_SUCCESS', 'Модуль успешно сохранен.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_config.ini'),
(34, 'COM_CONFIG_SAVE_SUCCESS', 'Настройки успешно сохранены.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_config.ini'),
(35, 'COM_CONFIG_SEO_SETTINGS', 'Параметры SEO', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_config.ini'),
(36, 'COM_CONFIG_SITE_SETTINGS', 'Параметры сайта', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_config.ini'),
(37, 'COM_CONFIG_TEMPLATE_SETTINGS', 'Параметры шаблона', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_config.ini'),
(38, 'COM_CONFIG_XML_DESCRIPTION', 'Менеджер конфигурации сайта', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_config.ini'),
(39, 'COM_CONTACT_ADDRESS', 'Адрес', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_contact.ini'),
(40, 'COM_CONTACT_ARTICLES_HEADING', 'Материалы контакта', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_contact.ini'),
(41, 'COM_CONTACT_CAPTCHA_LABEL', 'CAPTCHA', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_contact.ini'),
(42, 'COM_CONTACT_CAPTCHA_DESC', 'Введите текст, который вы видите на картинке.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_contact.ini'),
(43, 'COM_CONTACT_CAT_NUM', 'Кол-во контактов:', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_contact.ini'),
(44, 'COM_CONTACT_CONTACT_DEFAULT_LABEL', 'Отправить письмо', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_contact.ini'),
(45, 'COM_CONTACT_CONTACT_EMAIL_A_COPY_DESC', 'Отправляет копию данного сообщения на указанный вами адрес.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_contact.ini'),
(46, 'COM_CONTACT_CONTACT_EMAIL_A_COPY_LABEL', 'Отправить копию этого сообщения на ваш адрес', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_contact.ini'),
(47, 'COM_CONTACT_CONTACT_EMAIL_NAME_DESC', 'Ваше имя', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_contact.ini'),
(48, 'COM_CONTACT_CONTACT_EMAIL_NAME_LABEL', 'Имя', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_contact.ini'),
(49, 'COM_CONTACT_CONTACT_ENTER_MESSAGE_DESC', 'Введите текст вашего сообщения', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_contact.ini'),
(50, 'COM_CONTACT_CONTACT_ENTER_MESSAGE_LABEL', 'Сообщение', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_contact.ini'),
(51, 'COM_CONTACT_CONTACT_ENTER_VALID_EMAIL', 'Пожалуйста, введите корректный адрес электронной почты.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_contact.ini'),
(52, 'COM_CONTACT_CONTACT_REQUIRED', '<strong class=\"red\">*</strong> Обязательное поле', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_contact.ini'),
(53, 'COM_CONTACT_CONTENT_TYPE_CONTACT', 'Контакт', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_contact.ini'),
(54, 'COM_CONTACT_CONTENT_TYPE_CATEGORY', 'Категория контактов', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_contact.ini'),
(55, 'COM_CONTACT_FILTER_LABEL', 'Фильтр', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_contact.ini'),
(56, 'COM_CONTACT_FILTER_SEARCH_DESC', 'Фильтр поиска по контактам', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_contact.ini'),
(57, 'COM_CONTACT_CONTACT_MESSAGE_SUBJECT_DESC', 'Тема сообщения', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_contact.ini'),
(58, 'COM_CONTACT_CONTACT_MESSAGE_SUBJECT_LABEL', 'Тема', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_contact.ini'),
(59, 'COM_CONTACT_CONTACT_SEND', 'Отправить сообщение', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_contact.ini'),
(60, 'COM_CONTACT_COPYSUBJECT_OF', 'Копия: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_contact.ini'),
(61, 'COM_CONTACT_COPYTEXT_OF', 'Это копия сообщения, которое вы отправили %s через %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_contact.ini'),
(62, 'COM_CONTACT_COUNT', 'Кол-во контактов:', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_contact.ini'),
(63, 'COM_CONTACT_COUNTRY', 'Страна', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_contact.ini'),
(64, 'COM_CONTACT_DEFAULT_PAGE_TITLE', 'Контакты', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_contact.ini'),
(65, 'COM_CONTACT_DETAILS', 'Контакт', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_contact.ini'),
(66, 'COM_CONTACT_DOWNLOAD_INFORMATION_AS', 'Загрузить информацию как:', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_contact.ini'),
(67, 'COM_CONTACT_EMAIL_BANNEDTEXT', 'Поле \'%s\' вашего письма содержит фрагмент текста, который не допускается на этом сайте.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_contact.ini'),
(68, 'COM_CONTACT_EMAIL_DESC', 'Адрес электронной почты контакта', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_contact.ini'),
(69, 'COM_CONTACT_EMAIL_FORM', 'Форма обратной связи', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_contact.ini'),
(70, 'COM_CONTACT_EMAIL_LABEL', 'E-mail', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_contact.ini'),
(71, 'COM_CONTACT_EMAIL_THANKS', 'Спасибо за ваше письмо!', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_contact.ini'),
(72, 'COM_CONTACT_ENQUIRY_TEXT', 'Это письмо отправлено с сайта %s от:', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_contact.ini'),
(73, 'COM_CONTACT_ERROR_CONTACT_NOT_FOUND', 'Контакт не найден', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_contact.ini'),
(74, 'COM_CONTACT_FAX', 'Факс', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_contact.ini'),
(75, 'COM_CONTACT_FAX_NUMBER', 'Факс: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_contact.ini'),
(76, 'COM_CONTACT_FORM_LABEL', 'Отправить сообщение. Все поля, отмеченные звёздочкой, являются обязательными.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_contact.ini'),
(77, 'COM_CONTACT_FORM_NC', 'Пожалуйста, убедитесь, что форма заполнена правильно и полностью.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_contact.ini'),
(78, 'COM_CONTACT_IMAGE_DETAILS', 'Изображение контакта', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_contact.ini'),
(79, 'COM_CONTACT_LINKS', 'Ссылки', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_contact.ini'),
(80, 'COM_CONTACT_MAILENQUIRY', '%s контакт', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_contact.ini'),
(81, 'COM_CONTACT_MOBILE', 'Мобильный', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_contact.ini'),
(82, 'COM_CONTACT_MOBILE_NUMBER', 'Мобильный: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_contact.ini'),
(83, 'COM_CONTACT_NO_CONTACTS', 'Нет контактов', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_contact.ini'),
(84, 'COM_CONTACT_NOT_MORE_THAN_ONE_EMAIL_ADDRESS', 'Вы не можете ввести более одного адреса электронной почты.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_contact.ini'),
(85, 'COM_CONTACT_NUM_ITEMS', 'Кол-во контактов:', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_contact.ini'),
(86, 'COM_CONTACT_OPTIONAL', '(опционально)', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_contact.ini'),
(87, 'COM_CONTACT_OTHER_INFORMATION', 'Дополнительная информация', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_contact.ini'),
(88, 'COM_CONTACT_POSITION', 'Должность', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_contact.ini'),
(89, 'COM_CONTACT_PROFILE', 'Профиль', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_contact.ini'),
(90, 'COM_CONTACT_PROFILE_HEADING', 'Профиль контакта', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_contact.ini'),
(91, 'COM_CONTACT_SELECT_CONTACT', 'Выберите контакт:', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_contact.ini'),
(92, 'COM_CONTACT_SESSION_INVALID', 'Недопустимый cookie сеанса. Пожалуйста, проверьте, что cookies включены у вас в веб-браузере.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_contact.ini'),
(93, 'COM_CONTACT_STATE', 'Область', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_contact.ini'),
(94, 'COM_CONTACT_SUBURB', 'Город', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_contact.ini'),
(95, 'COM_CONTACT_TELEPHONE', 'Телефон', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_contact.ini'),
(96, 'COM_CONTACT_TELEPHONE_NUMBER', 'Телефон: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_contact.ini'),
(97, 'COM_CONTACT_USER_FIELDS', 'Поля', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_contact.ini'),
(98, 'COM_CONTACT_VCARD', 'Визитная карточка (vCard)', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_contact.ini'),
(99, 'COM_CONTENT_ACCESS_DELETE_DESC', 'Унаследованное состояние права на действие <strong>Удалять</strong> для данного материала, а так же суммарное состояние, вычисленное для выбранного меню.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(100, 'COM_CONTENT_ACCESS_EDIT_DESC', 'Унаследованное состояние права на действие <strong>Изменять</strong> для данного материала, а так же суммарное состояние, на основе выбранного меню.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(101, 'COM_CONTENT_ACCESS_EDITSTATE_DESC', 'Унаследованное состояние права на действие <strong>Изменять состояние</strong> для данного материала, а так же суммарное состояние, на основе выбранного меню.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(102, 'COM_CONTENT_ARTICLE_CONTENT', 'Материалы', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(103, 'COM_CONTENT_ARTICLE_HITS', 'Просмотров: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(104, 'COM_CONTENT_ARTICLE_INFO', 'Подробности', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(105, 'COM_CONTENT_ARTICLE_VOTE_FAILURE', 'Вы уже сегодня оценивали этот материал!', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(106, 'COM_CONTENT_ARTICLE_VOTE_SUCCESS', 'Спасибо за оценку!', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(107, 'COM_CONTENT_AUTHOR_FILTER_LABEL', 'Фильтр по автору', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(108, 'COM_CONTENT_CAPTCHA_DESC', 'Введите текст, который вы видите на картинке.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(109, 'COM_CONTENT_CAPTCHA_LABEL', 'Капча', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(110, 'COM_CONTENT_CATEGORY', 'Категория: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(111, 'COM_CONTENT_CATEGORY_LIST_TABLE_CAPTION', 'Список материалов в категории %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(112, 'COM_CONTENT_CHECKED_OUT_BY', 'Заблокировано %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(113, 'COM_CONTENT_CONTENT_TYPE_ARTICLE', 'Материал', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(114, 'COM_CONTENT_CONTENT_TYPE_CATEGORY', 'Категория материалов', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(115, 'COM_CONTENT_CREATE_ARTICLE', 'Создать новый материал', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(116, 'COM_CONTENT_CREATED_DATE', 'Дата создания', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(117, 'COM_CONTENT_CREATED_DATE_ON', 'Создано: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(118, 'COM_CONTENT_EDIT_ITEM', 'Изменить материал', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(119, 'COM_CONTENT_ERROR_ARTICLE_NOT_FOUND', 'Материал не найден', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(120, 'COM_CONTENT_ERROR_LOGIN_TO_VIEW_ARTICLE', 'Для просмотра данного материала необходимо пройти авторизацию', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(121, 'COM_CONTENT_ERROR_PARENT_CATEGORY_NOT_FOUND', 'Родительская категория не найдена', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(122, 'COM_CONTENT_FEED_READMORE', 'Подробнее...', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(123, 'COM_CONTENT_FIELD_FULL_DESC', 'Изображение для режима просмотра полного текста материала', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(124, 'COM_CONTENT_FIELD_FULL_LABEL', 'Изображение полного текста материала', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(125, 'COM_CONTENT_FIELD_IMAGE_ALT_DESC', 'Альтернативный текст для пользователей, у которых нет доступа к изображениям. Если не указан, используется текст заголовка.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(126, 'COM_CONTENT_FIELD_IMAGE_ALT_LABEL', 'Альтернативный текст', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(127, 'COM_CONTENT_FIELD_IMAGE_CAPTION_DESC', 'Текст, который будет отображаться под изображением.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(128, 'COM_CONTENT_FIELD_IMAGE_CAPTION_LABEL', 'Заголовок', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(129, 'COM_CONTENT_FIELD_IMAGE_DESC', 'Изображение, которое будет отображено', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(130, 'COM_CONTENT_FIELD_INTRO_DESC', 'Изображение для вступительного текста (материалы блогов и избранных материалов)', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(131, 'COM_CONTENT_FIELD_INTRO_LABEL', 'Изображение для вступительного текста материала', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(132, 'COM_CONTENT_FIELD_URL_DESC', 'Ссылка (необходимо использовать полные ссылки).', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(133, 'COM_CONTENT_FIELD_URL_LINK_TEXT_DESC', 'Текст для ссылки', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(134, 'COM_CONTENT_FIELD_URL_LINK_TEXT_LABEL', 'Текст ссылки', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(135, 'COM_CONTENT_FIELD_URLA_LABEL', 'Ссылка A', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(136, 'COM_CONTENT_FIELD_URLA_LINK_TEXT_LABEL', 'Текст ссылки A', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(137, 'COM_CONTENT_FIELD_URLB_LABEL', 'Ссылка B', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(138, 'COM_CONTENT_FIELD_URLB_LINK_TEXT_LABEL', 'Текст ссылки B', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(139, 'COM_CONTENT_FIELD_URLC_LABEL', 'Ссылка C', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(140, 'COM_CONTENT_FIELD_URLC_LINK_TEXT_LABEL', 'Текст ссылки C', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(141, 'COM_CONTENT_FILTER_SEARCH_DESC', 'Фильтр поиска по материалам', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(142, 'COM_CONTENT_FLOAT_DESC', 'Позволяет задать расположение изображения относительно текста материала.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(143, 'COM_CONTENT_FLOAT_FULLTEXT_LABEL', 'Выравнивание изображения<br />для полного текста материала', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(144, 'COM_CONTENT_FLOAT_INTRO_LABEL', 'Выравнивание изображения<br />для вступительного текста материала', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(145, 'COM_CONTENT_FLOAT_LABEL', 'Выравнивание изображения', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(146, 'COM_CONTENT_FORM_EDIT_ARTICLE', 'Изменить материал', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(147, 'COM_CONTENT_FORM_FILTER_LEGEND', 'Фильтры', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(148, 'COM_CONTENT_FORM_FILTER_SUBMIT', 'Фильтр', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(149, 'COM_CONTENT_HEADING_TITLE', 'Заголовок', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(150, 'COM_CONTENT_HITS_FILTER_LABEL', 'Фильтр по кол-ву просмотров', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(151, 'COM_CONTENT_IMAGES_AND_URLS', 'Изображения и ссылки', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(152, 'COM_CONTENT_INTROTEXT', 'Материал должен содержать текст', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(153, 'COM_CONTENT_INVALID_RATING', 'Рейтинг статьи: Неверный рейтинг: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(154, 'COM_CONTENT_LAST_UPDATED', 'Обновлено: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(155, 'COM_CONTENT_LEFT', 'Влево', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(156, 'COM_CONTENT_METADATA', 'Метаданные', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(157, 'COM_CONTENT_MODAL_FILTER_SEARCH_DESC', 'Поиск по заголовкам и алиасам. Если необходимо найти ID материала или автора материала, используйте префикс \'ID:\' или \'AUTHOR:\' в начале строки.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(158, 'COM_CONTENT_MODAL_FILTER_SEARCH_LABEL', 'Поиск материалов', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(159, 'COM_CONTENT_MODIFIED_DATE', 'Дата изменения', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(160, 'COM_CONTENT_MONTH', 'Месяц', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(161, 'COM_CONTENT_MORE_ARTICLES', 'Ещё статьи...', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(162, 'COM_CONTENT_NEW_ARTICLE', 'Новый материал', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(163, 'COM_CONTENT_NO_ARTICLES', 'В данной категории нет материалов.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(164, 'COM_CONTENT_NONE', 'Нет', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(165, 'COM_CONTENT_NUM_ITEMS', 'Кол-во материалов:', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(166, 'COM_CONTENT_NUM_ITEMS_TIP', 'Количество материалов:', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(167, 'COM_CONTENT_ON_NEW_CONTENT', 'Пользователем \'%1$s\' был создан новый материал с заголовком \'%2$s\'.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(168, 'COM_CONTENT_ORDERING', 'Порядок:<br />Новая статья по умолчанию занимает первую позицию в категории. Порядок можно потом изменить.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(169, 'COM_CONTENT_PAGEBREAK_DOC_TITLE', 'Разрыв страницы', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(170, 'COM_CONTENT_PAGEBREAK_INSERT_BUTTON', 'Вставить разрыв страницы', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(171, 'COM_CONTENT_PAGEBREAK_TITLE', 'Заголовок страницы:', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(172, 'COM_CONTENT_PAGEBREAK_TOC', 'Заголовок оглавления:', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(173, 'COM_CONTENT_PARENT', 'Родительская категория: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(174, 'COM_CONTENT_PUBLISHED_DATE', 'Дата публикации', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(175, 'COM_CONTENT_PUBLISHED_DATE_ON', 'Опубликовано: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(176, 'COM_CONTENT_PUBLISHING', 'Публикация', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(177, 'COM_CONTENT_RATINGS', 'Рейтинг', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(178, 'COM_CONTENT_RATINGS_COUNT', 'Рейтинг: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(179, 'COM_CONTENT_READ_MORE', 'Подробнее: ', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(180, 'COM_CONTENT_READ_MORE_TITLE', 'Подробнее...', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(181, 'COM_CONTENT_REGISTER_TO_READ_MORE', 'Зарегистрируйтесь, чтобы прочесть подробности...', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(182, 'COM_CONTENT_RIGHT', 'Вправо', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(183, 'COM_CONTENT_SAVE_SUCCESS', 'Материал успешно сохранён', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(184, 'COM_CONTENT_SAVE_WARNING', 'Алиас уже существует, поэтому к текущему тексту алиаса была добавлена цифра. Если вы хотите изменить данный алиас, обратитесь к администратору сайта.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(185, 'COM_CONTENT_SELECT_AN_ARTICLE', 'Выбор материала', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(186, 'COM_CONTENT_SUBMIT_SAVE_SUCCESS', 'Материал успешно создан', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(187, 'COM_CONTENT_TITLE_FILTER_LABEL', 'Фильтр по заголовку', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(188, 'COM_CONTENT_VOTES', 'Голосовать', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(189, 'COM_CONTENT_VOTES_COUNT', 'Оценка: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(190, 'COM_CONTENT_WRITTEN_BY', 'Автор: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_content.ini'),
(191, 'COM_FINDER', 'Умный поиск', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_finder.ini'),
(192, 'COM_FINDER_ADVANCED_SEARCH_TOGGLE', 'Расширенный поиск', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_finder.ini'),
(193, 'COM_FINDER_ADVANCED_TIPS', '<p>Примеры работы Умного Поиска:</p><p>Если ввести в поле поиска фразу <span class=\"term\">Война и Мир</span>, будут показаны материалы, содержащие и слово \"Война\" и слово \"Мир\".</p><p>Если ввести <span class=\"term\">Война не Мир</span> - материалы, содержащие слово \"Война\", но не содержащие слово \"Мир\".</p><p>Если ввести <span class=\"term\">Война или Мир</span> - материалы, содержащие либо слово \"Война\", либо слово \"Мир\" (либо оба эти слова).</p><p>Если ввести <span class=\"term\">\"Война и Мир\"</span> (с кавычками), будут показаны материалы, содержащие именно фразу \"Война и Мир\" целиком.</p><p>Результаты поиска можно ограничить с помощью фильтров по различным критериям, которые приводятся ниже.</p>', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_finder.ini'),
(194, 'COM_FINDER_DEFAULT_PAGE_TITLE', 'Результаты поиска', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_finder.ini'),
(195, 'COM_FINDER_FILTER_BRANCH_LABEL', 'Искать по критерию %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_finder.ini'),
(196, 'COM_FINDER_FILTER_DATE_BEFORE', 'До', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_finder.ini'),
(197, 'COM_FINDER_FILTER_DATE_EXACTLY', 'Точно', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_finder.ini'),
(198, 'COM_FINDER_FILTER_DATE_AFTER', 'После', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_finder.ini'),
(199, 'COM_FINDER_FILTER_DATE1', 'Дата начала', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_finder.ini'),
(200, 'COM_FINDER_FILTER_DATE1_DESC', 'Введите дату в формате YYYY-MM-DD', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_finder.ini'),
(201, 'COM_FINDER_FILTER_DATE2', 'Дата окончания', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_finder.ini'),
(202, 'COM_FINDER_FILTER_DATE2_DESC', 'Введите дату в формате YYYY-MM-DD', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_finder.ini'),
(203, 'COM_FINDER_FILTER_SELECT_ALL_LABEL', 'Искать всё', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_finder.ini'),
(204, 'COM_FINDER_FILTER_WHEN_AFTER', 'После', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_finder.ini'),
(205, 'COM_FINDER_FILTER_WHEN_BEFORE', 'До', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_finder.ini'),
(206, 'COM_FINDER_QUERY_DATE_CONDITION_AFTER', 'после', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_finder.ini'),
(207, 'COM_FINDER_QUERY_DATE_CONDITION_BEFORE', 'до', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_finder.ini'),
(208, 'COM_FINDER_QUERY_DATE_CONDITION_EXACT', 'точное совпадение', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_finder.ini'),
(209, 'COM_FINDER_QUERY_END_DATE', 'дата окончания <span class=\"when\">%s</span> <span class=\"date\">%s</span>', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_finder.ini'),
(210, 'COM_FINDER_QUERY_OPERATOR_AND', 'и', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_finder.ini'),
(211, 'COM_FINDER_QUERY_OPERATOR_OR', 'или', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_finder.ini'),
(212, 'COM_FINDER_QUERY_OPERATOR_NOT', 'не', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_finder.ini'),
(213, 'COM_FINDER_QUERY_FILTER_BRANCH_VENUE', 'место', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_finder.ini'),
(214, 'COM_FINDER_QUERY_START_DATE', 'дата начала <span class=\"when\">%s</span> <span class=\"date\">%s</span>', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_finder.ini'),
(215, 'COM_FINDER_QUERY_TAXONOMY_NODE', 'с <span class=\"node\">%s</span> как <span class=\"branch\">%s</span> ', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_finder.ini'),
(216, 'COM_FINDER_QUERY_TOKEN_EXCLUDED', '<span class=\"term\">%s</span> должны быть исключены', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_finder.ini'),
(217, 'COM_FINDER_QUERY_TOKEN_GLUE', ', и ', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_finder.ini'),
(218, 'COM_FINDER_QUERY_TOKEN_INTERPRETED', 'По запросу %s найдены следующие материалы:', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_finder.ini'),
(219, 'COM_FINDER_QUERY_TOKEN_OPTIONAL', '<span class=\"term\">%s</span> не обязательно', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_finder.ini'),
(220, 'COM_FINDER_QUERY_TOKEN_REQUIRED', '<span class=\"term\">%s</span> обязательно', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_finder.ini'),
(221, 'COM_FINDER_SEARCH_NO_RESULTS_BODY', 'Не найдено никаких результатов по запросу: %s.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_finder.ini'),
(222, 'COM_FINDER_SEARCH_NO_RESULTS_BODY_MULTILANG', 'Не найдено никаких результатов (на английском) по запросу: %s.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_finder.ini'),
(223, 'COM_FINDER_SEARCH_NO_RESULTS_HEADING', 'Ничего не найдено', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_finder.ini'),
(224, 'COM_FINDER_SEARCH_RESULTS_OF', 'Результаты <strong>%s</strong> - <strong>%s</strong> из <strong>%s</strong>', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_finder.ini'),
(225, 'COM_FINDER_SEARCH_SIMILAR', 'Вы имели в виду: %s?', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_finder.ini'),
(226, 'COM_FINDER_SEARCH_TERMS', 'Условия поиска:', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_finder.ini'),
(227, 'COM_MAILTO', 'Кому', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_mailto.ini'),
(228, 'COM_MAILTO_CANCEL', 'Отмена', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_mailto.ini'),
(229, 'COM_MAILTO_CLOSE_WINDOW', 'Закрыть окно', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_mailto.ini'),
(230, 'COM_MAILTO_EMAIL_ERR_NOINFO', 'Пожалуйста, введите корректный адрес электронной почты.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_mailto.ini'),
(231, 'COM_MAILTO_EMAIL_INVALID', 'Адрес \'%s\' некорректен. Проверьте его, пожалуйста.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_mailto.ini'),
(232, 'COM_MAILTO_EMAIL_MSG', 'Здравствуйте!\\n\\nЭто письмо отправлено вам с сайта «%s».\\n\\nПосетитель нашего сайта, %s (%s) , предлагает вам ознакомиться с содержанием страницы: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_mailto.ini'),
(233, 'COM_MAILTO_EMAIL_NOT_SENT', 'Не удаётся отправить электронное письмо.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_mailto.ini'),
(234, 'COM_MAILTO_EMAIL_SENT', 'Письмо было успешно отправлено.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_mailto.ini'),
(235, 'COM_MAILTO_EMAIL_TO', 'E-mail адресата', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_mailto.ini'),
(236, 'COM_MAILTO_EMAIL_TO_A_FRIEND', 'Отправить ссылку другу.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_mailto.ini'),
(237, 'COM_MAILTO_LINK_IS_MISSING', 'Ссылка отсутствует', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_mailto.ini'),
(238, 'COM_MAILTO_SEND', 'Отправить', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_mailto.ini'),
(239, 'COM_MAILTO_SENDER', 'Ваше имя', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_mailto.ini'),
(240, 'COM_MAILTO_SENT_BY', 'Информацию прислал', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_mailto.ini'),
(241, 'COM_MAILTO_SUBJECT', 'Тема', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_mailto.ini'),
(242, 'COM_MAILTO_YOUR_EMAIL', 'Ваш E-mail', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_mailto.ini'),
(243, 'COM_MEDIA_ALIGN', 'Выравнивание', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(244, 'COM_MEDIA_ALIGN_DESC', 'Назначает свойства \'pull-left\', \'pull-center\' или \'pull-right\' для элементов \'<figure>\' или \'<img>\'.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(245, 'COM_MEDIA_BROWSE_FILES', 'Файлы для просмотра', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(246, 'COM_MEDIA_CAPTION', 'Заголовок', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(247, 'COM_MEDIA_CAPTION_CLASS_LABEL', 'CSS-класс заголовка', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(248, 'COM_MEDIA_CAPTION_CLASS_DESC', 'Позволяет назначить указанный класс для элемента \'<figcaption>\'. Например: \'text-left\', \'text-right\', \'text-center\'', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(249, 'COM_MEDIA_CLEAR_LIST', 'Очистить список', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(250, 'COM_MEDIA_CONFIGURATION', 'Настройки медиа-менеджера', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(251, 'COM_MEDIA_CREATE_FOLDER', 'Создать каталог', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(252, 'COM_MEDIA_CURRENT_PROGRESS', 'Текущий прогресс', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(253, 'COM_MEDIA_DESCFTP', 'Для загрузки, изменения и удаления медиафайлов системе необходим доступ по FTP. Пожалуйста, введите параметры FTP-доступа в поля формы ниже.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(254, 'COM_MEDIA_DESCFTPTITLE', 'Параметры доступа по FTP', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(255, 'COM_MEDIA_DETAIL_VIEW', 'Подробно', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(256, 'COM_MEDIA_DIRECTORY', 'Каталог', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(257, 'COM_MEDIA_DIRECTORY_UP', 'На уровень выше', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(258, 'COM_MEDIA_ERROR_BAD_REQUEST', 'Некорректный запрос', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(259, 'COM_MEDIA_ERROR_FILE_EXISTS', 'Файл уже существует', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(260, 'COM_MEDIA_ERROR_UNABLE_TO_CREATE_FOLDER_WARNDIRNAME', 'Невозможно создать каталог. Имя каталога может содержать только буквенно-цифровые символов, без пробелов.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(261, 'COM_MEDIA_ERROR_UNABLE_TO_BROWSE_FOLDER_WARNDIRNAME', 'Невозможно открыть каталог:&#160;%s. Имя каталога может содержать только буквенно-цифровые символов, без пробелов.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(262, 'COM_MEDIA_ERROR_UNABLE_TO_DELETE', 'Не удалось удалить:&#160;', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(263, 'COM_MEDIA_ERROR_UNABLE_TO_DELETE_FILE_WARNFILENAME', 'Не удалось удалить:&#160;%s. Имя файла должно состоять только из букв и цифр, без пробелов.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(264, 'COM_MEDIA_ERROR_UNABLE_TO_DELETE_FOLDER_NOT_EMPTY', 'Не удалось удалить:&#160;%s. Каталог не пуст!', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(265, 'COM_MEDIA_ERROR_UNABLE_TO_DELETE_FOLDER_WARNDIRNAME', 'Не удалось удалить:&#160;%s. Имя каталога должно состоять только из букв и цифр, без пробелов.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(266, 'COM_MEDIA_ERROR_UNABLE_TO_UPLOAD_FILE', 'Не удаётся загрузить файл.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(267, 'COM_MEDIA_ERROR_WARNFILETOOLARGE', 'Размер данного файла слишком велик для загрузки', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(268, 'COM_MEDIA_ERROR_WARNUPLOADTOOLARGE', 'Общий размер загружаемых файлов превышает лимит.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(269, 'COM_MEDIA_FIELD_CHECK_MIME_DESC', 'Использовать Fileinfo или MIME Magic для проверки файлов. Отключите, если не хотите видеть сообщения об ошибках определения типа файла (mime type errors)', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(270, 'COM_MEDIA_FIELD_CHECK_MIME_LABEL', 'Проверять тип файла (MIME)', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(271, 'COM_MEDIA_FIELD_IGNORED_EXTENSIONS_DESC', 'Перечень (через запятую) расширений файлов, которые блокируются при проверке MIME-типов и&#160;при&#160;ограниченной загрузке.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(272, 'COM_MEDIA_FIELD_IGNORED_EXTENSIONS_LABEL', 'Запрещённые расширения файлов', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(273, 'COM_MEDIA_FIELD_ILLEGAL_MIME_TYPES_DESC', 'Перечень (через запятую) запрещённых для загрузки типов файлов (MIME) (чёрный список)', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(274, 'COM_MEDIA_FIELD_ILLEGAL_MIME_TYPES_LABEL', 'Недопустимые типы файлов (MIME)', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(275, 'COM_MEDIA_FIELD_LEGAL_EXTENSIONS_DESC', 'Перечень (через запятую) расширений файлов, которые разрешено загружать на сервер.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(276, 'COM_MEDIA_FIELD_LEGAL_EXTENSIONS_LABEL', 'Разрешённые расширения', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(277, 'COM_MEDIA_FIELD_LEGAL_IMAGE_EXTENSIONS_DESC', 'Перечень (через запятую) расширений файлов изображений, разрешённых для загрузки на сервер. Используется для проверки заголовков изображений.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(278, 'COM_MEDIA_FIELD_LEGAL_IMAGE_EXTENSIONS_LABEL', 'Разрешённые расширения изображений', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(279, 'COM_MEDIA_FIELD_LEGAL_MIME_TYPES_DESC', 'Перечень (через запятую) разрешённых для загрузки типов файлов (MIME)', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(280, 'COM_MEDIA_FIELD_LEGAL_MIME_TYPES_LABEL', 'Разрешённые типы файлов (MIME)', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(281, 'COM_MEDIA_FIELD_MAXIMUM_SIZE_DESC', 'Максимальный размер загружаемых файлов (в мегабайтах). Введите 0, если хотите позволить загружать файлы любого размера.<br /><br />Примечание: У сервера, на котором размещён сайт, может иметься собственное ограничение максимального объёма загружаемых файлов.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(282, 'COM_MEDIA_FIELD_MAXIMUM_SIZE_LABEL', 'Максимальный размер (в MB)', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(283, 'COM_MEDIA_FIELD_PATH_FILE_FOLDER_DESC', 'Введите путь к каталогу с файлами относительно корневого каталога сайта', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(284, 'COM_MEDIA_FIELD_PATH_FILE_FOLDER_LABEL', 'Путь к каталогу с файлами', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(285, 'COM_MEDIA_FIELD_PATH_IMAGE_FOLDER_DESC', 'Введите путь к каталогу с файлами относительно корневого каталога сайта.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(286, 'COM_MEDIA_FIELD_PATH_IMAGE_FOLDER_LABEL', 'Путь к каталогу с изображениями', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(287, 'COM_MEDIA_FIELD_RESTRICT_UPLOADS_DESC', 'Ограничить загрузку для пользователей с правами ниже <em>Менеджера</em>, если Fileinfo или MIME magic не установлены.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(288, 'COM_MEDIA_FIELD_RESTRICT_UPLOADS_LABEL', 'Ограничение загрузки', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(289, 'COM_MEDIA_FILES', 'Файлы', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(290, 'COM_MEDIA_FILESIZE', 'Размер файла', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(291, 'COM_MEDIA_FOLDER', 'Каталог', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(292, 'COM_MEDIA_FOLDERS', 'Каталоги', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(293, 'COM_MEDIA_IMAGE_DESCRIPTION', 'Описание изображения', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(294, 'COM_MEDIA_IMAGE_URL', 'Адрес (URL) изображения', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(295, 'COM_MEDIA_INSERT', 'Вставить', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(296, 'COM_MEDIA_INSERT_IMAGE', 'Вставить изображение', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(297, 'COM_MEDIA_MAXIMUM_SIZE', 'Максимальный размер', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(298, 'COM_MEDIA_MEDIA', 'Медиа', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(299, 'COM_MEDIA_NAME', 'Название файла', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(300, 'COM_MEDIA_NO_IMAGES_FOUND', 'Изображения не найдены', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(301, 'COM_MEDIA_NOT_SET', 'Не определено', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(302, 'COM_MEDIA_OVERALL_PROGRESS', 'Общий прогресс', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(303, 'COM_MEDIA_PIXEL_DIMENSIONS', 'Размеры (Ш&#160;х&#160;В), в&#160;пикселях', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(304, 'COM_MEDIA_START_UPLOAD', 'Загрузить', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(305, 'COM_MEDIA_THUMBNAIL_VIEW', 'Эскизы', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(306, 'COM_MEDIA_TITLE', 'Заголовок изображения', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(307, 'COM_MEDIA_UP', 'Вверх', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(308, 'COM_MEDIA_UPLOAD', 'Загрузить', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(309, 'COM_MEDIA_UPLOAD_FILES', 'Загрузка файлов (максимальный размер: %s MB)', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(310, 'COM_MEDIA_UPLOAD_FILES_NOLIMIT', 'Загрузка файлов (максимальный размер не ограничен)', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(311, 'COM_MEDIA_UPLOAD_COMPLETE', 'Загрузка завершена', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(312, 'COM_MEDIA_UPLOAD_FILE', 'Загрузить файл', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(313, 'COM_MEDIA_UPLOAD_SUCCESSFUL', 'Загрузка успешно завершена', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_media.ini'),
(314, 'COM_MESSAGES_ERR_SEND_FAILED', 'Пользователь заблокировал свой почтовый ящик. Доставить сообщение не удалось.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_messages.ini'),
(315, 'COM_MESSAGES_NEW_MESSAGE_ARRIVED', 'Вы получили новое личное сообщение от %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_messages.ini'),
(316, 'COM_MESSAGES_PLEASE_LOGIN', 'Отправлено', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_messages.ini'),
(317, 'COM_NEWSFEEDS_CACHE_DIRECTORY_UNWRITABLE', 'Директория кэша недоступна по записи. Лента новостей не может быть отображена. Пожалуйста, свяжитесь с администратором сайта.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_newsfeeds.ini'),
(318, 'COM_NEWSFEEDS_CAT_NUM', 'Кол-во новостных лент:', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_newsfeeds.ini'),
(319, 'COM_NEWSFEEDS_CONTENT_TYPE_NEWSFEED', 'Лента новостей', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_newsfeeds.ini'),
(320, 'COM_NEWSFEEDS_CONTENT_TYPE_CATEGORY', 'Категория новостных лент', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_newsfeeds.ini'),
(321, 'COM_NEWSFEEDS_DEFAULT_PAGE_TITLE', 'Ленты новостей', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_newsfeeds.ini'),
(322, 'COM_NEWSFEEDS_ERROR_FEED_NOT_FOUND', 'Ошибка. Лента новостей не найдена.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_newsfeeds.ini'),
(323, 'COM_NEWSFEEDS_ERRORS_FEED_NOT_RETRIEVED', 'Ошибка. Не удалось восстановить ленту новостей.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_newsfeeds.ini'),
(324, 'COM_NEWSFEEDS_FEED_LINK', 'Ссылка ленты', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_newsfeeds.ini'),
(325, 'COM_NEWSFEEDS_FEED_NAME', 'Название ленты', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_newsfeeds.ini'),
(326, 'COM_NEWSFEEDS_FILTER_LABEL', 'Фильтр', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_newsfeeds.ini'),
(327, 'COM_NEWSFEEDS_FILTER_SEARCH_DESC', 'Фильтр поиска по новостным лентам', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_newsfeeds.ini'),
(328, 'COM_NEWSFEEDS_NO_ARTICLES', 'В этой ленте новостей нет материалов', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_newsfeeds.ini'),
(329, 'COM_NEWSFEEDS_NUM_ARTICLES', 'Кол-во статей', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_newsfeeds.ini');
INSERT INTO `jm_overrider` (`id`, `constant`, `string`, `file`) VALUES
(330, 'COM_NEWSFEEDS_NUM_ARTICLES_COUNT', 'Кол-во статей: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_newsfeeds.ini'),
(331, 'COM_NEWSFEEDS_NUM_ITEMS', '# кол-во', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_newsfeeds.ini'),
(332, 'COM_SEARCH_ALL_WORDS', 'Все слова', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_search.ini'),
(333, 'COM_SEARCH_ALPHABETICAL', 'По алфавиту', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_search.ini'),
(334, 'COM_SEARCH_ANY_WORDS', 'Любое из слов', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_search.ini'),
(335, 'COM_SEARCH_ERROR_ENTERKEYWORD', 'Введите ключевое слово для поиска', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_search.ini'),
(336, 'COM_SEARCH_ERROR_IGNOREKEYWORD', 'Одно или более общих слов были проигнорированы при поиске.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_search.ini'),
(337, 'COM_SEARCH_ERROR_SEARCH_MESSAGE', 'Для выполнения поиска длина фразы должна быть не менее %1$s символов и не более %2$s.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_search.ini'),
(338, 'COM_SEARCH_EXACT_PHRASE', 'Точное совпадение', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_search.ini'),
(339, 'COM_SEARCH_FIELD_SEARCH_PHRASES_DESC', 'Показывать параметры поиска.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_search.ini'),
(340, 'COM_SEARCH_FIELD_SEARCH_PHRASES_LABEL', 'Использовать параметры поиска', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_search.ini'),
(341, 'COM_SEARCH_FIELD_SEARCH_AREAS_DESC', 'Показывать список доступных областей поиска', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_search.ini'),
(342, 'COM_SEARCH_FIELD_SEARCH_AREAS_LABEL', 'Использовать области поиска', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_search.ini'),
(343, 'COM_SEARCH_FOR', 'Совпадение', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_search.ini'),
(344, 'COM_SEARCH_MOST_POPULAR', 'Популярные первыми', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_search.ini'),
(345, 'COM_SEARCH_NEWEST_FIRST', 'Новые первыми', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_search.ini'),
(346, 'COM_SEARCH_OLDEST_FIRST', 'Старые первыми', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_search.ini'),
(347, 'COM_SEARCH_ORDERING', 'Порядок', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_search.ini'),
(348, 'COM_SEARCH_SEARCH', 'Искать', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_search.ini'),
(349, 'COM_SEARCH_SEARCH_AGAIN', 'Искать снова', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_search.ini'),
(350, 'COM_SEARCH_SEARCH_KEYWORD', 'Текст для поиска', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_search.ini'),
(351, 'COM_SEARCH_SEARCH_KEYWORD_N_RESULTS_1', '<strong>Результат поиска: найден один объект.</strong>', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_search.ini'),
(352, 'COM_SEARCH_SEARCH_KEYWORD_N_RESULTS_2', '<strong>Результат поиска: найдено %s объекта.</strong>', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_search.ini'),
(353, 'COM_SEARCH_SEARCH_KEYWORD_N_RESULTS', '<strong>Результат поиска: найдено %s объектов.</strong>', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_search.ini'),
(354, 'COM_SEARCH_SEARCH_ONLY', 'Ограничение области поиска', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_search.ini'),
(355, 'COM_SEARCH_SEARCH_RESULT', 'Результат поиска', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_search.ini'),
(356, 'COM_TAGS_CREATED_DATE', 'Дата создания', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_tags.ini'),
(357, 'COM_TAGS_DEFAULT_PAGE_TITLE', 'Метки', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_tags.ini'),
(358, 'COM_TAGS_FILTER_SEARCH_DESC', 'Введите заголовок метки или его часть для поиска.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_tags.ini'),
(359, 'COM_TAGS_MODIFIED_DATE', 'Дата изменения', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_tags.ini'),
(360, 'COM_TAGS_NO_ITEMS', 'Нет элементов с такой меткой', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_tags.ini'),
(361, 'COM_TAGS_NO_TAGS', 'Метки отсутствуют', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_tags.ini'),
(362, 'COM_TAGS_PUBLISHED_DATE', 'Дата публикации', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_tags.ini'),
(363, 'COM_TAGS_TAG_NOT_FOUND', 'Метка не найдена.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_tags.ini'),
(364, 'COM_TAGS_TITLE_FILTER_LABEL', 'Начните ввод заголовка метки', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_tags.ini'),
(365, 'COM_USERS_ACTIVATION_TOKEN_NOT_FOUND', 'Код подтверждения не найден.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(366, 'COM_USERS_CAPTCHA_LABEL', 'CAPTCHA', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(367, 'COM_USERS_CAPTCHA_DESC', 'Введите текст, который вы видите на картинке.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(368, 'COM_USERS_DATABASE_ERROR', 'Не удалось загрузить данные о пользователе из базы данных: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(369, 'COM_USERS_DESIRED_PASSWORD', 'Введите пароль.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(370, 'COM_USERS_DESIRED_USERNAME', 'Введите желаемый логин.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(371, 'COM_USERS_EDIT_PROFILE', 'Изменить профиль', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(372, 'COM_USERS_EMAIL_ACCOUNT_DETAILS', 'Параметры учётной записи для %s на сайте %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(373, 'COM_USERS_EMAIL_ACTIVATE_WITH_ADMIN_ACTIVATION_BODY', 'Здравствуйте, уважаемый администратор!\\n\\nНовый пользователь только что зарегистрировался на сайте %s.\\nПользователь подтвердил e-mail и просит активировать его учётную запись.\\nВ этом письме содержатся его регистрационные данные:\\n\\n Имя: %s \\n E-mail: %s \\n Логин: %s \\n\\nВы можете активировать учётную запись пользователя, перейдя по следующей ссылке:\\n %s \\n', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(374, 'COM_USERS_EMAIL_ACTIVATE_WITH_ADMIN_ACTIVATION_SUBJECT', 'Запрос активации учётной записи: %s на сайте %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(375, 'COM_USERS_EMAIL_ACTIVATED_BY_ADMIN_ACTIVATION_BODY', 'Здравствуйте %s,\\n\\nВаша учётная запись активирована. Вы можете войти на сайт %s. Ваш логин %s. Для учётной записи установлен тот пароль, который вы вводили при регистрации.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(376, 'COM_USERS_EMAIL_ACTIVATED_BY_ADMIN_ACTIVATION_SUBJECT', 'Активирована учётная запись %s на сайте %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(377, 'COM_USERS_EMAIL_PASSWORD_RESET_BODY', 'Здравствуйте,\\n\\nНа сайте %s был сделан запрос на восстановление пароля к вашей учётной записи. Чтобы восстановить пароль вам потребуется ввести указанный ниже код подтверждения.\\n\\nКод подтверждения: %s\\n\\nДля ввода кода подтверждения перейдите на страницу по ссылке ниже.\\n\\n %s \\n\\nСпасибо.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(378, 'COM_USERS_EMAIL_PASSWORD_RESET_SUBJECT', 'Запрос сброса пароля на сайте %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(379, 'COM_USERS_EMAIL_REGISTERED_BODY', 'Здравствуйте %s,\\n\\nСпасибо за регистрацию на %s.\\n\\nТеперь вы можете войти на %s используя следующие данные:\\n\\nЛогин: %s\\nПароль: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(380, 'COM_USERS_EMAIL_REGISTERED_BODY_NOPW', 'Здравствуйте %s,\\n\\nСпасибо за регистрацию на %s.\\n\\nТеперь вы можете войти на %s используя логин и пароль, указанные при регистрации.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(381, 'COM_USERS_EMAIL_REGISTERED_NOTIFICATION_TO_ADMIN_BODY', 'Здравствуйте, уважаемый администратор, \\n\\nНовый пользователь \'%s\', логин \'%s\', зарегистрировался на сайте %s.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(382, 'COM_USERS_EMAIL_REGISTERED_WITH_ACTIVATION_BODY', 'Здравствуйте, %s,\\n\\nБлагодарим вас за регистрацию на сайте %s. Ваша учётная запись создана, но должна быть активирована прежде, чем вы сможете ею воспользоваться.\\nЧтобы активировать учётную запись, перейдите по ссылке ниже, или скопируйте её в адресную строку браузера:\\n%s \\n\\nПосле активации вы сможете входить на сайт %s с помощью указанных ниже логина и пароля:\\n\\nЛогин: %s\\nПароль: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(383, 'COM_USERS_EMAIL_REGISTERED_WITH_ACTIVATION_BODY_NOPW', 'Здравствуйте, %s,\\n\\nБлагодарим вас за регистрацию на сайте %s. Ваша учётная запись создана, но должна быть активирована прежде, чем вы сможете ею воспользоваться.\\nЧтобы активировать учётную запись, перейдите по ссылке ниже, или скопируйте её в адресную строку браузера:\\n%s \\n\\nПосле активации вы сможете входить на сайт %s с помощью указанных ниже логина и пароля:\\n\\nЛогин: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(384, 'COM_USERS_EMAIL_REGISTERED_WITH_ADMIN_ACTIVATION_BODY', 'Здравствуйте %s,\\n\\nБлагодарим вас за регистрацию на сайте %s. Ваша учётная запись создана, но должна быть проверена прежде, чем вы сможете ею воспользоваться.\\nЧтобы подтвердить вашу учётную запись, перейдите по ссылке, приведённой ниже, или вставьте её в адресную строку браузера:\\n %s \\n\\nПосле проверки, администратору сайта будет отправлено сообщение о необходимости активировать вашу учётную запись.\\nПосле активации учётной записи вы сможете войти на сайт %s, используя логин и пароль приведённые ниже:\\n\\nЛогин: %s\\nПароль: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(385, 'COM_USERS_EMAIL_REGISTERED_WITH_ADMIN_ACTIVATION_BODY_NOPW', 'Здравствуйте %s,\\n\\nБлагодарим вас за регистрацию на сайте %s. Ваша учётная запись создана, но должна быть проверена прежде, чем вы сможете ею воспользоваться.\\nЧтобы подтвердить вашу учётную запись, перейдите по ссылке, приведённой ниже, или вставьте её в адресную строку браузера:\\n %s \\n\\nПосле проверки, администратору сайта будет отправлено сообщение о необходимости активировать вашу учётную запись.\\nПосле активации учётной записи вы сможете войти на сайт %s, используя логин и пароль приведённые ниже:\\n\\nЛогин: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(386, 'COM_USERS_EMAIL_USERNAME_REMINDER_BODY', 'Здравствуйте,\\n\\nНа сайте %s была сделана заявка на восстановление логина вашей учётной записи.\\n\\nВаш логин: %s.\\n\\nДля входа на сайт под вашими учётными данными перейдите по ссылке ниже.\\n\\n%s \\n\\nСпасибо.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(387, 'COM_USERS_EMAIL_USERNAME_REMINDER_SUBJECT', 'Восстановление логина на сайте %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(388, 'COM_USERS_ERROR_SECRET_CODE_WITHOUT_TFA', 'Вы ввели секретный код, однако двухфакторная аутентификация не включена для вашей учётной записи. Если вы желаете использовать секретный код для повышения безопасности авторизации, разрешите двухфакторную аутентификацию в параметрах вашего профиля.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(389, 'COM_USERS_FIELD_PASSWORD_RESET_DESC', 'Введите, пожалуйста, адрес электронной почты, указанный в параметрах вашей учётной записи.<br />На этот адрес будет отправлен специальный проверочный код. После его получения вы сможете ввести новый пароль для вашей учётной записи.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(390, 'COM_USERS_FIELD_PASSWORD_RESET_LABEL', 'Адрес электронной почты', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(391, 'COM_USERS_FIELD_REMIND_EMAIL_DESC', 'Введите, пожалуйста, адрес электронной почты, указанный в&#160;параметрах вашей учётной записи. На этот адрес будет отправлено письмо, содержащее ваш Логин.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(392, 'COM_USERS_FIELD_REMIND_EMAIL_LABEL', 'Адрес электронной почты', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(393, 'COM_USERS_FIELD_RESET_CONFIRM_TOKEN_DESC', 'Введите проверочный код, который получили по электронной почте.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(394, 'COM_USERS_FIELD_RESET_CONFIRM_TOKEN_LABEL', 'Код подтверждения:', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(395, 'COM_USERS_FIELD_RESET_CONFIRM_USERNAME_DESC', 'Введите ваш логин', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(396, 'COM_USERS_FIELD_RESET_CONFIRM_USERNAME_LABEL', 'Логин', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(397, 'COM_USERS_FIELD_RESET_PASSWORD1_DESC', 'Введите ваш новый пароль', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(398, 'COM_USERS_FIELD_RESET_PASSWORD1_LABEL', 'Пароль', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(399, 'COM_USERS_FIELD_RESET_PASSWORD1_MESSAGE', 'Введённые вами пароли не совпадают. Пожалуйста, введите желаемый пароль в поле пароля и в поле подтверждения.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(400, 'COM_USERS_FIELD_RESET_PASSWORD2_DESC', 'Подтвердите ваш новый пароль', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(401, 'COM_USERS_FIELD_RESET_PASSWORD2_LABEL', 'Повтор пароля', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(402, 'COM_USERS_INVALID_EMAIL', 'Недопустимый адрес электронной почты', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(403, 'COM_USERS_LOGIN_IMAGE_ALT', 'Изображение логина', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(404, 'COM_USERS_LOGIN_REGISTER', 'Ещё нет учётной записи?', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(405, 'COM_USERS_LOGIN_REMEMBER_ME', 'Запомнить меня', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(406, 'COM_USERS_LOGIN_REMIND', 'Забыли логин?', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(407, 'COM_USERS_LOGIN_RESET', 'Забыли пароль?', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(408, 'COM_USERS_LOGIN_USERNAME_LABEL', 'Логин', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(409, 'COM_USERS_MAIL_FAILED', 'Не удалось отправить электронную почту.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(410, 'COM_USERS_MAIL_SEND_FAILURE_BODY', 'При отправке письма c регистрационными данными пользователя произошла ошибка: %s Пользователь, для которого отправлялось письмо: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(411, 'COM_USERS_MAIL_SEND_FAILURE_SUBJECT', 'Ошибка при отправке письма', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(412, 'COM_USERS_MSG_NOT_ENOUGH_INTEGERS_N_1', 'В пароле недостаточно цифровых символов. Требуется не менее 1 цифры.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(413, 'COM_USERS_MSG_NOT_ENOUGH_INTEGERS_N_2', 'В пароле недостаточно цифровых символов. Требуется не менее %s цифровых символов.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(414, 'COM_USERS_MSG_NOT_ENOUGH_INTEGERS_N', 'В пароле недостаточно цифровых символов. Требуется не менее %s цифровых символов.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(415, 'COM_USERS_MSG_NOT_ENOUGH_SYMBOLS_N_1', 'В пароле недостаточно символов. Требуется не менее 1 символа.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(416, 'COM_USERS_MSG_NOT_ENOUGH_SYMBOLS_N_2', 'В пароле недостаточно символов. Требуется не менее %s символов.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(417, 'COM_USERS_MSG_NOT_ENOUGH_SYMBOLS_N', 'В пароле недостаточно символов. Требуется не менее %s символов.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(418, 'COM_USERS_MSG_NOT_ENOUGH_UPPERCASE_LETTERS_N_1', 'В пароле недостаточно символов в верхнем регистре (заглавных букв). Требуется не менее 1 символа в верхнем регистре.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(419, 'COM_USERS_MSG_NOT_ENOUGH_UPPERCASE_LETTERS_N_2', 'В пароле недостаточно символов в верхнем регистре (заглавных букв). Требуется не менее %s символов в верхнем регистре.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(420, 'COM_USERS_MSG_NOT_ENOUGH_UPPERCASE_LETTERS_N', 'В пароле недостаточно символов в верхнем регистре (заглавных букв). Требуется не менее %s символов в верхнем регистре.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(421, 'COM_USERS_MSG_PASSWORD_TOO_LONG', 'Пароль слишком длинный. Длина пароля должна быть меньше 100 символов.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(422, 'COM_USERS_MSG_PASSWORD_TOO_SHORT_N', 'Пароль слишком короткий. Минимальная длина пароля - %s символов.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(423, 'COM_USERS_MSG_SPACES_IN_PASSWORD', 'Пароль не должен содержать пробелов в начале или конце.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(424, 'COM_USERS_OPTIONAL', '(необязательно)', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(425, 'COM_USERS_OR', 'или', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(426, 'COM_USERS_PROFILE', 'Профиль пользователя', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(427, 'COM_USERS_PROFILE_BIND_FAILED', 'Ошибка загрузки данных профиля: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(428, 'COM_USERS_PROFILE_CORE_LEGEND', 'Профиль', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(429, 'COM_USERS_PROFILE_CUSTOM_LEGEND', 'Профиль пользователя', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(430, 'COM_USERS_PROFILE_DEFAULT_LABEL', 'Изменить свой профиль', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(431, 'COM_USERS_PROFILE_EMAIL1_DESC', 'Введите адрес электронной почты', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(432, 'COM_USERS_PROFILE_EMAIL1_LABEL', 'Адрес электронной почты', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(433, 'COM_USERS_PROFILE_EMAIL1_MESSAGE', 'Ваш адрес электронной почты уже используется или введён некорректно. Пожалуйста, введите другой адрес электронной почты.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(434, 'COM_USERS_PROFILE_EMAIL2_DESC', 'Подтвердите указанный вами адрес электронной почты', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(435, 'COM_USERS_PROFILE_EMAIL2_LABEL', 'Подтвердите адрес электронной почты:', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(436, 'COM_USERS_PROFILE_EMAIL2_MESSAGE', 'Адреса электронной почты не совпадают. Пожалуйста, введите ваш адрес электронной почты в поле адреса и в поле подтверждения.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(437, 'COM_USERS_PROFILE_LAST_VISITED_DATE_LABEL', 'Дата последнего посещения', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(438, 'COM_USERS_PROFILE_MY_PROFILE', 'Мой профиль', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(439, 'COM_USERS_PROFILE_NAME_DESC', 'Введите ваше полное имя', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(440, 'COM_USERS_PROFILE_NAME_LABEL', 'Имя', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(441, 'COM_USERS_PROFILE_NEVER_VISITED', 'Вы посетили этот сайт впервые', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(442, 'COM_USERS_PROFILE_NOCHANGE_USERNAME_DESC', 'Если вы хотите изменить логин - обратитесь к администратору сайта', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(443, 'COM_USERS_PROFILE_OTEPS', 'Одноразовые аварийные пароли', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(444, 'COM_USERS_PROFILE_OTEPS_DESC', 'Если у вас нет доступа к вашему устройству для двухфакторной аутентификации вы можете использовать один из данных паролей вместо секретного кода. Каждый из данных аварийных паролей является одноразовым - он уничтожается сразу после использования. Мы рекомендуем распечатать эти пароли и держать распечатку в надёжном и доступном месте - в кошельке или сейфе.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(445, 'COM_USERS_PROFILE_OTEPS_WAIT_DESC', 'Одноразовые аварийные пароли для вашей учётной записи отсутствуют. Одноразовые пароли формируются автоматически и отображаются здесь сразу после активации двухфакторной аутентификации.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(446, 'COM_USERS_PROFILE_PASSWORD1_LABEL', 'Пароль', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(447, 'COM_USERS_PROFILE_PASSWORD1_MESSAGE', 'Введённые вами пароли не совпадают. Пожалуйста, введите желаемый пароль в поле пароля и в поле подтверждения.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(448, 'COM_USERS_PROFILE_PASSWORD2_DESC', 'Подтверждение пароля', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(449, 'COM_USERS_PROFILE_PASSWORD2_LABEL', 'Повтор пароля', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(450, 'COM_USERS_PROFILE_REGISTERED_DATE_LABEL', 'Дата регистрации', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(451, 'COM_USERS_PROFILE_SAVE_FAILED', 'Не удаётся сохранить профиль: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(452, 'COM_USERS_PROFILE_SAVE_SUCCESS', 'Профиль сохранен', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(453, 'COM_USERS_PROFILE_TWO_FACTOR_AUTH', 'Двухфакторная аутентификация', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(454, 'COM_USERS_PROFILE_TWOFACTOR_LABEL', 'Тип аутентификации', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(455, 'COM_USERS_PROFILE_TWOFACTOR_DESC', 'Тип двухфакторной аутентификации для вашей учётной записи', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(456, 'COM_USERS_PROFILE_USERNAME_DESC', 'Введите желаемый логин', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(457, 'COM_USERS_PROFILE_USERNAME_LABEL', 'Логин', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(458, 'COM_USERS_PROFILE_USERNAME_MESSAGE', 'Введённый вами логин некорректен. Пожалуйста, введите другой логин.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(459, 'COM_USERS_PROFILE_VALUE_NOT_FOUND', 'Нет информации', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(460, 'COM_USERS_PROFILE_WELCOME', 'Добро пожаловать, %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(461, 'COM_USERS_REGISTER_DEFAULT_LABEL', 'Регистрация', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(462, 'COM_USERS_REGISTER_EMAIL1_DESC', 'Введите адрес электронной почты', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(463, 'COM_USERS_REGISTER_EMAIL1_LABEL', 'Адрес электронной почты', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(464, 'COM_USERS_REGISTER_EMAIL1_MESSAGE', 'Ваш адрес электронной почты уже используется или введён некорректно. Пожалуйста, введите другой адрес электронной почты.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(465, 'COM_USERS_REGISTER_EMAIL2_DESC', 'Подтвердите указанный вами адрес электронной почты', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(466, 'COM_USERS_REGISTER_EMAIL2_LABEL', 'Подтверждение адреса электронной почты:', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(467, 'COM_USERS_REGISTER_EMAIL2_MESSAGE', 'Адреса электронной почты не совпадают. Пожалуйста, введите ваш адрес электронной почты в поле адреса и в поле подтверждения.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(468, 'COM_USERS_REGISTER_NAME_DESC', 'Введите ваше полное имя', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(469, 'COM_USERS_REGISTER_NAME_LABEL', 'Имя', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(470, 'COM_USERS_REGISTER_PASSWORD1_LABEL', 'Пароль', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(471, 'COM_USERS_REGISTER_PASSWORD1_MESSAGE', 'Введённые вами пароли не совпадают. Пожалуйста, введите желаемый пароль в поле пароля и в поле подтверждения.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(472, 'COM_USERS_REGISTER_PASSWORD2_DESC', 'Подтверждение пароля', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(473, 'COM_USERS_REGISTER_PASSWORD2_LABEL', 'Повтор пароля', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(474, 'COM_USERS_REGISTER_REQUIRED', '<strong class=\"red\">*</strong> Обязательное поле', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(475, 'COM_USERS_REGISTER_USERNAME_DESC', 'Введите логин, под которым вы хотите входить на сайт', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(476, 'COM_USERS_REGISTER_USERNAME_LABEL', 'Логин', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(477, 'COM_USERS_REGISTER_USERNAME_MESSAGE', 'Введённый вами логин некорректен. Пожалуйста, введите другой логин.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(478, 'COM_USERS_REGISTRATION', 'Регистрация пользователя', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(479, 'COM_USERS_REGISTRATION_ACTIVATE_SUCCESS', 'Ваша учётная запись была успешно активирована. Теперь вы можете войти, используя логин и пароль, указанные при регистрации.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(480, 'COM_USERS_REGISTRATION_ACTIVATION_NOTIFY_SEND_MAIL_FAILED', 'При отправке e-mail с информацией об активации учётной записи пользователя произошла ошибка', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(481, 'COM_USERS_REGISTRATION_ACTIVATION_SAVE_FAILED', 'Не удалось сохранить данные об активации учётной записи: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(482, 'COM_USERS_REGISTRATION_ADMINACTIVATE_SUCCESS', 'Учётная запись пользователя была успешно активирована. Пользователю было отправлено уведомление об этом.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(483, 'COM_USERS_REGISTRATION_BIND_FAILED', 'Не удалось привязать регистрационные данные: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(484, 'COM_USERS_REGISTRATION_COMPLETE_ACTIVATE', 'Учётная запись для вас была создана. На указанный при регистрации адрес электронной почты была отправлена ссылка для её активации. Обратите внимание, что необходимо активировать учётную запись, перейдя по содержащейся в письме ссылке. Только после этого вы сможете проходить авторизацию на сайте под вашим логином и паролем.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(485, 'COM_USERS_REGISTRATION_COMPLETE_VERIFY', 'Учётная запись для вас была создана. На указанный при регистрации адрес электронной почты была отправлена ссылка для её активации. Обратите внимание, что необходимо подтвердить учётную запись, перейдя по содержащейся в письме ссылке. После этого Администратор активирует учётную запись и вы сможете входить на сайт под вашим логином и паролем.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(486, 'COM_USERS_REGISTRATION_DEFAULT_LABEL', 'Регистрация пользователя', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(487, 'COM_USERS_REGISTRATION_SAVE_FAILED', 'Не удалось зарегистрировать пользователя: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(488, 'COM_USERS_REGISTRATION_SAVE_SUCCESS', 'Спасибо за регистрацию. Теперь вы можете войти на сайт, используя логин и пароль, указанные при регистрации.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(489, 'COM_USERS_REGISTRATION_SEND_MAIL_FAILED', 'Произошла ошибка при отправке письма с регистрационными данными. Администратору сайта было отправлено сообщение о возникшей проблеме.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(490, 'COM_USERS_REGISTRATION_VERIFY_SUCCESS', 'Ваш адрес электронной почты был проверен успешно. Как только администратор активирует созданную учётную запись, вам будет отправлено сообщение по электронной почте, после чего вы сможете войти на сайт.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(491, 'COM_USERS_REMIND', 'Восстановление', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(492, 'COM_USERS_REMIND_DEFAULT_LABEL', 'Введите, пожалуйста, адрес электронной почты, указанный в параметрах вашей учётной записи. На этот адрес будет отправлено письмо, содержащее ваш Логин.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(493, 'COM_USERS_REMIND_EMAIL_LABEL', 'Ваш e-mail', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(494, 'COM_USERS_REMIND_LIMIT_ERROR_N_HOURS_1', 'Вы превысили максимально-допустимое количество попыток восстановления пароля. Пожалуйста, повторите попытку через 1 час.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(495, 'COM_USERS_REMIND_LIMIT_ERROR_N_HOURS_2', 'Вы превысили максимально-допустимое количество попыток восстановления пароля. Пожалуйста, повторите попытку через %s часов.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(496, 'COM_USERS_REMIND_LIMIT_ERROR_N_HOURS', 'Вы превысили максимально-допустимое количество попыток восстановления пароля. Пожалуйста, повторите попытку через %s часов.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(497, 'COM_USERS_REMIND_REQUEST_ERROR', 'Ошибка при напоминании пароля.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(498, 'COM_USERS_REMIND_REQUEST_FAILED', 'Не удалось восстановить данные: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(499, 'COM_USERS_REMIND_REQUEST_SUCCESS', 'Сообщение с информацией отправлено на указанный адрес. Пожалуйста, проверьте почту.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(500, 'COM_USERS_REMIND_SUPERADMIN_ERROR', 'Суперадминистратор не может запросить восстановление пароля. Пожалуйста, свяжитесь с другим Суперадминистратором или используйте альтернативный метод.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(501, 'COM_USERS_RESET', 'Восстановление пароля', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(502, 'COM_USERS_RESET_COMPLETE_ERROR', 'При восстановлении пароля произошла ошибка.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(503, 'COM_USERS_RESET_COMPLETE_FAILED', 'При восстановлении пароля произошла ошибка: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(504, 'COM_USERS_RESET_COMPLETE_LABEL', 'Введите, пожалуйста, новый пароль.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(505, 'COM_USERS_RESET_COMPLETE_SUCCESS', 'Пароль успешно восстановлен. Теперь вы можете войти на сайт.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(506, 'COM_USERS_RESET_CONFIRM_ERROR', 'При подтверждении пароля произошла ошибка.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(507, 'COM_USERS_RESET_CONFIRM_FAILED', 'Не удалось восстановить пароль, поскольку проверочный код был указан неверно. %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(508, 'COM_USERS_RESET_CONFIRM_LABEL', 'На ваш адрес электронной почты было отправлено письмо, содержащее проверочный код. Введите его, пожалуйста, в поле ниже. Это подтвердит, что именно вы являетесь владельцем данной учётной записи.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(509, 'COM_USERS_RESET_COMPLETE_TOKENS_MISSING', 'Восстановление пароля не выполнено, поскольку отсутствует проверочный код.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(510, 'COM_USERS_RESET_REQUEST_ERROR', 'Ошибка при восстановлении пароля.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(511, 'COM_USERS_RESET_REQUEST_FAILED', 'Ошибка при восстановлении пароля: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(512, 'COM_USERS_RESET_REQUEST_LABEL', 'Пожалуйста, введите адрес электронной почты, указанный в параметрах вашей учётной записи. На него будет отправлен специальный проверочный код. После его получения вы сможете ввести новый пароль для вашей учётной записи.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(513, 'COM_USERS_SETTINGS_FIELDSET_LABEL', 'Основные настройки', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(514, 'COM_USERS_USER_BLOCKED', 'Этот пользователь заблокирован. Если вы считаете, что это сделано по ошибке, пожалуйста, сообщите администратору сайта.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(515, 'COM_USERS_USER_FIELD_BACKEND_LANGUAGE_DESC', 'Выберите предпочтительный лично для вас язык панели управления.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(516, 'COM_USERS_USER_FIELD_BACKEND_LANGUAGE_LABEL', 'Язык панели управления', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(517, 'COM_USERS_USER_FIELD_BACKEND_TEMPLATE_DESC', 'Выбор шаблона панели управления. Параметр будет применён только для данного пользователя.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(518, 'COM_USERS_USER_FIELD_BACKEND_TEMPLATE_LABEL', 'Шаблон панели управления', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(519, 'COM_USERS_USER_FIELD_EDITOR_DESC', 'Выберите предпочтительный лично для вас текстовый редактор', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(520, 'COM_USERS_USER_FIELD_EDITOR_LABEL', 'Редактор', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(521, 'COM_USERS_USER_FIELD_FRONTEND_LANGUAGE_DESC', 'Выберите предпочтительный лично для вас язык сайта.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(522, 'COM_USERS_USER_FIELD_FRONTEND_LANGUAGE_LABEL', 'Язык сайта', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(523, 'COM_USERS_USER_FIELD_HELPSITE_DESC', 'Сайт справочной системы панели управления', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(524, 'COM_USERS_USER_FIELD_HELPSITE_LABEL', 'Сайт справки', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(525, 'COM_USERS_USER_FIELD_TIMEZONE_DESC', 'Укажите ваш часовой пояс', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(526, 'COM_USERS_USER_FIELD_TIMEZONE_LABEL', 'Часовой пояс', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(527, 'COM_USERS_USER_NOT_FOUND', 'Пользователь не найден', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(528, 'COM_USERS_USER_SAVE_FAILED', 'Ошибка при сохранении информации о пользователе: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_users.ini'),
(529, 'COM_WEBLINKS_CAPTCHA_LABEL', 'Капча', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_weblinks.ini'),
(530, 'COM_WEBLINKS_CAPTCHA_DESC', 'Введите текст, который вы видите на картинке.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_weblinks.ini'),
(531, 'COM_WEBLINKS_CONTENT_TYPE_WEBLINK', 'Ссылка', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_weblinks.ini'),
(532, 'COM_WEBLINKS_CONTENT_TYPE_CATEGORY', 'Категория ссылок', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_weblinks.ini'),
(533, 'COM_WEBLINKS_DEFAULT_PAGE_TITLE', 'Каталог ссылок', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_weblinks.ini'),
(534, 'COM_WEBLINKS_EDIT', 'Изменить ссылку', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_weblinks.ini'),
(535, 'COM_WEBLINKS_ERR_TABLES_NAME', 'Ссылка с таким названием уже присутствует в выбранной категории. Введите другое название.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_weblinks.ini'),
(536, 'COM_WEBLINKS_ERR_TABLES_PROVIDE_URL', 'Пожалуйста, введите корректный URL-адрес', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_weblinks.ini'),
(537, 'COM_WEBLINKS_ERR_TABLES_TITLE', 'Необходимо указать название ссылки.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_weblinks.ini'),
(538, 'COM_WEBLINKS_ERROR_CATEGORY_NOT_FOUND', 'Категория ссылок не найдена', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_weblinks.ini'),
(539, 'COM_WEBLINKS_ERROR_UNIQUE_ALIAS', 'Другая ссылка с таким же алиасом уже присутствует в данной категории', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_weblinks.ini'),
(540, 'COM_WEBLINKS_ERROR_WEBLINK_NOT_FOUND', 'Ссылка не найдена', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_weblinks.ini'),
(541, 'COM_WEBLINKS_ERROR_WEBLINK_URL_INVALID', 'URL-адрес ссылки не корректен', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_weblinks.ini'),
(542, 'COM_WEBLINKS_FIELD_ALIAS_DESC', 'Алиас используется только для внутренних нужд системы. Оставьте это&#160;поле пустым и Joomla автоматически заполнит его значением, созданным на основе названия ссылки. В одной категории не должно быть двух ссылок с одинаковым алиасом.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_weblinks.ini'),
(543, 'COM_WEBLINKS_FIELD_CATEGORY_DESC', 'Вы должны выбрать категорию', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_weblinks.ini'),
(544, 'COM_WEBLINKS_FIELD_DESCRIPTION_DESC', 'В это поле можно ввести описание ссылки', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_weblinks.ini'),
(545, 'COM_WEBLINKS_FILTER_LABEL', 'Фильтр', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_weblinks.ini'),
(546, 'COM_WEBLINKS_FILTER_SEARCH_DESC', 'Фильтр поиска по ссылкам', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_weblinks.ini'),
(547, 'COM_WEBLINKS_FIELD_TITLE_DESC', 'Необходимо ввести название ссылки.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_weblinks.ini'),
(548, 'COM_WEBLINKS_FIELD_URL_DESC', 'Необходимо ввести ссылку (URL).', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_weblinks.ini'),
(549, 'COM_WEBLINKS_FIELD_URL_LABEL', 'Ссылка (URL)', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_weblinks.ini'),
(550, 'COM_WEBLINKS_FORM_CREATE_WEBLINK', 'Добавить ссылку', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_weblinks.ini'),
(551, 'COM_WEBLINKS_GRID_TITLE', 'Название', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_weblinks.ini'),
(552, 'COM_WEBLINKS_LINK', 'Ссылка', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_weblinks.ini'),
(553, 'COM_WEBLINKS_NAME', 'Название', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_weblinks.ini'),
(554, 'COM_WEBLINKS_NO_WEBLINKS', 'В этой категории отсутствуют ссылки', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_weblinks.ini'),
(555, 'COM_WEBLINKS_NUM', 'Кол-во ссылок:', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_weblinks.ini'),
(556, 'COM_WEBLINKS_NUM_ITEMS', 'Ссылки в категории', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_weblinks.ini'),
(557, 'COM_WEBLINKS_FORM_EDIT_WEBLINK', 'Редактирование ссылки', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_weblinks.ini'),
(558, 'COM_WEBLINKS_FORM_SUBMIT_WEBLINK', 'Добавление новой ссылки', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_weblinks.ini'),
(559, 'COM_WEBLINKS_SAVE_SUCCESS', 'Ссылка успешно сохранена', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_weblinks.ini'),
(560, 'COM_WEBLINKS_SUBMIT_SAVE_SUCCESS', 'Ссылка успешно добавлена', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_weblinks.ini'),
(561, 'COM_WEBLINKS_WEB_LINKS', 'Ссылки', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_weblinks.ini'),
(562, 'JGLOBAL_NEWITEMSLAST_DESC', 'Новые ссылки по умолчанию располагаются последними. Очерёдность может быть изменена после сохранения новой ссылки.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_weblinks.ini'),
(563, 'COM_WRAPPER_NO_IFRAMES', 'Эта функция работает неправильно. К сожалению, ваш браузер не поддерживает Inline Frames.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.com_wrapper.ini'),
(564, 'FILES_JOOMLA', 'CMS Joomla', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.files_joomla.sys.ini'),
(565, 'FILES_JOOMLA_ERROR_FILE_FOLDER', 'Ошибка удаления файла или директории %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.files_joomla.sys.ini'),
(566, 'FILES_JOOMLA_ERROR_MANIFEST', 'Ошибка обновления кэша манифеста: (тип, элемент, директория, клиент) = (%s, %s, %s, %s)', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.files_joomla.sys.ini'),
(567, 'FILES_JOOMLA_XML_DESCRIPTION', 'Система управления сайтом Joomla! 3', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.files_joomla.sys.ini'),
(568, 'FINDER_CLI', 'Индексатор системы <strong>Умный Поиск</strong>', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.finder_cli.ini'),
(569, 'FINDER_CLI_BATCH_COMPLETE', ' * Обработано %s заданий за %s секунд.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.finder_cli.ini'),
(570, 'FINDER_CLI_FILTER_RESTORE_WARNING', 'Предупреждение: Невозможно найти термин %s/%s в фильтре %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.finder_cli.ini'),
(571, 'FINDER_CLI_INDEX_PURGE', 'Очистка индекса', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.finder_cli.ini'),
(572, 'FINDER_CLI_INDEX_PURGE_FAILED', '- очистка индекса не удалась', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.finder_cli.ini'),
(573, 'FINDER_CLI_INDEX_PURGE_SUCCESS', '- индекс успешно очищен', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.finder_cli.ini'),
(574, 'FINDER_CLI_PEAK_MEMORY_USAGE', 'Пиковое использование памяти: %s байт', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.finder_cli.ini'),
(575, 'FINDER_CLI_PROCESS_COMPLETE', 'Общее время выполнения: %s секунд.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.finder_cli.ini'),
(576, 'FINDER_CLI_RESTORE_FILTER_COMPLETED', '- кол-во восстановленных фильтров: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.finder_cli.ini'),
(577, 'FINDER_CLI_RESTORE_FILTERS', 'Восстанавление фильтров', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.finder_cli.ini'),
(578, 'FINDER_CLI_SAVE_FILTER_COMPLETED', '- кол-во сохраненных фильтров: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.finder_cli.ini'),
(579, 'FINDER_CLI_SAVE_FILTERS', 'Сохранение фильтров', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.finder_cli.ini'),
(580, 'FINDER_CLI_SETTING_UP_PLUGINS', 'Подключение плагинов поиска', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.finder_cli.ini'),
(581, 'FINDER_CLI_SETUP_ITEMS', 'Создано %s объектов за %s секунд.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.finder_cli.ini'),
(582, 'FINDER_CLI_STARTING_INDEXER', 'Запуск индексатора', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.finder_cli.ini'),
(583, 'JERROR_PARSING_LANGUAGE_FILE', '&#160; имеются ошибки в строках %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(584, 'ERROR', 'Ошибка', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(585, 'MESSAGE', 'Сообщение', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(586, 'NOTICE', 'Внимание', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(587, 'WARNING', 'Предупреждение', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(588, 'J1', '1', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(589, 'J2', '2', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(590, 'J3', '3', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(591, 'J4', '4', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(592, 'J5', '5', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(593, 'J6', '6', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(594, 'J7', '7', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(595, 'J8', '8', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(596, 'J9', '9', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(597, 'J10', '10', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(598, 'J15', '15', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(599, 'J20', '20', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(600, 'J25', '25', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(601, 'J30', '30', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(602, 'J50', '50', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(603, 'J100', '100', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(604, 'J200', '200', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(605, 'J500', '500', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(606, 'JACTION_ADMIN', 'Настраивать', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(607, 'JACTION_ADMIN_GLOBAL', 'Суперадминистратор', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(608, 'JACTION_COMPONENT_SETTINGS', 'Параметры компонента', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(609, 'JACTION_CREATE', 'Создать', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(610, 'JACTION_DELETE', 'Удалить', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(611, 'JACTION_EDIT', 'Изменить', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(612, 'JACTION_EDITOWN', 'Изменять свои', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(613, 'JACTION_EDITSTATE', 'Изменять состояние', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(614, 'JACTION_LOGIN_ADMIN', 'Вход в панель управления', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(615, 'JACTION_LOGIN_SITE', 'Вход на сайт', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(616, 'JACTION_MANAGE', 'Управление компонентом', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(617, 'JADMINISTRATOR', 'Панель управления', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(618, 'JALL', 'Все', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(619, 'JALL_LANGUAGE', 'Все', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(620, 'JAPPLY', 'Сохранить', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(621, 'JARCHIVED', 'В архиве', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(622, 'JASSOCIATIONS', 'Также доступны:', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(623, 'JAUTHOR', 'Автор', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(624, 'JCANCEL', 'Отмена', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(625, 'JCATEGORY', 'Категория', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(626, 'JCLEAR', 'Очистить', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(627, 'JDATE', 'Дата', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(628, 'JDAY', 'День', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(629, 'JDEFAULT', 'По умолчанию', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(630, 'JDETAILS', 'Подробности', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(631, 'JDISABLED', 'Отключено', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(632, 'JEDITOR', 'Редактор', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(633, 'JENABLED', 'Включен', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini');
INSERT INTO `jm_overrider` (`id`, `constant`, `string`, `file`) VALUES
(634, 'JEXPIRED', 'Устарело', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(635, 'JFALSE', 'False', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(636, 'JFEATURED', 'Избранные', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(637, 'JHIDE', 'Скрыть', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(638, 'JINVALID_TOKEN', 'Неверный параметр', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(639, 'JINVALID_TOKEN_NOTICE', 'Маркер безопасности не прошел проверку. Запрос был прерван, чтобы предотвратить любое нарушение безопасности. Пожалуйста, попробуйте снова.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(640, 'JLOGIN', 'Войти', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(641, 'JLOGOUT', 'Выйти', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(642, 'JMONTH', 'Месяц', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(643, 'JNEW', 'Новый', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(644, 'JNEXT', 'Вперёд', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(645, 'JNEXT_TITLE', 'Следующий материал: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(646, 'JNO', 'Нет', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(647, 'JNONE', 'Не найдено', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(648, 'JNOTPUBLISHEDYET', 'Ещё не опубликовано', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(649, 'JNOTICE', 'Внимание', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(650, 'JOFF', 'Выкл.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(651, 'JOFFLINE_MESSAGE', 'Сайт закрыт на техническое обслуживание.<br />Пожалуйста, зайдите позже.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(652, 'JON', 'Вкл.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(653, 'JOPTIONS', 'Настройки', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(654, 'JPAGETITLE', '%1$s - %2$s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(655, 'JPREV', 'Назад', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(656, 'JPREVIOUS', 'Предыдущий', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(657, 'JPREVIOUS_TITLE', 'Предыдущий материал: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(658, 'JPUBLISHED', 'Опубликовано', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(659, 'JREGISTER', 'Регистрация', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(660, 'JREQUIRED', 'Обязательно', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(661, 'JSAVE', 'Сохранить', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(662, 'JSELECT', 'Выбрать', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(663, 'JSHOW', 'Показывать', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(664, 'JSITE', 'Сайт', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(665, 'JSTATUS', 'Состояние', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(666, 'JSUBMIT', 'Отправить', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(667, 'JTAG', 'Метки', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(668, 'JTAG_DESC', 'Добавление и удаление меток.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(669, 'JTAG_FIELD_SELECT_DESC', 'Выберите метку', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(670, 'JTOOLBAR', 'Панель инструментов', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(671, 'JTOOLBAR_VERSIONS', 'Версии', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(672, 'JTRASH', 'В корзину', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(673, 'JTRASHED', 'В корзине', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(674, 'JTRUE', 'True', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(675, 'JUNPUBLISHED', 'Не опубликовано', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(676, 'JUSER_TOOLS', 'Инструменты пользователя', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(677, 'JYEAR', 'Год', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(678, 'JYES', 'Да', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(679, 'JBROWSERTARGET_MODAL', 'Модально', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(680, 'JBROWSERTARGET_NEW', 'Открывать в новом окне', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(681, 'JBROWSERTARGET_PARENT', 'Открывать в родительском окне', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(682, 'JBROWSERTARGET_POPUP', 'Открывать во всплывающем окне', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(683, 'JERROR_ALERTNOAUTHOR', 'Для просмотра этой информации необходимо пройти авторизацию', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(684, 'JERROR_ALERTNOTEMPLATE', '<strong>Шаблон для данной страницы недоступен. Пожалуйста, сообщите об этом Администратору сайта.</strong>', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(685, 'JERROR_AN_ERROR_HAS_OCCURRED', 'Обнаружена ошибка.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(686, 'JERROR_COULD_NOT_FIND_TEMPLATE', 'Шаблон \"%s\" не найден.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(687, 'JERROR_ERROR', 'Ошибка', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(688, 'JERROR_LAYOUT_AN_OUT_OF_DATE_BOOKMARK_FAVOURITE', '<strong>просроченная закладка/избранное</strong>', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(689, 'JERROR_LAYOUT_ERROR_HAS_OCCURRED_WHILE_PROCESSING_YOUR_REQUEST', 'В процессе обработки вашего запроса произошла ошибка.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(690, 'JERROR_LAYOUT_GO_TO_THE_HOME_PAGE', 'Вернуться на Домашнюю страницу', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(691, 'JERROR_LAYOUT_HOME_PAGE', 'Домашняя страница', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(692, 'JERROR_LAYOUT_MIS_TYPED_ADDRESS', '<strong>неправильный адрес</strong>', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(693, 'JERROR_LAYOUT_NOT_ABLE_TO_VISIT', 'Вы не можете посетить текущую страницу по одной из причин:', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(694, 'JERROR_LAYOUT_PAGE_NOT_FOUND', 'Такой страницы не существует.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(695, 'JERROR_LAYOUT_PLEASE_CONTACT_THE_SYSTEM_ADMINISTRATOR', 'Если проблема повторится, пожалуйста, обратитесь к системному администратору сайта и сообщите об ошибке, описание которой приведено ниже.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(696, 'JERROR_LAYOUT_PLEASE_TRY_ONE_OF_THE_FOLLOWING_PAGES', 'Пожалуйста, перейдите на одну из следующих страниц:', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(697, 'JERROR_LAYOUT_PREVIOUS_ERROR', 'Предыдущая ошибка', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(698, 'JERROR_LAYOUT_REQUESTED_RESOURCE_WAS_NOT_FOUND', 'Запрашиваемый ресурс не найден.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(699, 'JERROR_LAYOUT_SEARCH', 'Вы можете воспользоваться поиском по сайту или перейти на главную страницу сайта.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(700, 'JERROR_LAYOUT_SEARCH_ENGINE_OUT_OF_DATE_LISTING', 'кэш поисковой системы ссылается на <strong>несуществующий документ</strong>', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(701, 'JERROR_LAYOUT_SEARCH_PAGE', 'Поиск по сайту', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(702, 'JERROR_LAYOUT_YOU_HAVE_NO_ACCESS_TO_THIS_PAGE', 'у вас <strong>нет права доступа</strong> на эту страницу', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(703, 'JERROR_LOADING_MENUS', 'Ошибка загрузки меню: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(704, 'JERROR_LOGIN_DENIED', 'У вас нет права доступа к закрытой части сайта.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(705, 'JERROR_NOLOGIN_BLOCKED', 'Вход запрещён! Ваша учётная запись заблокирована или ещё не активирована.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(706, 'JERROR_PAGE_NOT_FOUND', 'Страница не найдена', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(707, 'JERROR_SESSION_STARTUP', 'Ошибка инициализации сессии.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(708, 'JERROR_TABLE_BIND_FAILED', 'hmm %s ...', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(709, 'JERROR_USERS_PROFILE_NOT_FOUND', 'Профиль пользователя не найден', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(710, 'JFIELD_ACCESS_DESC', 'Уровень доступа для данной страницы', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(711, 'JFIELD_ACCESS_LABEL', 'Доступ', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(712, 'JFIELD_ALIAS_DESC', 'Алиас (псевдоним) применяется для создания сокращённой URL-ссылки (SEF URL). Если оставить это поле пустым, Joomla! заполнит его значением по умолчанию, созданным на основе заголовка объекта. Это значение будет зависеть от установленных на сайте параметров SEO (Общие настройки -> Сайт).<br /> В случае использования адресов страниц в формате Unicode, Алиас будет состоять из символов того же языка, что и заголовок. При желании можно вручную ввести любые символы в кодировке UTF-8 (т.е. создавать адреса на русском языке, как в Wiki), но следует помнить, что пробелы и некоторые другие служебные символы при этом будут заменены на дефисы.<br /> По умолчанию, без использования Unicode, Алиас генерируется из символов заголовка, переведённых в нижний регистр. Пробелы при этом также заменяются на тире. Можно ввести Алиас вручную, латинскими символами, используя строчные буквы и дефисы без пробелов. Допускается вводить символ подчёркивания. Если заголовок состоит не из латинских букв, значение алиаса будет состоять из текущей даты и времени.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(713, 'JFIELD_ALIAS_LABEL', 'Алиас', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(714, 'JFIELD_ALIAS_PLACEHOLDER', 'Автоматически создавать из заголовка', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(715, 'JFIELD_ALT_PAGE_TITLE_LABEL', 'Альтернативный заголовок страницы', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(716, 'JFIELD_CATEGORY_DESC', 'Категория', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(717, 'JFIELD_FIELDS_CATEGORY_DESC', 'Выберите категорию, в которую включено это поле.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(718, 'JFIELD_LANGUAGE_DESC', 'Назначить язык этому материалу.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(719, 'JFIELD_LANGUAGE_LABEL', 'Язык', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(720, 'JFIELD_META_DESCRIPTION_DESC', 'Необязательный текст для использования в качестве описания HTML-страницы. Как правило, этот текст используется поисковыми системами для показа описания страницы в результатах поиска.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(721, 'JFIELD_META_DESCRIPTION_LABEL', 'Мета-тег Description', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(722, 'JFIELD_META_KEYWORDS_DESC', 'Слова и фразы, разделённые запятыми, которые будут выведены в мета-теге Keywords HTML-страницы.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(723, 'JFIELD_META_KEYWORDS_LABEL', 'Мета-тег Keywords', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(724, 'JFIELD_META_RIGHTS_DESC', 'Описание авторских прав на данный материал.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(725, 'JFIELD_META_RIGHTS_LABEL', 'Авторские права', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(726, 'JFIELD_ORDERING_DESC', 'Порядок материалов в данной категории', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(727, 'JFIELD_ORDERING_LABEL', 'Порядок', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(728, 'JFIELD_PUBLISHED_DESC', 'Устанавливает состояние публикации.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(729, 'JFIELD_TITLE_DESC', 'Заголовок материала', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(730, 'JGLOBAL_ADD_CUSTOM_CATEGORY', 'Добавить новую категорию', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(731, 'JGLOBAL_ARTICLES', 'Материалы', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(732, 'JGLOBAL_FIELDS', 'Поля', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(733, 'JGLOBAL_AUTH_ACCESS_DENIED', 'В доступе отказано', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(734, 'JGLOBAL_AUTH_ACCESS_GRANTED', 'Доступ разрешён', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(735, 'JGLOBAL_AUTH_BIND_FAILED', 'Ошибка привязки к серверу LDAP', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(736, 'JGLOBAL_AUTH_CANCEL', 'Аутентификация отменена', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(737, 'JGLOBAL_AUTH_CURL_NOT_INSTALLED', 'Curl не установлен', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(738, 'JGLOBAL_AUTH_EMPTY_PASS_NOT_ALLOWED', 'Пустой пароль не допускается', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(739, 'JGLOBAL_AUTH_FAIL', 'Ошибка аутентификации', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(740, 'JGLOBAL_AUTH_FAILED', 'Не удалось проверить подлинность: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(741, 'JGLOBAL_AUTH_INCORRECT', 'Неправильное имя пользователя или пароль', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(742, 'JGLOBAL_AUTH_INVALID_PASS', 'Имя пользователя и пароль не совпадают или у вас ещё нет учётной записи на сайте', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(743, 'JGLOBAL_AUTH_INVALID_SECRETKEY', 'Неверный Секретный код для двухфакторной аутентификации.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(744, 'JGLOBAL_AUTH_NO_BIND', 'Невозможно привязать LDAP', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(745, 'JGLOBAL_AUTH_NO_CONNECT', 'Не удаётся подключиться к серверу LDAP', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(746, 'JGLOBAL_AUTH_NO_REDIRECT', 'Не удалось перенаправить на сервер: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(747, 'JGLOBAL_AUTH_NO_USER', 'Имя пользователя и пароль не совпадают или у вас ещё нет учётной записи на сайте', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(748, 'JGLOBAL_AUTH_NOT_CREATE_DIR', 'Не удалось создать каталог %s. Пожалуйста, проверьте права доступа.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(749, 'JGLOBAL_AUTH_PASS_BLANK', 'Пароль LDAP не может быть пустым', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(750, 'JGLOBAL_AUTH_UNKNOWN_ACCESS_DENIED', 'Результат неизвестен. В доступе отказано', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(751, 'JGLOBAL_AUTH_USER_BLACKLISTED', 'Пользователь занесён в чёрный список', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(752, 'JGLOBAL_AUTH_USER_NOT_FOUND', 'Не удалось найти пользователя', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(753, 'JGLOBAL_AUTO', 'Авто', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(754, 'JGLOBAL_CATEGORY_NOT_FOUND', 'Категория не найдена', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(755, 'JGLOBAL_CENTER', 'Центр', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(756, 'JGLOBAL_CHECK_ALL', 'Выбрать все', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(757, 'JGLOBAL_CLICK_TO_SORT_THIS_COLUMN', 'Нажмите для сортировки по этому столбцу', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(758, 'JGLOBAL_CREATED_DATE_ON', 'Создано %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(759, 'JGLOBAL_CUSTOM_CATEGORY', 'Новые категории', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(760, 'JGLOBAL_DESCRIPTION', 'Описание', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(761, 'JGLOBAL_DISPLAY_NUM', 'Кол-во строк:', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(762, 'JGLOBAL_EDIT', 'Изменить', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(763, 'JGLOBAL_EDIT_TITLE', 'Изменить материал', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(764, 'JGLOBAL_EMAIL', 'E-mail', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(765, 'JGLOBAL_EMAIL_TITLE', 'Отправить ссылку другу', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(766, 'JGLOBAL_FIELD_CATEGORIES_CHOOSE_CATEGORY_DESC', 'Будут показаны категории, находящиеся в данной', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(767, 'JGLOBAL_FIELD_CATEGORIES_CHOOSE_CATEGORY_LABEL', 'Выберите категорию верхнего уровня', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(768, 'JGLOBAL_FIELD_CATEGORIES_DESC_DESC', 'Если вы введёте текст в этой области, он перепишет описание категории верхнего уровня, если оно имеется.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(769, 'JGLOBAL_FIELD_CATEGORIES_DESC_LABEL', 'Альтернативное описание', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(770, 'JGLOBAL_FIELD_CREATED_BY_ALIAS_DESC', 'Подменяет имя автора при отображении материала', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(771, 'JGLOBAL_FIELD_CREATED_BY_ALIAS_LABEL', 'Псевдоним автора', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(772, 'JGLOBAL_FIELD_CREATED_BY_DESC', 'Пользователь, который создал это.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(773, 'JGLOBAL_FIELD_CREATED_BY_LABEL', 'Автор', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(774, 'JGLOBAL_FIELD_CREATED_DESC', 'Дата создания', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(775, 'JGLOBAL_FIELD_CREATED_LABEL', 'Дата создания', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(776, 'JGLOBAL_FIELD_FEATURED_DESC', 'Связь материала с макетом блога избранных материалов', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(777, 'JGLOBAL_FIELD_FEATURED_LABEL', 'Избранные', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(778, 'JGLOBAL_FIELD_FIELD_CACHETIME_DESC', 'Количество минут до обновления кэша.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(779, 'JGLOBAL_FIELD_FIELD_ORDERING_LABEL', 'Порядок', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(780, 'JGLOBAL_FIELD_FIELD_ORDERING_DESC', 'Порядок отображения элементов', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(781, 'JGLOBAL_FIELD_ID_DESC', 'Номер записи в базе данных', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(782, 'JGLOBAL_FIELD_ID_LABEL', 'ID', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(783, 'JGLOBAL_FIELD_LAYOUT_DESC', 'Макет по умолчанию для отображения элемента', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(784, 'JGLOBAL_FIELD_LAYOUT_LABEL', 'Выбор макета', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(785, 'JGLOBAL_FIELD_MODIFIED_LABEL', 'Дата изменения', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(786, 'JGLOBAL_FIELD_MODIFIED_BY_DESC', 'Пользователь, который сделал последнее изменение', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(787, 'JGLOBAL_FIELD_MODIFIED_BY_LABEL', 'Изменил', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(788, 'JGLOBAL_FIELD_NUM_CATEGORY_ITEMS_DESC', 'Количество категорий для отображения на каждом уровне', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(789, 'JGLOBAL_FIELD_NUM_CATEGORY_ITEMS_LABEL', 'Количество категорий', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(790, 'JGLOBAL_FIELD_PUBLISH_DOWN_DESC', 'Дата снятия с публикации (не обязательно)', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(791, 'JGLOBAL_FIELD_PUBLISH_DOWN_LABEL', 'Завершение публикации', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(792, 'JGLOBAL_FIELD_PUBLISH_UP_DESC', 'Дата начала публикации (не обязательно)', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(793, 'JGLOBAL_FIELD_PUBLISH_UP_LABEL', 'Начало публикации', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(794, 'JGLOBAL_FIELD_SHOW_BASE_DESCRIPTION_DESC', 'Показывать описание категории верхнего уровня или заменять его текстом из поля Описание, введённым в параметрах пункта меню. При использовании корня (самого верхнего уровня) категорий, его поле Описание должно быть заполнено.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(795, 'JGLOBAL_FIELD_SHOW_BASE_DESCRIPTION_LABEL', 'Описание категории уровня выше', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(796, 'JGLOBAL_FIELD_VERSION_NOTE_DESC', 'Введите необязательный комментарий для данной версии объекта.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(797, 'JGLOBAL_FIELD_VERSION_NOTE_LABEL', 'Комментарий версии', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(798, 'JGLOBAL_FILTER_BUTTON', 'Применить', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(799, 'JGLOBAL_FILTER_LABEL', 'Фильтр', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(800, 'JGLOBAL_FULL_TEXT', 'Полный текст', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(801, 'JGLOBAL_GT', '&gt;', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(802, 'JGLOBAL_HELPREFRESH_BUTTON', 'Обновить', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(803, 'JGLOBAL_HITS', 'Просмотры', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(804, 'JGLOBAL_HITS_COUNT', 'Просмотров: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(805, 'JGLOBAL_ICON_SEP', '|', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(806, 'JGLOBAL_INHERIT', 'Наследовать', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(807, 'JGLOBAL_INTRO_TEXT', 'Вступительный текст', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(808, 'JGLOBAL_KEEP_TYPING', 'Продолжайте ввод...', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(809, 'JGLOBAL_LEFT', 'Слева', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(810, 'JGLOBAL_LOOKING_FOR', 'Поиск', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(811, 'JGLOBAL_LT', '&lt;', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(812, 'JGLOBAL_MAXIMUM_UPLOAD_SIZE_LIMIT', 'Максимальный размер загрузки: <strong>%s</strong>', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(813, 'JGLOBAL_NEWITEMSLAST_DESC', 'Новый элемент по умолчанию будет первым. Изменить порядок можно после сохранения.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(814, 'JGLOBAL_NO_MATCHING_RESULTS', 'Результаты отсутствуют', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(815, 'JGLOBAL_NUM', '№', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(816, 'JGLOBAL_OTPMETHOD_NONE', 'Отключить двухфакторную аутентификацию', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(817, 'JGLOBAL_PASSWORD', 'Пароль', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(818, 'JGLOBAL_PASSWORD_RESET_REQUIRED', 'Перед продолжением необходимо сбросить ваш текущий пароль.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(819, 'JGLOBAL_PRINT', 'Печать', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(820, 'JGLOBAL_PRINT_TITLE', 'Распечатать материал < %s >', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(821, 'JGLOBAL_RECORD_NUMBER', 'ID записи: %d', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(822, 'JGLOBAL_REMEMBER_ME', 'Запомнить меня', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(823, 'JGLOBAL_REMEMBER_MUST_LOGIN', 'Из соображений безопасности вам необходимо авторизоваться для редактирования вашей персональной информации.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(824, 'JGLOBAL_RESOURCE_NOT_FOUND', 'Ресурс не найден', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(825, 'JGLOBAL_RIGHT', 'Справа', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(826, 'JGLOBAL_ROOT', 'Корень', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(827, 'JGLOBAL_SECRETKEY', 'Секретный код', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(828, 'JGLOBAL_SECRETKEY_HELP', 'Если вы включили двухфакторную аутентификацию для вашей учётной записи, введите ваш секретный код. Если вы не знаете, что это такое - оставьте поле пустым.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(829, 'JGLOBAL_SELECT_AN_OPTION', 'Выберите значение', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(830, 'JGLOBAL_SELECT_NO_RESULTS_MATCH', 'Результаты не совпадают', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(831, 'JGLOBAL_SELECT_SOME_OPTIONS', 'Выберите несколько значений', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(832, 'JGLOBAL_START_PUBLISH_AFTER_FINISH', 'Дата начала публикации должна быть меньше даты окончания публикации', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(833, 'JGLOBAL_SUBCATEGORIES', 'Подкатегории', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(834, 'JGLOBAL_SUBHEADING_DESC', 'Произвольный текст для отображения в качестве подзаголовка.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(835, 'JGLOBAL_TITLE', 'Заголовок', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(836, 'JGLOBAL_TYPE_OR_SELECT_CATEGORY', 'Введите или выберите категорию', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(837, 'JGLOBAL_TYPE_OR_SELECT_SOME_OPTIONS', 'Введите или выберите несколько вариантов', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(838, 'JGLOBAL_USE_GLOBAL', 'По умолчанию', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(839, 'JGLOBAL_USE_GLOBAL_VALUE', 'Используйте глобальные (%s)', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(840, 'JGLOBAL_USERNAME', 'Логин', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(841, 'JGLOBAL_VALIDATION_FORM_FAILED', 'Неверная форма', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(842, 'JGLOBAL_YOU_MUST_LOGIN_FIRST', 'Пожалуйста, прежде пройдите авторизацию', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(843, 'JGRID_HEADING_ACCESS', 'Доступ', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(844, 'JGRID_HEADING_ID', 'ID', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(845, 'JGRID_HEADING_LANGUAGE', 'Язык', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(846, 'JLIB_DATABASE_ERROR_ADAPTER_MYSQL', 'MySQL-адаптер \'mysql\' недоступен.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(847, 'JLIB_DATABASE_ERROR_ADAPTER_MYSQLI', 'MySQLi-адаптер \'mysqli\' недоступен.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(848, 'JLIB_DATABASE_ERROR_CONNECT_DATABASE', 'Не удаётся подключиться к базе данных: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(849, 'JLIB_DATABASE_ERROR_CONNECT_MYSQL', 'Не удаётся подключиться к MySQL.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(850, 'JLIB_DATABASE_ERROR_DATABASE_CONNECT', 'Не удаётся подключиться к базе данных', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(851, 'JLIB_DATABASE_ERROR_LOAD_DATABASE_DRIVER', 'Не удалось загрузить драйвер базы данных: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(852, 'JLIB_ERROR_INFINITE_LOOP', 'В JError обнаружен бесконечный цикл', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(853, 'JOPTION_DO_NOT_USE', '- Не выбрано ни одного -', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(854, 'JOPTION_SELECT_ACCESS', '- Выберите уровень доступа -', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(855, 'JOPTION_SELECT_AUTHOR', '- Выберите автора -', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(856, 'JOPTION_SELECT_CATEGORY', '- Выберите категорию -', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(857, 'JOPTION_SELECT_LANGUAGE', '- Выберите язык -', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(858, 'JOPTION_SELECT_PUBLISHED', '- Выберите состояние -', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(859, 'JOPTION_SELECT_MAX_LEVELS', '- Выберите кол-во уровней -', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(860, 'JOPTION_SELECT_TAG', '- Выберите метку -', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(861, 'JOPTION_USE_DEFAULT', '- Использовать по умолчанию -', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(862, 'JSEARCH_FILTER_CLEAR', 'Очистить', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(863, 'JSEARCH_FILTER_LABEL', 'Фильтр', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(864, 'JSEARCH_FILTER_SUBMIT', 'Искать', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(865, 'JSEARCH_FILTER', 'Искать', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(866, 'DATE_FORMAT_LC', 'd.m.Y', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(867, 'DATE_FORMAT_LC1', 'd.m.Y', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(868, 'DATE_FORMAT_LC2', 'd.m.Y H:i', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(869, 'DATE_FORMAT_LC3', 'd F Y', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(870, 'DATE_FORMAT_LC4', 'd.m.Y', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(871, 'DATE_FORMAT_LC5', 'd-m-Y H:i', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(872, 'DATE_FORMAT_JS1', 'd.m.y', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(873, 'DATE_FORMAT_CALENDAR_DATE', '%d-%m-%Y', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(874, 'DATE_FORMAT_CALENDAR_DATETIME', '%d-%m-%Y %H:%M:%S', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(875, 'DATE_FORMAT_FILTER_DATE', 'd.m.Y', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(876, 'DATE_FORMAT_FILTER_DATETIME', 'd-m-Y H:i:s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(877, 'JANUARY_SHORT', 'янв', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(878, 'JANUARY', 'января', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(879, 'FEBRUARY_SHORT', 'фев', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(880, 'FEBRUARY', 'февраля', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(881, 'MARCH_SHORT', 'март', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(882, 'MARCH', 'марта', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(883, 'APRIL_SHORT', 'апр', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(884, 'APRIL', 'апреля', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(885, 'MAY_SHORT', 'мая', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(886, 'MAY', 'мая', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(887, 'JUNE_SHORT', 'июнь', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(888, 'JUNE', 'июня', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(889, 'JULY_SHORT', 'июль', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(890, 'JULY', 'июля', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(891, 'AUGUST_SHORT', 'авг', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(892, 'AUGUST', 'августа', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(893, 'SEPTEMBER_SHORT', 'сен', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(894, 'SEPTEMBER', 'сентября', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(895, 'OCTOBER_SHORT', 'окт', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(896, 'OCTOBER', 'октября', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(897, 'NOVEMBER_SHORT', 'нояб', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(898, 'NOVEMBER', 'ноября', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(899, 'DECEMBER_SHORT', 'дек', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(900, 'DECEMBER', 'декабря', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(901, 'SAT', 'Сб', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(902, 'SATURDAY', 'Суббота', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(903, 'SUN', 'Вс', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(904, 'SUNDAY', 'Воскресенье', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(905, 'MON', 'Пн', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(906, 'MONDAY', 'Понедельник', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(907, 'TUE', 'Вт', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(908, 'TUESDAY', 'Вторник', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(909, 'WED', 'Ср', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(910, 'WEDNESDAY', 'Среда', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(911, 'THU', 'Чт', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(912, 'THURSDAY', 'Четверг', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(913, 'FRI', 'Пт', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(914, 'FRIDAY', 'Пятница', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(915, 'DECIMALS_SEPARATOR', '.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(916, 'THOUSANDS_SEPARATOR', ' ', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(917, 'PHPMAILER_PROVIDE_ADDRESS', 'Необходимо указать хотя бы одного получателя электронной почты.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(918, 'PHPMAILER_MAILER_IS_NOT_SUPPORTED', 'Почтовый агент не поддерживается', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(919, 'PHPMAILER_EXECUTE', 'Не удалось выполнить: ', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(920, 'PHPMAILER_EXTENSION_MISSING', 'Отсутствует расширение: ', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(921, 'PHPMAILER_INSTANTIATE', 'Не удалось вызвать функцию mail.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(922, 'PHPMAILER_AUTHENTICATE', 'Ошибка SMTP! Не удалось пройти авторизацию.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(923, 'PHPMAILER_FROM_FAILED', 'Ошибка в перечисленных адресах отправителей: ', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(924, 'PHPMAILER_RECIPIENTS_FAILED', 'Ошибка SMTP! Следующие получатели недоступны: ', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(925, 'PHPMAILER_DATA_NOT_ACCEPTED', 'Ошибка SMTP! Данные были не приняты.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(926, 'PHPMAILER_CONNECT_HOST', 'Ошибка SMTP! Не удаётся подключиться к хосту SMTP.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(927, 'PHPMAILER_FILE_ACCESS', 'Не удалось получить доступ к файлу: ', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(928, 'PHPMAILER_FILE_OPEN', 'Файловая ошибка: Не удалось открыть файл: ', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(929, 'PHPMAILER_ENCODING', 'Неизвестная кодировка: ', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(930, 'PHPMAILER_SIGNING_ERROR', 'Ошибка отправки письма: ', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(931, 'PHPMAILER_SMTP_ERROR', 'Ошибка SMTP: ', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(932, 'PHPMAILER_EMPTY_MESSAGE', 'Пустое тело письма', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(933, 'PHPMAILER_INVALID_ADDRESS', 'Некорректный адрес', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(934, 'PHPMAILER_VARIABLE_SET', 'Ошибка установки/сброса переменной: ', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(935, 'PHPMAILER_SMTP_CONNECT_FAILED', 'Ошибка подключения к SMTP', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(936, 'PHPMAILER_TLS', 'Не удалось запустить TLS', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(937, 'MYSQL', 'MySQL', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(938, 'MYSQLI', 'MySQLi', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(939, 'ORACLE', 'Oracle', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(940, 'PDOMYSQL', 'MySQL (PDO)', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(941, 'POSTGRESQL', 'PostgreSQL', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(942, 'SQLAZURE', 'Microsoft SQL Azure', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(943, 'SQLITE', 'SQLite', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(944, 'SQLSRV', 'Microsoft SQL Server', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(945, 'JSEARCH_TOOLS', 'Фильтрация', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(946, 'JSEARCH_TOOLS_DESC', 'Фильтрация списка.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(947, 'JSEARCH_TOOLS_ORDERING', 'Порядок отображения:', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.ini'),
(948, 'LIB_FOF_DOWNLOAD_ERR_COULDNOTDOWNLOADFROMURL', 'Не удалось загрузить из %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_fof.ini'),
(949, 'LIB_FOF_DOWNLOAD_ERR_COULDNOTWRITELOCALFILE', 'Редактирование локального файла %s запрещено', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_fof.ini'),
(950, 'LIB_FOF_DOWNLOAD_ERR_CURL_ERROR', 'Ошибка загрузки: Ошибка cURL %s: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_fof.ini'),
(951, 'LIB_FOF_DOWNLOAD_ERR_HTTPERROR', 'Неожиданный HTTP статус %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_fof.ini'),
(952, 'LIB_FOF_XML_DESCRIPTION', 'Framework-on-Framework (FOF) — фреймворк для быстрой разработки расширений Joomla!', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_fof.sys.ini'),
(953, 'LIB_IDNA', 'IDNA Convert', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_idna_convert.sys.ini'),
(954, 'LIB_IDNA_XML_DESCRIPTION', 'Класс idna_convert предназначен для преобразования интернационализованных доменных имён (см. подробнее  RFC 3490, 3491, 3492 и 3454) - из формы содержащей символы национальных алфавитов, в форму, используемую в DNS (символы ASCII).', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_idna_convert.sys.ini'),
(955, 'JERROR_PARSING_LANGUAGE_FILE', '&#160; имеются ошибки в строках %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(956, 'JLIB_APPLICATION_ERROR_ACCESS_FORBIDDEN', 'Доступ запрещён', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(957, 'JLIB_APPLICATION_ERROR_APPLICATION_GET_NAME', 'JApplication: :getName() : Не может получить или обработать имя класса.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(958, 'JLIB_APPLICATION_ERROR_APPLICATION_LOAD', 'Не удалось загрузить приложение: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(959, 'JLIB_APPLICATION_ERROR_BATCH_CANNOT_CREATE', 'У вас нет прав на создание новых элементов в данной категории.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(960, 'JLIB_APPLICATION_ERROR_BATCH_CANNOT_EDIT', 'У вас нет прав на редактирование одно или нескольких элементов.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(961, 'JLIB_APPLICATION_ERROR_BATCH_FAILED', 'Пакетная операция завершилась с ошибкой: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(962, 'JLIB_APPLICATION_ERROR_BATCH_MOVE_CATEGORY_NOT_FOUND', 'Категория, в которую выполняется перемещение, не найдена.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(963, 'JLIB_APPLICATION_ERROR_BATCH_MOVE_ROW_NOT_FOUND', 'Перемещаемый объект не найден.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(964, 'JLIB_APPLICATION_ERROR_CHECKIN_FAILED', 'Снятие блокировки прервано из-за следующей ошибки: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(965, 'JLIB_APPLICATION_ERROR_CHECKIN_NOT_CHECKED', 'Объект не был заблокирован', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(966, 'JLIB_APPLICATION_ERROR_CHECKIN_USER_MISMATCH', 'Пользователь, пытающийся снять блокировку, не тот, который её установил.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(967, 'JLIB_APPLICATION_ERROR_CHECKOUT_FAILED', 'установка блокировки прервана с ошибкой: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(968, 'JLIB_APPLICATION_ERROR_CHECKOUT_USER_MISMATCH', 'Пользователь, пытающийся установить блокировку, не тот, который уже установил её ранее.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(969, 'JLIB_APPLICATION_ERROR_COMPONENT_NOT_FOUND', 'Компонент не найден', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(970, 'JLIB_APPLICATION_ERROR_COMPONENT_NOT_LOADING', 'Ошибка при загрузке компонента: %1$s, %2$s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(971, 'JLIB_APPLICATION_ERROR_CONTROLLER_GET_NAME', 'JController: :getName() : Не может получить или опознать имя класса.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(972, 'JLIB_APPLICATION_ERROR_CREATE_RECORD_NOT_PERMITTED', 'Создание записей не допускается', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(973, 'JLIB_APPLICATION_ERROR_DELETE_NOT_PERMITTED', 'Удаление не допускается', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(974, 'JLIB_APPLICATION_ERROR_EDITSTATE_NOT_PERMITTED', 'Изменение состояния не допускается', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(975, 'JLIB_APPLICATION_ERROR_EDIT_ITEM_NOT_PERMITTED', 'Правка не допускается', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(976, 'JLIB_APPLICATION_ERROR_EDIT_NOT_PERMITTED', 'Правка не допускается', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(977, 'JLIB_APPLICATION_ERROR_HISTORY_ID_MISMATCH', 'Ошибка восстановления версии элемента из истории.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(978, 'JLIB_APPLICATION_ERROR_INSUFFICIENT_BATCH_INFORMATION', 'Недостаточно данных для выполнения пакетной операции', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(979, 'JLIB_APPLICATION_ERROR_INVALID_CONTROLLER_CLASS', 'Неверный класс контроллера: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(980, 'JLIB_APPLICATION_ERROR_INVALID_CONTROLLER', 'Недействительный контроллер: имя = \'%s\', формат = \'%s\'', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(981, 'JLIB_APPLICATION_ERROR_LAYOUTFILE_NOT_FOUND', 'Макет %s не найден', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(982, 'JLIB_APPLICATION_ERROR_LIBRARY_NOT_FOUND', 'Библиотека не найдена', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(983, 'JLIB_APPLICATION_ERROR_LIBRARY_NOT_LOADING', 'Ошибка загрузки библиотеки: %1$s, %2$s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(984, 'JLIB_APPLICATION_ERROR_MENU_LOAD', 'Ошибка загрузки меню: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(985, 'JLIB_APPLICATION_ERROR_MODEL_GET_NAME', 'JModel:: GetName (): Не удаётся получить или разобрать имя класса.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(986, 'JLIB_APPLICATION_ERROR_MODULE_LOAD', 'Ошибка при загрузке модуля %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(987, 'JLIB_APPLICATION_ERROR_PATHWAY_LOAD', 'Не удаётся загрузить пути: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(988, 'JLIB_APPLICATION_ERROR_REORDER_FAILED', 'Изменение порядка не удалось. Ошибка: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(989, 'JLIB_APPLICATION_ERROR_ROUTER_LOAD', 'Не удаётся загрузить маршрутизатор: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(990, 'JLIB_APPLICATION_ERROR_MODELCLASS_NOT_FOUND', 'Модель класса %s не найдена в файле', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(991, 'JLIB_APPLICATION_ERROR_SAVE_FAILED', 'Сохранить не удалось из-за ошибки: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(992, 'JLIB_APPLICATION_ERROR_SAVE_NOT_PERMITTED', 'Сохранение не разрешено', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(993, 'JLIB_APPLICATION_ERROR_TABLE_NAME_NOT_SUPPORTED', 'Таблица %s не поддерживается. Файл не найден.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(994, 'JLIB_APPLICATION_ERROR_TASK_NOT_FOUND', 'Задача [%s] не найдена', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(995, 'JLIB_APPLICATION_ERROR_UNHELD_ID', 'У вас нет прав на доступ к данной странице по прямой ссылке (#%d).', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(996, 'JLIB_APPLICATION_ERROR_VIEW_CLASS_NOT_FOUND', 'Класс представления не найден [class, file]: %1$s, %2$s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(997, 'JLIB_APPLICATION_ERROR_VIEW_GET_NAME_SUBSTRING', 'JView: :getName (): Имя вашего класса содержит подстроку \'view\'. Это вызывает проблемы при извлечении имени класса из имени представления объектов. Избегайте создания имён объектов, содержащих строку \'view\'.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(998, 'JLIB_APPLICATION_ERROR_VIEW_GET_NAME', 'JView: :getName (): Невозможно получить или разобрать имя класса.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(999, 'JLIB_APPLICATION_ERROR_VIEW_NOT_FOUND', 'Представление не найдено [name, type, prefix]: %1$s, %2$s, %3$s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1000, 'JLIB_APPLICATION_SAVE_SUCCESS', 'Пункт успешно сохранён.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1001, 'JLIB_APPLICATION_SUBMIT_SAVE_SUCCESS', 'Элемент успешно создан.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1002, 'JLIB_APPLICATION_SUCCESS_BATCH', 'Пакетная операция завершена успешно.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1003, 'JLIB_APPLICATION_SUCCESS_ITEM_REORDERED', 'Порядок успешно сохранён.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1004, 'JLIB_APPLICATION_SUCCESS_ORDERING_SAVED', 'Порядок успешно сохранён.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1005, 'JLIB_APPLICATION_SUCCESS_LOAD_HISTORY', 'Предыдущая версия успешно восстановлена. Сохранено в %s %s.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1006, 'JLIB_LOGIN_AUTHENTICATE', 'Логин или пароль введены неправильно, либо такой учётной записи ещё не существует.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1007, 'JLIB_CACHE_ERROR_CACHE_HANDLER_LOAD', 'Не удалось загрузить обработчик кэша: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1008, 'JLIB_CACHE_ERROR_CACHE_STORAGE_LOAD', 'Не удалось загрузить Cache Storage: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1009, 'JLIB_CAPTCHA_ERROR_PLUGIN_NOT_FOUND', 'Плагин CAPTCHA не найден (или не установлен). Пожалуйста, свяжитесь с администратором сайта', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1010, 'JLIB_CLIENT_ERROR_JFTP_NO_CONNECT', 'JFTP: :connect: Невозможно подключиться к серверу \' %1$s \' через порт \' %2$s \'', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini');
INSERT INTO `jm_overrider` (`id`, `constant`, `string`, `file`) VALUES
(1011, 'JLIB_CLIENT_ERROR_JFTP_NO_CONNECT_SOCKET', 'JFTP: :connect: Невозможно подключиться к серверу \' %1$s \' через порт \' %2$s \'. Ошибка сокета: %3$s и сообщение об ошибке: %4$s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1012, 'JLIB_CLIENT_ERROR_JFTP_BAD_RESPONSE', 'JFTP: :connect: Некорректный ответ. Ответ сервера: %s [Expected: 220]', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1013, 'JLIB_CLIENT_ERROR_JFTP_BAD_USERNAME', 'JFTP: :login: Неверный логин. Ответ сервера: %1$s [Ожидали: 331]. Отправлен логин: %2$s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1014, 'JLIB_CLIENT_ERROR_JFTP_BAD_PASSWORD', 'JFTP: :login: Неверный пароль. Ответ сервера: %1$s [Ожидали: 230]. Отправлен пароль: %2$s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1015, 'JLIB_CLIENT_ERROR_JFTP_PWD_BAD_RESPONSE_NATIVE', 'FTP: :pwd: Некорректный ответ', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1016, 'JLIB_CLIENT_ERROR_JFTP_PWD_BAD_RESPONSE', 'JFTP: :pwd: Некорректный ответ. Ответ сервера: %s [Ожидали: 257]', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1017, 'JLIB_CLIENT_ERROR_JFTP_SYST_BAD_RESPONSE_NATIVE', 'JFTP: :syst: Некорректный ответ', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1018, 'JLIB_CLIENT_ERROR_JFTP_SYST_BAD_RESPONSE', 'JFTP: :syst: Некорректный ответ. Ответ сервера: %s [Ожидали: 215]', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1019, 'JLIB_CLIENT_ERROR_JFTP_CHDIR_BAD_RESPONSE_NATIVE', 'JFTP: :chdir: Некорректный ответ', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1020, 'JLIB_CLIENT_ERROR_JFTP_CHDIR_BAD_RESPONSE', 'JFTP: :chdir: Некорректный ответ. Ответ сервера: %1$s [Ожидали: 250]. Передан путь: %2$s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1021, 'JLIB_CLIENT_ERROR_JFTP_REINIT_BAD_RESPONSE_NATIVE', 'JFTP: :reinit: Некорректный ответ', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1022, 'JLIB_CLIENT_ERROR_JFTP_REINIT_BAD_RESPONSE', 'JFTP: :reinit: Некорректный ответ. Ответ сервера: %s [Ожидали: 220]', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1023, 'JLIB_CLIENT_ERROR_JFTP_RENAME_BAD_RESPONSE_NATIVE', 'JFTP: :rename: Некорректный ответ', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1024, 'JLIB_CLIENT_ERROR_JFTP_RENAME_BAD_RESPONSE_FROM', 'JFTP: :rename: Некорректный ответ. Ответ сервера: %1$s [Ожидалось: 350]. Исходный путь: %2$s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1025, 'JLIB_CLIENT_ERROR_JFTP_RENAME_BAD_RESPONSE_TO', 'JFTP: :rename: Некорректный ответ. Ответ сервера: %1$s [Ожидали: 250]. К пути: %2$s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1026, 'JLIB_CLIENT_ERROR_JFTP_CHMOD_BAD_RESPONSE_NATIVE', 'JFTP: :chmod: Некорректный ответ', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1027, 'JLIB_CLIENT_ERROR_JFTP_CHMOD_BAD_RESPONSE', 'JFTP: :chmod: Некорректный ответ. Ответ сервера: %1$s [Ожидали: 250]. Передан путь: %2$s. Передан режим: %3$s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1028, 'JLIB_CLIENT_ERROR_JFTP_DELETE_BAD_RESPONSE_NATIVE', 'JFTP: :delete: Некорректный ответ', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1029, 'JLIB_CLIENT_ERROR_JFTP_DELETE_BAD_RESPONSE', 'JFTP: :delete: Некорректный ответ. Ответ сервера: %1$s [Ожидали: 250]. Передан путь: %2$s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1030, 'JLIB_CLIENT_ERROR_JFTP_MKDIR_BAD_RESPONSE_NATIVE', 'JFTP: :mkdir: Некорректный ответ', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1031, 'JLIB_CLIENT_ERROR_JFTP_MKDIR_BAD_RESPONSE', 'JFTP: :mkdir: Некорректный ответ. Ответ сервера: %1$s [Ожидали: 257]. Передан путь: %2$s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1032, 'JLIB_CLIENT_ERROR_JFTP_RESTART_BAD_RESPONSE_NATIVE', 'JFTP: :restart: Некорректный ответ', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1033, 'JLIB_CLIENT_ERROR_JFTP_RESTART_BAD_RESPONSE', 'JFTP: :restart: Некорректный ответ. Ответ сервера: %1$s [Ожидали: 350]. Отправлена точка рестарта: %2$s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1034, 'JLIB_CLIENT_ERROR_JFTP_CREATE_BAD_RESPONSE_BUFFER', 'JFTP: :create: Некорректный ответ', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1035, 'JLIB_CLIENT_ERROR_JFTP_CREATE_BAD_RESPONSE_PASSIVE', 'JFTP: :create: Невозможно использовать пассивный режим', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1036, 'JLIB_CLIENT_ERROR_JFTP_CREATE_BAD_RESPONSE', 'JFTP: :create: Некорректный ответ. Ответ сервера: %1$s [Ожидали: 150 или 125]. Передан путь: %2$s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1037, 'JLIB_CLIENT_ERROR_JFTP_CREATE_BAD_RESPONSE_TRANSFER', 'JFTP: :create: Передача прервана. Ответ сервера: %1$s [Ожидали: 226]. Передан путь: %2$s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1038, 'JLIB_CLIENT_ERROR_JFTP_READ_BAD_RESPONSE_BUFFER', 'JFTP: :read: Некорректный ответ', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1039, 'JLIB_CLIENT_ERROR_JFTP_READ_BAD_RESPONSE_PASSIVE', 'JFTP: :read: Невозможно использовать пассивный режим', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1040, 'JLIB_CLIENT_ERROR_JFTP_READ_BAD_RESPONSE', 'JFTP: :read: Некорректный ответ. Ответ сервера: %1$s [Ожидали: 150 или 125]. Передан путь: %2$s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1041, 'JLIB_CLIENT_ERROR_JFTP_READ_BAD_RESPONSE_TRANSFER', 'JFTP: :read: Передача прервана. Ответ сервера: %1$s [Ожидали: 226]. Передан путь: %2$s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1042, 'JLIB_CLIENT_ERROR_JFTP_GET_BAD_RESPONSE', 'JFTP: :get: Некорректный ответ', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1043, 'JLIB_CLIENT_ERROR_JFTP_GET_PASSIVE', 'JFTP: :get: Невозможно использовать пассивный режим', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1044, 'JLIB_CLIENT_ERROR_JFTP_GET_WRITING_LOCAL', 'JFTP: :get: Невозможно открыть локальный файл для записи Локальный путь: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1045, 'JLIB_CLIENT_ERROR_JFTP_GET_BAD_RESPONSE_RETR', 'JFTP: :get: Некорректный ответ. Ответ сервера: %1$s [Ожидали: 150 или 125]. Передан путь: %2$s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1046, 'JLIB_CLIENT_ERROR_JFTP_GET_BAD_RESPONSE_TRANSFER', 'JFTP: :get: Передача прервана. Ответ сервера: %1$s [Ожидали: 226]. Передан путь: %2$s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1047, 'JLIB_CLIENT_ERROR_JFTP_STORE_PASSIVE', 'JFTP: :store: Невозможно использовать пассивный режим', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1048, 'JLIB_CLIENT_ERROR_JFTP_STORE_BAD_RESPONSE', 'JFTP: :store: Некорректный ответ', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1049, 'JLIB_CLIENT_ERROR_JFTP_STORE_READING_LOCAL', 'JFTP: :store: Не удаётся открыть локальный файл для чтения. Локальный путь: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1050, 'JLIB_CLIENT_ERROR_JFTP_STORE_FIND_LOCAL', 'JFTP: :store: Не удаётся найти локальный файл. Локальный путь: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1051, 'JLIB_CLIENT_ERROR_JFTP_STORE_BAD_RESPONSE_STOR', 'JFTP: :store: Некорректный ответ. Ответ сервера: %1$s [Ожидали: 150 или 125]. Передан путь: %2$s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1052, 'JLIB_CLIENT_ERROR_JFTP_STORE_DATA_PORT', 'JFTP: :store: Не удаётся произвести запись данных в порт сокета', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1053, 'JLIB_CLIENT_ERROR_JFTP_STORE_BAD_RESPONSE_TRANSFER', 'JFTP: :store: Передача прервана. Ответ сервера: %1$s [Ожидали: 226]. Передан путь: %2$s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1054, 'JLIB_CLIENT_ERROR_JFTP_WRITE_PASSIVE', 'JFTP: :write: Невозможно использовать пассивный режим', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1055, 'JLIB_CLIENT_ERROR_JFTP_WRITE_BAD_RESPONSE', 'JFTP: :write: Некорректный ответ', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1056, 'JLIB_CLIENT_ERROR_JFTP_WRITE_BAD_RESPONSE_STOR', 'JFTP: :write: Некорректный ответ. Ответ сервера: %1$s [Ожидали: 150 или 125]. Передан путь: %2$s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1057, 'JLIB_CLIENT_ERROR_JFTP_WRITE_DATA_PORT', 'JFTP: :write: Не могу записать данные порта сокета', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1058, 'JLIB_CLIENT_ERROR_JFTP_WRITE_BAD_RESPONSE_TRANSFER', 'JFTP: :write: Передача прервана. Ответ сервера: %1$s [Ожидали: 226]. Передан путь: %2$s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1059, 'JLIB_CLIENT_ERROR_JFTP_APPEND_PASSIVE', 'JFTP: :append: Невозможно использовать пассивный режим', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1060, 'JLIB_CLIENT_ERROR_JFTP_APPEND_BAD_RESPONSE', 'JFTP: :append: Некорректный ответ', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1061, 'JLIB_CLIENT_ERROR_JFTP_APPEND_BAD_RESPONSE_APPE', 'JFTP: :append: Некорректный ответ. Ответ сервера: %1$s [Ожидали: 150 или 125]. Передан путь: %2$s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1062, 'JLIB_CLIENT_ERROR_JFTP_APPEND_DATA_PORT', 'JFTP: :append: Не удаётся произвести запись данных в порт сокета', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1063, 'JLIB_CLIENT_ERROR_JFTP_APPEND_BAD_RESPONSE_TRANSFER', 'JFTP: :append: Передача прервана. Ответ сервера: %1$s [Ожидали: 226]. Передан путь: %2$s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1064, 'JLIB_CLIENT_ERROR_JFTP_SIZE_BAD_RESPONSE', 'JFTP: :size: Некорректный ответ', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1065, 'JLIB_CLIENT_ERROR_JFTP_SIZE_PASSIVE', 'JFTP: :size: Невозможно использовать пассивный режим', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1066, 'JLIB_CLIENT_ERROR_JFTP_LISTNAMES_PASSIVE', 'JFTP: :listNames: Невозможно использовать пассивный режим', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1067, 'JLIB_CLIENT_ERROR_JFTP_LISTNAMES_BAD_RESPONSE', 'JFTP: :listNames: Некорректный ответ', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1068, 'JLIB_CLIENT_ERROR_JFTP_LISTNAMES_BAD_RESPONSE_NLST', 'JFTP: :listNames: Некорректный ответ. Ответ сервера: %1$s [Ожидали: 150 или 125]. Передан путь: %2$s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1069, 'JLIB_CLIENT_ERROR_JFTP_LISTNAMES_BAD_RESPONSE_TRANSFER', 'JFTP: :listNames: Передача прервана. Ответ сервера: %1$s [Ожидали: 226]. Передан путь: %2$s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1070, 'JLIB_CLIENT_ERROR_JFTP_LISTDETAILS_BAD_RESPONSE', 'JFTP: :listDetails: Некорректный ответ', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1071, 'JLIB_CLIENT_ERROR_JFTP_LISTDETAILS_PASSIVE', 'JFTP: :listDetails: Невозможно использовать пассивный режим', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1072, 'JLIB_CLIENT_ERROR_JFTP_LISTDETAILS_BAD_RESPONSE_LIST', 'JFTP: :listDetails: Некорректный ответ. Ответ сервера: %1$s [Ожидали: 150 или 125]. Передан путь: %2$s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1073, 'JLIB_CLIENT_ERROR_JFTP_LISTDETAILS_BAD_RESPONSE_TRANSFER', 'JFTP: :listDetails: Передача прервана. Ответ сервера: %1$s [Ожидали: 226]. Передан путь: %2$s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1074, 'JLIB_CLIENT_ERROR_JFTP_LISTDETAILS_UNRECOGNISED', 'JFTP: :listDetails: Неизвестный формат списка каталогов', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1075, 'JLIB_CLIENT_ERROR_JFTP_PUTCMD_UNCONNECTED', 'JFTP: :_putCmd: Не подключен к порту управления', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1076, 'JLIB_CLIENT_ERROR_JFTP_PUTCMD_SEND', 'JFTP: :_putCmd: Невозможно послать команду: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1077, 'JLIB_CLIENT_ERROR_JFTP_VERIFYRESPONSE', 'JFTP: :_verifyResponse: превышено время ожидания или не был распознан ответ во время ожидания ответа от сервера. Ответ сервера: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1078, 'JLIB_CLIENT_ERROR_JFTP_PASSIVE_CONNECT_PORT', 'JFTP: :_passive: Нет подключения к порту управления', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1079, 'JLIB_CLIENT_ERROR_JFTP_PASSIVE_RESPONSE', 'JFTP: :_passive: Тайм-аут или нераспознанный ответ во время ожидания ответа от сервера. Ответ сервера: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1080, 'JLIB_CLIENT_ERROR_JFTP_PASSIVE_IP_OBTAIN', 'JFTP: :_passive: Невозможно получить IP и порт для передачи данных. Ответ сервера: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1081, 'JLIB_CLIENT_ERROR_JFTP_PASSIVE_IP_VALID', 'JFTP: :_passive: IP и порт для передачи данных не действительны. Ответ сервера: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1082, 'JLIB_CLIENT_ERROR_JFTP_PASSIVE_CONNECT', 'JFTP: :_passive: Невозможно подключиться к серверу %1$s через порт %2$s. Ошибка сокета: %3$s и сообщение об ошибке: %4$s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1083, 'JLIB_CLIENT_ERROR_JFTP_MODE_BINARY', 'JFTP: :_mode: Некорректный ответ. Ответ сервера: %s [Ожидали: 200]. Передан режим: Binary', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1084, 'JLIB_CLIENT_ERROR_JFTP_MODE_ASCII', 'JFTP: :_mode: Некорректный ответ. Ответ сервера: %s [Ожидали: 200]. Передан режим: Ascii', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1085, 'JLIB_CLIENT_ERROR_HELPER_SETCREDENTIALSFROMREQUEST_FAILED', 'Похоже, что учётные данные пользователя не корректны...', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1086, 'JLIB_CLIENT_ERROR_LDAP_ADDRESS_NOT_AVAILABLE', 'Адрес недоступен.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1087, 'JLIB_CMS_WARNING_PROVIDE_VALID_NAME', 'Пожалуйста, введите корректный, не пустой заголовок.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1088, 'JLIB_DATABASE_ERROR_ADAPTER_MYSQL', 'Адаптер \'mysql\' для СУБД MySQL недоступен.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1089, 'JLIB_DATABASE_ERROR_ADAPTER_MYSQLI', 'Адаптер \'mysqli\' для СУБД MySQLi недоступен.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1090, 'JLIB_DATABASE_ERROR_BIND_FAILED_INVALID_SOURCE_ARGUMENT', '%s: :bind не выполнен. Неправильный аргумент.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1091, 'JLIB_DATABASE_ERROR_ARTICLE_UNIQUE_ALIAS', 'Другой материал из этой категории уже имеет такой алиас', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1092, 'JLIB_DATABASE_ERROR_CATEGORY_UNIQUE_ALIAS', 'Другая категория с той же родительской категорией уже содержит такой алиас', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1093, 'JLIB_DATABASE_ERROR_CHECK_FAILED', '%s: :check не выполнен - %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1094, 'JLIB_DATABASE_ERROR_CHECKIN_FAILED', '%s: :checkIn не выполнен - %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1095, 'JLIB_DATABASE_ERROR_CHECKOUT_FAILED', '%s: :checkOut не выполнен - %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1096, 'JLIB_DATABASE_ERROR_CHILD_ROWS_CHECKED_OUT', 'Дочерняя запись заблокирована.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1097, 'JLIB_DATABASE_ERROR_CLASS_DOES_NOT_SUPPORT_ORDERING', '%s не поддерживает сортировку.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1098, 'JLIB_DATABASE_ERROR_CLASS_IS_MISSING_FIELD', 'В базе данных отсутствует поле: %s &#160; %s.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1099, 'JLIB_DATABASE_ERROR_CLASS_NOT_FOUND_IN_FILE', 'Класс таблицы %s не найден в файле.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1100, 'JLIB_DATABASE_ERROR_CONNECT_DATABASE', 'Не удаётся подключиться к базе данных: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1101, 'JLIB_DATABASE_ERROR_CONNECT_MYSQL', 'Не удаётся подключиться к MySQL.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1102, 'JLIB_DATABASE_ERROR_DATABASE_CONNECT', 'Не удаётся подключиться к базе данных', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1103, 'JLIB_DATABASE_ERROR_DATABASE_UPGRADE_FAILED', 'Не удалось обновить базу данных MySQL. Проверьте в Менеджер расширений -> <a href=\"index.php?option=com_installer&view=database\">База данных</a>.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1104, 'JLIB_DATABASE_ERROR_DELETE_CATEGORY', 'Данные слева и справа не соответствуют. Невозможно удалить категорию.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1105, 'JLIB_DATABASE_ERROR_DELETE_FAILED', '%s: :delete не выполнен - %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1106, 'JLIB_DATABASE_ERROR_DELETE_ROOT_CATEGORIES', 'Категории родительского уровня не могут быть удалены.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1107, 'JLIB_DATABASE_ERROR_EMAIL_INUSE', 'Этот адрес уже зарегистрирован.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1108, 'JLIB_DATABASE_ERROR_EMPTY_ROW_RETURNED', 'Строка в базе данных пуста.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1109, 'JLIB_DATABASE_ERROR_FUNCTION_FAILED', 'Ошибка базы данных с номером %s <br /><span style=\"color: red;\">%s</span>', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1110, 'JLIB_DATABASE_ERROR_GET_NEXT_ORDER_FAILED', '%s: :getNextOrder не выполнен - %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1111, 'JLIB_DATABASE_ERROR_GET_TREE_FAILED', '%s: :getTree не выполнен - %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1112, 'JLIB_DATABASE_ERROR_GETNODE_FAILED', '%s: :_getNode не выполнен - %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1113, 'JLIB_DATABASE_ERROR_GETROOTID_FAILED', '%s: :getRootId не выполнен - %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1114, 'JLIB_DATABASE_ERROR_HIT_FAILED', '%s: :hit не выполнен - %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1115, 'JLIB_DATABASE_ERROR_INVALID_LOCATION', '%s: :setLocation - Недопустимое расположение', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1116, 'JLIB_DATABASE_ERROR_INVALID_NODE_RECURSION', '%s: :move Failed - Нельзя переместить узел сам в себя', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1117, 'JLIB_DATABASE_ERROR_INVALID_PARENT_ID', 'Неверный ID родителя.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1118, 'JLIB_DATABASE_ERROR_LANGUAGE_NO_TITLE', 'Язык должен иметь название', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1119, 'JLIB_DATABASE_ERROR_LANGUAGE_UNIQUE_IMAGE', 'Обнаружен язык контента в котором уже используется выбранный Префикс изображения', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1120, 'JLIB_DATABASE_ERROR_LANGUAGE_UNIQUE_LANG_CODE', 'Обнаружен язык контента в котором уже используется выбранный Тег языка', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1121, 'JLIB_DATABASE_ERROR_LANGUAGE_UNIQUE_SEF', 'Обнаружен язык контента в котором уже используется выбранный Код языка для URL', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1122, 'JLIB_DATABASE_ERROR_LOAD_DATABASE_DRIVER', 'Не удалось загрузить драйвер базы данных: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1123, 'JLIB_DATABASE_ERROR_MENUTYPE', 'Некоторые пункты меню или некоторые модули меню, связанные с этим типом меню заблокированы другим пользователем или являются пунктом по умолчанию в этом меню', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1124, 'JLIB_DATABASE_ERROR_MENUTYPE_CHECKOUT', 'Вы пытаетесь изменить пункт/модуль меню, который был заблокирован другим пользователем.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1125, 'JLIB_DATABASE_ERROR_MENUTYPE_EMPTY', 'Тип меню пустой', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1126, 'JLIB_DATABASE_ERROR_MENUTYPE_EXISTS', 'Тип меню существует: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1127, 'JLIB_DATABASE_ERROR_MENU_CANNOT_UNSET_DEFAULT', 'Параметру языка данного пункта меню должно быть присвоено значение \'Все\'. Как минимум один пункт меню, из тех, что назначены пунктом \'по умолчанию\', должен быть привязан ко всем языкам, даже если сайт является многоязычным.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1128, 'JLIB_DATABASE_ERROR_MENU_CANNOT_UNSET_DEFAULT_DEFAULT', 'Как минимум один пункт меню должен быть отмечен как \'По умолчанию\'.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1129, 'JLIB_DATABASE_ERROR_MENU_UNPUBLISH_DEFAULT_HOME', 'Нельзя снимать с публикации пункт меню, назначенный \'главной страницей\'', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1130, 'JLIB_DATABASE_ERROR_MENU_DEFAULT_CHECKIN_USER_MISMATCH', 'Текущее главное меню для данного языка заблокировано другим пользователем', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1131, 'JLIB_DATABASE_ERROR_MENU_UNIQUE_ALIAS', 'Другой пункт меню с таким же родителем, уже содержит такой Алиас', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1132, 'JLIB_DATABASE_ERROR_MENU_UNIQUE_ALIAS_ROOT', 'Другой пункт меню, верхнего уровня, уже содержит такой Алиас', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1133, 'JLIB_DATABASE_ERROR_MENU_HOME_NOT_COMPONENT', 'Пункт меню, являющийся \'главной страницей\' сайта, должен ссылаться на компонент.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1134, 'JLIB_DATABASE_ERROR_MENU_HOME_NOT_UNIQUE_IN_MENU', 'Меню должно содержать только один пункт, отмеченный как \'главная страница\'.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1135, 'JLIB_DATABASE_ERROR_MENU_ROOT_ALIAS_COMPONENT', 'Алиас пункта меню, находящегося на первом уровне вложенности, не может быть \'component\'.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1136, 'JLIB_DATABASE_ERROR_MENU_ROOT_ALIAS_FOLDER', 'Алиас пункта меню первого уровня не может быть \'%s\' поскольку \'%s\' совпадает с именем подкаталога в каталоге с системными файлами Joomla!.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1137, 'JLIB_DATABASE_ERROR_MOVE_FAILED', '%s: :move Ошибка - %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1138, 'JLIB_DATABASE_ERROR_MUSTCONTAIN_A_TITLE_CATEGORY', 'Категория должна иметь заголовок', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1139, 'JLIB_DATABASE_ERROR_MUSTCONTAIN_A_TITLE_EXTENSION', 'Расширение должно иметь название', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1140, 'JLIB_DATABASE_ERROR_MUSTCONTAIN_A_TITLE_MENUITEM', 'Пункт меню должен иметь название.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1141, 'JLIB_DATABASE_ERROR_MUSTCONTAIN_A_TITLE_MODULE', 'Модуль должен иметь заголовок', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1142, 'JLIB_DATABASE_ERROR_MUSTCONTAIN_A_TITLE_UPDATESITE', 'Сервер обновления должен иметь название.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1143, 'JLIB_DATABASE_ERROR_NEGATIVE_NOT_PERMITTED', '%s не может быть меньше нуля', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1144, 'JLIB_DATABASE_ERROR_NO_ROWS_SELECTED', 'Нет выбранных строк.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1145, 'JLIB_DATABASE_ERROR_NOT_SUPPORTED_FILE_NOT_FOUND', 'Таблица %s не поддерживается. Файл не найден.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1146, 'JLIB_DATABASE_ERROR_NULL_PRIMARY_KEY', 'Пустой первичный ключ не допускается.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1147, 'JLIB_DATABASE_ERROR_ORDERDOWN_FAILED', '%s: :orderDown не выполнено - %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1148, 'JLIB_DATABASE_ERROR_ORDERUP_FAILED', '%s: :orderUp не выполнено - %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1149, 'JLIB_DATABASE_ERROR_PLEASE_ENTER_A_USER_NAME', 'Пожалуйста, укажите имя пользователя.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1150, 'JLIB_DATABASE_ERROR_PLEASE_ENTER_YOUR_NAME', 'Пожалуйста, укажите ваше имя.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1151, 'JLIB_DATABASE_ERROR_PUBLISH_FAILED', '%s: :publish не выполнено - %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1152, 'JLIB_DATABASE_ERROR_REBUILD_FAILED', '%s: :rebuild не выполнено - %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1153, 'JLIB_DATABASE_ERROR_REBUILDPATH_FAILED', '%s: :rebuildPath не выполнено - %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1154, 'JLIB_DATABASE_ERROR_REORDER_FAILED', '%s: :reorder не выполнено - %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1155, 'JLIB_DATABASE_ERROR_REORDER_UPDATE_ROW_FAILED', '%s: :reorder обновление порядка строки %s не выполнено - %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1156, 'JLIB_DATABASE_ERROR_ROOT_NODE_NOT_FOUND', 'Корневой узел не найден.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1157, 'JLIB_DATABASE_ERROR_STORE_FAILED_UPDATE_ASSET_ID', 'Поле asset_id не может быть обновлено', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1158, 'JLIB_DATABASE_ERROR_STORE_FAILED', '%1$s: :store не выполнено<br />%2$s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1159, 'JLIB_DATABASE_ERROR_USERGROUP_TITLE', 'Группа должна иметь название', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1160, 'JLIB_DATABASE_ERROR_USERGROUP_TITLE_EXISTS', 'Группа пользователей с таким названием уже существует. Название должно быть уникальным в пределах одного родителя.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1161, 'JLIB_DATABASE_ERROR_USERLEVEL_NAME_EXISTS', 'Уровень доступа \"%s\" уже существует.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1162, 'JLIB_DATABASE_ERROR_USERNAME_CANNOT_CHANGE', 'Невозможно использовать это имя пользователя', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1163, 'JLIB_DATABASE_ERROR_USERNAME_INUSE', 'Имя пользователя занято', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1164, 'JLIB_DATABASE_ERROR_VALID_AZ09', 'Пожалуйста, введите корректный логин. Без пробелов, не менее %d символов. Так же в логине <strong>не должно быть символов:</strong> < > \" \' &#37; ; ( ) &', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1165, 'JLIB_DATABASE_ERROR_VALID_MAIL', 'Пожалуйста, введите корректный адрес электронной почты.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1166, 'JLIB_DATABASE_ERROR_VIEWLEVEL', 'Необходимо ввести заголовок', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1167, 'JLIB_DATABASE_FUNCTION_NOERROR', 'Функция базы данных сработала без ошибок', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1168, 'JLIB_DATABASE_QUERY_FAILED', 'Ошибка выполнения SQL-запроса (ошибка # %s): %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1169, 'JLIB_DOCUMENT_ERROR_UNABLE_LOAD_DOC_CLASS', 'Не удаётся загрузить класс документа', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1170, 'JLIB_ENVIRONMENT_SESSION_EXPIRED', 'Время сессии истекло, пожалуйста, пройдите авторизацию заново.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1171, 'JLIB_ENVIRONMENT_SESSION_INVALID', 'Недопустимый cookie сеанса. Пожалуйста, проверьте, что cookies включены у вас в веб-браузере.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1172, 'JLIB_ERROR_COMPONENTS_ACL_CONFIGURATION_FILE_MISSING_OR_IMPROPERLY_STRUCTURED', 'Файл конфигурации ACL компонента %s отсутствует или неправильно структурирован.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1173, 'JLIB_ERROR_INFINITE_LOOP', 'В JError обнаружен бесконечный цикл', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1174, 'JLIB_EVENT_ERROR_DISPATCHER', 'JEventDispatcher: :register: Обработчик событий не распознан. Обработчик: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1175, 'JLIB_FILESYSTEM_BZIP_NOT_SUPPORTED', 'BZip2 не поддерживается', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1176, 'JLIB_FILESYSTEM_BZIP_UNABLE_TO_READ', 'Невозможно прочитать архив (bz2)', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1177, 'JLIB_FILESYSTEM_BZIP_UNABLE_TO_WRITE', 'Невозможно записать архив (bz2)', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1178, 'JLIB_FILESYSTEM_BZIP_UNABLE_TO_WRITE_FILE', 'Невозможно записать файл (bz2)', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1179, 'JLIB_FILESYSTEM_GZIP_NOT_SUPPORTED', 'GZlib не поддерживается', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1180, 'JLIB_FILESYSTEM_GZIP_UNABLE_TO_READ', 'Невозможно прочитать архив (gz)', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1181, 'JLIB_FILESYSTEM_GZIP_UNABLE_TO_WRITE', 'Невозможно записать архив (gz)', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1182, 'JLIB_FILESYSTEM_GZIP_UNABLE_TO_WRITE_FILE', 'Невозможно записать файл (gz)', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1183, 'JLIB_FILESYSTEM_GZIP_UNABLE_TO_DECOMPRESS', 'Не удалось распаковать данные', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1184, 'JLIB_FILESYSTEM_TAR_UNABLE_TO_READ', 'Невозможно прочитать архив (tar)', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1185, 'JLIB_FILESYSTEM_TAR_UNABLE_TO_DECOMPRESS', 'Не удалось распаковать данные', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1186, 'JLIB_FILESYSTEM_TAR_UNABLE_TO_CREATE_DESTINATION', 'Невозможно создать целевой объект', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1187, 'JLIB_FILESYSTEM_TAR_UNABLE_TO_WRITE_ENTRY', 'Невозможно записать данные', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1188, 'JLIB_FILESYSTEM_ZIP_NOT_SUPPORTED', 'Zlib не поддерживается', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1189, 'JLIB_FILESYSTEM_ZIP_UNABLE_TO_READ', 'Невозможно прочитать архив (zip)', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1190, 'JLIB_FILESYSTEM_ZIP_INFO_FAILED', 'Получить информацию о ZIP-архиве не удалось', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1191, 'JLIB_FILESYSTEM_ZIP_UNABLE_TO_CREATE_DESTINATION', 'Невозможно создать целевой объект', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1192, 'JLIB_FILESYSTEM_ZIP_UNABLE_TO_WRITE_ENTRY', 'Невозможно записать данные', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1193, 'JLIB_FILESYSTEM_ZIP_UNABLE_TO_READ_ENTRY', 'Невозможно прочитать объект', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1194, 'JLIB_FILESYSTEM_ZIP_UNABLE_TO_OPEN_ARCHIVE', 'Невозможно открыть архив', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1195, 'JLIB_FILESYSTEM_ZIP_INVALID_ZIP_DATA', 'Некорректные ZIP-данные', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1196, 'JLIB_FILESYSTEM_STREAM_FAILED', 'Не удалось зарегистрировать строковый поток', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1197, 'JLIB_FILESYSTEM_UNKNOWNARCHIVETYPE', 'Неизвестный тип архива', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1198, 'JLIB_FILESYSTEM_UNABLE_TO_LOAD_ARCHIVE', 'Не удаётся загрузить архив', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1199, 'JLIB_FILESYSTEM_ERROR_JFILE_FIND_COPY', 'JFile: :copy: Не удаётся найти или прочитать файл: $%s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1200, 'JLIB_FILESYSTEM_ERROR_JFILE_STREAMS', 'JFile: :copy(%1$s, %2$s): %3$s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1201, 'JLIB_FILESYSTEM_ERROR_COPY_FAILED', 'Копирование не удалось', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1202, 'JLIB_FILESYSTEM_ERROR_COPY_FAILED_ERR01', 'Ошибка копирования: %1s в %2s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1203, 'JLIB_FILESYSTEM_DELETE_FAILED', 'Не удалось удалить %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1204, 'JLIB_FILESYSTEM_CANNOT_FIND_SOURCE_FILE', 'Не удаётся найти исходный файл', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1205, 'JLIB_FILESYSTEM_ERROR_JFILE_MOVE_STREAMS', 'JFile: :move: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1206, 'JLIB_FILESYSTEM_ERROR_RENAME_FILE', 'Переименовать не удалось', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1207, 'JLIB_FILESYSTEM_ERROR_READ_UNABLE_TO_OPEN_FILE', 'JFile: :read: Не удаётся открыть файл: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1208, 'JLIB_FILESYSTEM_ERROR_WRITE_STREAMS', 'JFile: :write(%1$s): %2$s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1209, 'JLIB_FILESYSTEM_ERROR_UPLOAD', 'JFile: :upload: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1210, 'JLIB_FILESYSTEM_ERROR_WARNFS_ERR01', 'Внимание! Не удалось изменить права на файл!', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1211, 'JLIB_FILESYSTEM_ERROR_WARNFS_ERR02', 'Внимание! Не удалось переместить файл!', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1212, 'JLIB_FILESYSTEM_ERROR_WARNFS_ERR03', 'Внимание: файл %s  не был загружен из соображений безопасности!', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1213, 'JLIB_FILESYSTEM_ERROR_WARNFS_ERR04', 'Предупреждение: Не удалось переместить файл: %1s в %2s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1214, 'JLIB_FILESYSTEM_ERROR_FIND_SOURCE_FOLDER', 'Не удаётся найти исходный каталог', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1215, 'JLIB_FILESYSTEM_ERROR_FOLDER_EXISTS', 'Каталог уже существует', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1216, 'JLIB_FILESYSTEM_ERROR_FOLDER_CREATE', 'Невозможно создать каталог', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1217, 'JLIB_FILESYSTEM_ERROR_FOLDER_OPEN', 'Невозможно открыть исходный каталог', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1218, 'JLIB_FILESYSTEM_ERROR_FOLDER_LOOP', 'Обнаружен Бесконечный цикл', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1219, 'JLIB_FILESYSTEM_ERROR_FOLDER_PATH', 'Путь не в пределах значения переменной open_basedir', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1220, 'JLIB_FILESYSTEM_ERROR_COULD_NOT_CREATE_DIRECTORY', 'Не удалось создать каталог', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1221, 'JLIB_FILESYSTEM_ERROR_DELETE_BASE_DIRECTORY', 'Вы не можете удалить главный каталог', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1222, 'JLIB_FILESYSTEM_ERROR_PATH_IS_NOT_A_FOLDER', 'JFolder: :delete: Путь ведёт не к каталогу. Путь: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1223, 'JLIB_FILESYSTEM_ERROR_FOLDER_DELETE', 'JFolder: :delete: Не удаётся удалить каталог. Путь: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1224, 'JLIB_FILESYSTEM_ERROR_FOLDER_RENAME', 'Не удалось переименовать: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1225, 'JLIB_FILESYSTEM_ERROR_PATH_IS_NOT_A_FOLDER_FILES', 'JFolder: :files: Путь ведёт не к каталогу. Путь: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1226, 'JLIB_FILESYSTEM_ERROR_PATH_IS_NOT_A_FOLDER_FOLDER', 'JFolder: :folder: Путь ведёт не к каталогу. Путь: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1227, 'JLIB_FILESYSTEM_ERROR_STREAMS_FILE_SIZE', 'Не удалось определить размер файла. На некоторых потоках это может не сработать!', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1228, 'JLIB_FILESYSTEM_ERROR_STREAMS_FILE_NOT_OPEN', 'Файл не открыт', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1229, 'JLIB_FILESYSTEM_ERROR_STREAMS_FILENAME', 'Имя файла не указано', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1230, 'JLIB_FILESYSTEM_ERROR_NO_DATA_WRITTEN', 'Предупреждение: данные не были сохранены', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1231, 'JLIB_FILESYSTEM_ERROR_STREAMS_FAILED_TO_OPEN_WRITER', 'Не удаётся открыть для записи: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1232, 'JLIB_FILESYSTEM_ERROR_STREAMS_FAILED_TO_OPEN_READER', 'Не удаётся открыть для чтения: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1233, 'JLIB_FILESYSTEM_ERROR_STREAMS_NOT_UPLOADED_FILE', 'Файл не был загружен!', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1234, 'JLIB_FILTER_PARAMS_ALNUM', 'Буквенно-Цифровой', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1235, 'JLIB_FILTER_PARAMS_FLOAT', 'Выравнивание изображения', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1236, 'JLIB_FILTER_PARAMS_INTEGER', 'Целое число', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1237, 'JLIB_FILTER_PARAMS_RAW', 'Raw', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1238, 'JLIB_FILTER_PARAMS_SAFEHTML', 'Безопасный HTML', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1239, 'JLIB_FILTER_PARAMS_TEL', 'Телефон', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1240, 'JLIB_FILTER_PARAMS_TEXT', 'Текст', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1241, 'JLIB_FORM_BUTTON_CLEAR', 'Очистить', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1242, 'JLIB_FORM_BUTTON_SELECT', 'Выбрать', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1243, 'JLIB_FORM_CHANGE_IMAGE', 'Изменить изображение', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1244, 'JLIB_FORM_CHANGE_IMAGE_BUTTON', 'Изменить изображение кнопки', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1245, 'JLIB_FORM_CHANGE_USER', 'Выбрать пользователя', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1246, 'JLIB_FORM_ERROR_FIELDS_CATEGORY_ERROR_EXTENSION_EMPTY', 'В поле категории не указан атрибут расширения', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1247, 'JLIB_FORM_ERROR_FIELDS_GROUPEDLIST_ELEMENT_NAME', 'Неизвестный тип элемента: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1248, 'JLIB_FORM_ERROR_NO_DATA', 'Нет данных', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1249, 'JLIB_FORM_ERROR_VALIDATE_FIELD', 'Неправильное XML-поле', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1250, 'JLIB_FORM_ERROR_XML_FILE_DID_NOT_LOAD', 'XML-файл не был загружен', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1251, 'JLIB_FORM_FIELD_INVALID', 'Некорректно заполнено поле:&#160;', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1252, 'JLIB_FORM_INPUTMODE', 'latin', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1253, 'JLIB_FORM_INVALID_FORM_OBJECT', 'Недопустимый объект формы: :%s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1254, 'JLIB_FORM_INVALID_FORM_RULE', 'Недопустимое правило формы: :%s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1255, 'JLIB_FORM_MEDIA_PREVIEW_ALT', 'Выбранное изображение', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1256, 'JLIB_FORM_MEDIA_PREVIEW_EMPTY', 'Изображение не выбрано.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1257, 'JLIB_FORM_MEDIA_PREVIEW_SELECTED_IMAGE', 'Выбранное изображение', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1258, 'JLIB_FORM_MEDIA_PREVIEW_TIP_TITLE', 'Предпросмотр', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1259, 'JLIB_FORM_SELECT_USER', 'Выбор пользователя', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1260, 'JLIB_FORM_VALIDATE_FIELD_INVALID', 'Недопустимое поле: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1261, 'JLIB_FORM_VALIDATE_FIELD_REQUIRED', 'Требуется поле: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1262, 'JLIB_FORM_VALIDATE_FIELD_RULE_MISSING', 'Правило валидации отсутствует: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1263, 'JLIB_FORM_VALIDATE_FIELD_URL_SCHEMA_MISSING', 'Недействительный URL: URL схема отсутствует в %1$s. Пожалуйста, добавьте одну из указанных в начале: %2$s.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1264, 'JLIB_FORM_VALUE_CACHE_APC', 'Alternative PHP Cache', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1265, 'JLIB_FORM_VALUE_CACHE_APCU', 'APC кэш пользователя', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1266, 'JLIB_FORM_VALUE_CACHE_CACHELITE', 'Cache_Lite', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1267, 'JLIB_FORM_VALUE_CACHE_EACCELERATOR', 'eAccelerator', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1268, 'JLIB_FORM_VALUE_CACHE_FILE', 'Файл', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1269, 'JLIB_FORM_VALUE_CACHE_MEMCACHE', 'Memcache', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1270, 'JLIB_FORM_VALUE_CACHE_MEMCACHED', 'Memcached (Experimental)', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1271, 'JLIB_FORM_VALUE_CACHE_REDIS', 'Redis', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1272, 'JLIB_FORM_VALUE_CACHE_WINCACHE', 'Windows Кэш', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1273, 'JLIB_FORM_VALUE_CACHE_XCACHE', 'XCache', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1274, 'JLIB_FORM_VALUE_SESSION_APC', 'Alternative PHP Cache', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1275, 'JLIB_FORM_VALUE_SESSION_DATABASE', 'База данных', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1276, 'JLIB_FORM_VALUE_SESSION_EACCELERATOR', 'eAccelerator', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1277, 'JLIB_FORM_VALUE_SESSION_MEMCACHE', 'Memcache', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1278, 'JLIB_FORM_VALUE_SESSION_MEMCACHED', 'Memcached (Experimental)', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1279, 'JLIB_FORM_VALUE_SESSION_NONE', 'Нет', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1280, 'JLIB_FORM_VALUE_SESSION_REDIS', 'Redis', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1281, 'JLIB_FORM_VALUE_SESSION_WINCACHE', 'Windows Кэш', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1282, 'JLIB_FORM_VALUE_SESSION_XCACHE', 'XCache', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1283, 'JLIB_FORM_VALUE_TIMEZONE_UTC', 'Всемирное время, Coordinated (UTC)', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1284, 'JLIB_FORM_VALUE_FROM_TEMPLATE', 'Из шаблона', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1285, 'JLIB_FORM_VALUE_INHERITED', 'Унаследовано', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1286, 'JLIB_HTML_ACCESS_MODIFY_DESC_CAPTION_ACL', 'ACL', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1287, 'JLIB_HTML_ACCESS_MODIFY_DESC_CAPTION_TABLE', 'Таблица', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1288, 'JLIB_HTML_ACCESS_SUMMARY_DESC_CAPTION', 'Суммарная таблица прав доступа', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1289, 'JLIB_HTML_ACCESS_SUMMARY_DESC', 'Ниже приведён обзор настройки разрешений для этой статьи. Переходя по вкладкам выше, можно настроить параметры отдельных действий.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1290, 'JLIB_HTML_ACCESS_SUMMARY', 'Итог', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1291, 'JLIB_HTML_ADD_TO_ROOT', 'Создать в корне', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1292, 'JLIB_HTML_ADD_TO_THIS_MENU', 'Добавить к этому меню', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1293, 'JLIB_HTML_BATCH_ACCESS_LABEL', 'Изменить уровень доступа', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1294, 'JLIB_HTML_BATCH_ACCESS_LABEL_DESC', 'Если ничего не выбрать, будет сохранён исходный уровень доступа.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1295, 'JLIB_HTML_BATCH_COPY', 'Копировать', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1296, 'JLIB_HTML_BATCH_FLIPORDERING_LABEL', 'Перевернуть сортировку всех статей в выбранных категориях', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1297, 'JLIB_HTML_BATCH_LANGUAGE_LABEL', 'Установить язык', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1298, 'JLIB_HTML_BATCH_LANGUAGE_LABEL_DESC', 'Если ничего не выбрать, будет сохранён исходный язык.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1299, 'JLIB_HTML_BATCH_LANGUAGE_NOCHANGE', '- Сохранить исходный язык -', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1300, 'JLIB_HTML_BATCH_MENU_LABEL', 'Выберите категорию для Перемещения/Копирования', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini');
INSERT INTO `jm_overrider` (`id`, `constant`, `string`, `file`) VALUES
(1301, 'JLIB_HTML_BATCH_MOVE', 'Переместить', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1302, 'JLIB_HTML_BATCH_MOVE_QUESTION', 'Вы хотите переместить элементы или сделать их копию?', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1303, 'JLIB_HTML_BATCH_NO_CATEGORY', '-Не перемещать и не копировать-', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1304, 'JLIB_HTML_BATCH_NOCHANGE', '- Сохранить исходный уровень доступа -', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1305, 'JLIB_HTML_BATCH_TAG_LABEL', 'Добавить метку', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1306, 'JLIB_HTML_BATCH_TAG_LABEL_DESC', 'Добавить метку выбранным элементам.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1307, 'JLIB_HTML_BATCH_TAG_NOCHANGE', '- Сохранить исходные метки -', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1308, 'JLIB_HTML_BATCH_USER_LABEL', 'Установить Пользователя', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1309, 'JLIB_HTML_BATCH_USER_LABEL_DESC', 'Если ничего не выбрать, будет сохранён исходный пользователь.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1310, 'JLIB_HTML_BATCH_USER_NOCHANGE', '- Сохранить исходного пользователя -', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1311, 'JLIB_HTML_BATCH_USER_NOUSER', 'Нет пользователя', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1312, 'JLIB_HTML_BEHAVIOR_ABOUT_THE_CALENDAR', 'О календаре', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1313, 'JLIB_HTML_BEHAVIOR_CLOSE', 'Закрыть', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1314, 'JLIB_HTML_BEHAVIOR_DATE_SELECTION', 'Выбор даты:\\n', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1315, 'JLIB_HTML_BEHAVIOR_DISPLAY_S_FIRST', 'Показывать первые %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1316, 'JLIB_HTML_BEHAVIOR_DRAG_TO_MOVE', 'Потяните, чтобы переместить', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1317, 'JLIB_HTML_BEHAVIOR_GO_TODAY', 'Текущая дата', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1318, 'JLIB_HTML_BEHAVIOR_GREEN', 'Зелёный', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1319, 'JLIB_HTML_BEHAVIOR_HOLD_MOUSE', '- Удерживайте кнопку мыши на любой из кнопок, расположенных выше, для быстрого выбора.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1320, 'JLIB_HTML_BEHAVIOR_MONTH_SELECT', '- Чтобы выбрать месяц воспользуйтесь кнопками < и > \\n', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1321, 'JLIB_HTML_BEHAVIOR_NEXT_MONTH_HOLD_FOR_MENU', 'Нажмите, что бы перейти на следующий месяц. Нажмите и удерживайте для показа списка месяцев.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1322, 'JLIB_HTML_BEHAVIOR_NEXT_YEAR_HOLD_FOR_MENU', 'Нажмите, что бы перейти на следующий год. Нажмите и удерживайте для показа списка лет.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1323, 'JLIB_HTML_BEHAVIOR_PREV_MONTH_HOLD_FOR_MENU', 'Нажмите, что бы перейти на предыдущий месяц. Нажмите и удерживайте для показа списка месяцев.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1324, 'JLIB_HTML_BEHAVIOR_PREV_YEAR_HOLD_FOR_MENU', 'Нажмите, что бы перейти на предыдущий год. Нажмите и удерживайте для показа списка лет.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1325, 'JLIB_HTML_BEHAVIOR_SELECT_DATE', 'Выбор даты.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1326, 'JLIB_HTML_BEHAVIOR_SHIFT_CLICK_OR_DRAG_TO_CHANGE_VALUE', 'Shift + клик или перетаскивание мышкой позволит изменить значение.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1327, 'JLIB_HTML_BEHAVIOR_TIME', 'Время:', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1328, 'JLIB_HTML_BEHAVIOR_TODAY', 'Сегодня', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1329, 'JLIB_HTML_BEHAVIOR_TT_DATE_FORMAT', '%a, %b %e', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1330, 'JLIB_HTML_BEHAVIOR_WK', 'нед.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1331, 'JLIB_HTML_BEHAVIOR_YEAR_SELECT', '- Чтобы выбрать год, используйте кнопками < и > \\n', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1332, 'JLIB_HTML_BUTTON_BASE_CLASS', 'Не удалось загрузить базовый класс кнопок.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1333, 'JLIB_HTML_BUTTON_NO_LOAD', 'Не удалось загрузить кнопку %s (%s);', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1334, 'JLIB_HTML_BUTTON_NOT_DEFINED', 'Не назначена кнопка для типа = %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1335, 'JLIB_HTML_CALENDAR', 'Календарь', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1336, 'JLIB_HTML_CHECKED_OUT', 'Проверено', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1337, 'JLIB_HTML_CHECKIN', 'Разблокировать', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1338, 'JLIB_HTML_CLOAKING', 'Этот адрес электронной почты защищён от спам-ботов. У вас должен быть включен JavaScript для просмотра.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1339, 'JLIB_HTML_DATE_RELATIVE_DAYS_0', '%s дней назад', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1340, 'JLIB_HTML_DATE_RELATIVE_DAYS_1', '%s день назад', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1341, 'JLIB_HTML_DATE_RELATIVE_DAYS_2', '%s дней назад', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1342, 'JLIB_HTML_DATE_RELATIVE_DAYS', '%s дней назад.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1343, 'JLIB_HTML_DATE_RELATIVE_HOURS_0', '%s часов назад', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1344, 'JLIB_HTML_DATE_RELATIVE_HOURS_1', '%s час назад', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1345, 'JLIB_HTML_DATE_RELATIVE_HOURS_2', '%s часа назад.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1346, 'JLIB_HTML_DATE_RELATIVE_HOURS', '%s часов назад.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1347, 'JLIB_HTML_DATE_RELATIVE_LESSTHANAMINUTE', 'Менее, чем минуту назад', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1348, 'JLIB_HTML_DATE_RELATIVE_MINUTES_0', '%s минут назад', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1349, 'JLIB_HTML_DATE_RELATIVE_MINUTES_1', '%s минуту назад', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1350, 'JLIB_HTML_DATE_RELATIVE_MINUTES_2', '%s минут назад', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1351, 'JLIB_HTML_DATE_RELATIVE_MINUTES', '%s минут назад.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1352, 'JLIB_HTML_DATE_RELATIVE_WEEKS_0', '%s недель назад', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1353, 'JLIB_HTML_DATE_RELATIVE_WEEKS_1', '%s неделя назад', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1354, 'JLIB_HTML_DATE_RELATIVE_WEEKS_2', '%s недель назад', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1355, 'JLIB_HTML_DATE_RELATIVE_WEEKS', '%s недель назад', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1356, 'JLIB_HTML_EDIT_MENU_ITEM', 'Редактировать пункт меню', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1357, 'JLIB_HTML_EDIT_MENU_ITEM_ID', 'ID: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1358, 'JLIB_HTML_EDIT_MODULE', 'Редактировать модуль', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1359, 'JLIB_HTML_EDIT_MODULE_IN_POSITION', 'Позиция: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1360, 'JLIB_HTML_EDITOR_CANNOT_LOAD', 'Не удалось загрузить редактор', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1361, 'JLIB_HTML_END', 'В конец', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1362, 'JLIB_HTML_ERROR_FUNCTION_NOT_SUPPORTED', 'Функция не поддерживается.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1363, 'JLIB_HTML_ERROR_NOTFOUNDINFILE', '%s: :%s не найден в файле.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1364, 'JLIB_HTML_ERROR_NOTSUPPORTED_NOFILE', '%s: :%s не поддерживается. Файл, не найден.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1365, 'JLIB_HTML_ERROR_NOTSUPPORTED', '%s: :%s не поддерживается.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1366, 'JLIB_HTML_MOVE_DOWN', 'Вниз', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1367, 'JLIB_HTML_MOVE_UP', 'Вверх', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1368, 'JLIB_HTML_NO_PARAMETERS_FOR_THIS_ITEM', 'Нет параметров для этого элемента.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1369, 'JLIB_HTML_NO_RECORDS_FOUND', 'Записей не найдено', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1370, 'JLIB_HTML_PAGE_CURRENT', 'Страница %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1371, 'JLIB_HTML_PAGE_CURRENT_OF_TOTAL', 'Страница %s из %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1372, 'JLIB_HTML_PAGINATION', 'Разбиение на страницы', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1373, 'JLIB_HTML_PLEASE_MAKE_A_SELECTION_FROM_THE_LIST', 'Пожалуйста, выберите объект из списка', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1374, 'JLIB_HTML_PUBLISH_ITEM', 'Опубликовать', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1375, 'JLIB_HTML_PUBLISHED_EXPIRED_ITEM', 'Опубликовано, но срок истёк', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1376, 'JLIB_HTML_PUBLISHED_FINISHED', 'Окончание: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1377, 'JLIB_HTML_PUBLISHED_ITEM', 'Опубликовано и действует', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1378, 'JLIB_HTML_PUBLISHED_PENDING_ITEM', 'Опубликовано, но приостановлено', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1379, 'JLIB_HTML_PUBLISHED_START', 'Старт: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1380, 'JLIB_HTML_RESULTS_OF', 'Показано %s - %s из %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1381, 'JLIB_HTML_SAVE_ORDER', 'Сохранить порядок', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1382, 'JLIB_HTML_SELECT_STATE', 'Выбрать состояние', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1383, 'JLIB_HTML_START', 'В начало', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1384, 'JLIB_HTML_UNPUBLISH_ITEM', 'Снять с публикации', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1385, 'JLIB_HTML_VIEW_ALL', 'Посмотреть все', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1386, 'JLIB_HTML_SETDEFAULT_ITEM', 'Установить по умолчанию', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1387, 'JLIB_HTML_UNSETDEFAULT_ITEM', 'Отключить по умолчанию', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1388, 'JLIB_INSTALLER_ABORT', 'Отмена установки языка %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1389, 'JLIB_INSTALLER_ABORT_ALREADYINSTALLED', 'Расширение уже установлено', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1390, 'JLIB_INSTALLER_ABORT_ALREADY_EXISTS', 'Расширение %1$s: Расширение %2$s уже существует.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1391, 'JLIB_INSTALLER_ABORT_COMP_BUILDADMINMENUS_FAILED', 'Ошибка при создании меню панели управления', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1392, 'JLIB_INSTALLER_ABORT_COMP_COPY_MANIFEST', 'Компонент %1$s: Ошибка копирования файла PHP-манифеста.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1393, 'JLIB_INSTALLER_ABORT_COMP_COPY_SETUP', 'Компонент %1$s: Ошибка копирования установочного файла.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1394, 'JLIB_INSTALLER_ABORT_COMP_FAIL_ADMIN_FILES', 'Компонент %s: Ошибка копирования файлов панели управления.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1395, 'JLIB_INSTALLER_ABORT_COMP_FAIL_SITE_FILES', 'Компонент %s: Ошибка копирования файлов сайта.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1396, 'JLIB_INSTALLER_ABORT_COMP_INSTALL_COPY_SETUP', 'Установка компонента: Не удалось скопировать файл установки.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1397, 'JLIB_INSTALLER_ABORT_COMP_INSTALL_CUSTOM_INSTALL_FAILURE', 'Установка компонента: Ошибка в пользовательском скрипте установки', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1398, 'JLIB_INSTALLER_ABORT_COMP_INSTALL_MANIFEST', 'Установка компонента: Не удалось скопировать манифест PHP-файла.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1399, 'JLIB_INSTALLER_ABORT_COMP_INSTALL_PHP_INSTALL', 'Установка компонента: Не удалось скопировать файл установки PHP.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1400, 'JLIB_INSTALLER_ABORT_COMP_INSTALL_PHP_UNINSTALL', 'Установка компонента: Не удалось скопировать файл деинсталляции PHP.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1401, 'JLIB_INSTALLER_ABORT_COMP_INSTALL_ROLLBACK', 'Установка компонента: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1402, 'JLIB_INSTALLER_ABORT_COMP_INSTALL_SQL_ERROR', 'Установка компонента: Файл ошибок SQL %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1403, 'JLIB_INSTALLER_ABORT_COMP_UPDATESITEMENUS_FAILED', 'Установка компонента: Не удалось обновить пункты меню.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1404, 'JLIB_INSTALLER_ABORT_COMP_UPDATE_ADMIN_ELEMENT', 'Обновление компонента: В XML-файле отсутствует элемент управления', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1405, 'JLIB_INSTALLER_ABORT_COMP_UPDATE_COPY_SETUP', 'Обновление компонента: Не удалось скопировать файл установки.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1406, 'JLIB_INSTALLER_ABORT_COMP_UPDATE_MANIFEST', 'Обновление компонента: Не удалось скопировать манифест PHP-файла.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1407, 'JLIB_INSTALLER_ABORT_COMP_UPDATE_PHP_INSTALL', 'Обновление компонента: Не удалось скопировать PHP-файл установки.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1408, 'JLIB_INSTALLER_ABORT_COMP_UPDATE_PHP_UNINSTALL', 'Обновление компонента: Не удалось скопировать PHP-файл деинсталляции.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1409, 'JLIB_INSTALLER_ABORT_COMP_UPDATE_ROLLBACK', 'Обновление компонента: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1410, 'JLIB_INSTALLER_ABORT_COMP_UPDATE_SQL_ERROR', 'Обновление компонента: файл ошибок SQL %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1411, 'JLIB_INSTALLER_ABORT_CREATE_DIRECTORY', 'Расширение %1$s: Ошибка создания каталога: %2$s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1412, 'JLIB_INSTALLER_ABORT_DEBUG', 'Установка была неожиданно прервана:', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1413, 'JLIB_INSTALLER_ABORT_DETECTMANIFEST', 'Не удалось обнаружить файл манифеста', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1414, 'JLIB_INSTALLER_ABORT_DIRECTORY', 'Расширение %1$s: %2$s уже использует каталог: %3$s. Вы пытаетесь повторно установить данное расширение?', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1415, 'JLIB_INSTALLER_ABORT_ERROR_DELETING_EXTENSIONS_RECORD', 'Не удалось удалить запись расширения из базы данных.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1416, 'JLIB_INSTALLER_ABORT_EXTENSIONNOTVALID', 'Недопустимое расширение', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1417, 'JLIB_INSTALLER_ABORT_FILE_INSTALL_COPY_SETUP', 'Установка файлов: Не удалось скопировать файл установки.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1418, 'JLIB_INSTALLER_ABORT_FILE_INSTALL_CUSTOM_INSTALL_FAILURE', 'Установка файлов: Ошибка в пользовательском скрипте установки', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1419, 'JLIB_INSTALLER_ABORT_FILE_INSTALL_FAIL_SOURCE_DIRECTORY', 'Установка файлов: Не удалось найти исходный каталог: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1420, 'JLIB_INSTALLER_ABORT_FILE_INSTALL_ROLLBACK', 'Установка файлов: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1421, 'JLIB_INSTALLER_ABORT_FILE_INSTALL_SQL_ERROR', 'Установка файлов %1$s: файл ошибок SQL %2$s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1422, 'JLIB_INSTALLER_ABORT_FILE_ROLLBACK', 'Установка файлов: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1423, 'JLIB_INSTALLER_ABORT_FILE_SAME_NAME', 'Установка файлов: Модуль с таким же именем уже существует.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1424, 'JLIB_INSTALLER_ABORT_FILE_UPDATE_SQL_ERROR', 'Обновление файлов: файл ошибок SQL %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1425, 'JLIB_INSTALLER_ABORT_INSTALL_CUSTOM_INSTALL_FAILURE', 'Расширение %s: Ошибка пользовательского скрипта установки.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1426, 'JLIB_INSTALLER_ABORT_LIB_COPY_FILES', 'Библиотека %s: Ошибка копирования исходных файлов.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1427, 'JLIB_INSTALLER_ABORT_LIB_INSTALL_ALREADY_INSTALLED', 'Установка библиотеки: Библиотека уже установлена', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1428, 'JLIB_INSTALLER_ABORT_LIB_INSTALL_COPY_SETUP', 'Установка библиотеки: Не удалось скопировать файл установки.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1429, 'JLIB_INSTALLER_ABORT_LIB_INSTALL_FAILED_TO_CREATE_DIRECTORY', 'Установка библиотеки: Не удалось создать каталог: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1430, 'JLIB_INSTALLER_ABORT_LIB_INSTALL_NOFILE', 'Установка библиотеки: Файл библиотеки не указан', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1431, 'JLIB_INSTALLER_ABORT_LIB_INSTALL_ROLLBACK', 'Установка библиотеки: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1432, 'JLIB_INSTALLER_ABORT_LOAD_DETAILS', 'Не удалось загрузить параметры расширения', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1433, 'JLIB_INSTALLER_ABORT_MANIFEST', 'Расширение %1$s: Ошибка копирования файла PHP-манифеста.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1434, 'JLIB_INSTALLER_ABORT_METHODNOTSUPPORTED', 'Для данного типа расширений метод не поддерживается', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1435, 'JLIB_INSTALLER_ABORT_METHODNOTSUPPORTED_TYPE', 'Для данного типа расширений не поддерживается метод: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1436, 'JLIB_INSTALLER_ABORT_MOD_COPY_FILES', 'Модуль %s: Ошибка копирования исходных файлов.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1437, 'JLIB_INSTALLER_ABORT_MOD_INSTALL_COPY_SETUP', 'Установка модуля: Не удалось скопировать установочный файл.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1438, 'JLIB_INSTALLER_ABORT_MOD_INSTALL_CREATE_DIRECTORY', 'Модуль %1$s: Не удалось создать каталог: %2$s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1439, 'JLIB_INSTALLER_ABORT_MOD_INSTALL_CUSTOM_INSTALL_FAILURE', 'Установка модуля: Ошибка в пользовательском скрипте установки', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1440, 'JLIB_INSTALLER_ABORT_MOD_INSTALL_DIRECTORY', 'Модуль %1$s: Другой модуль уже использует каталог: %2$s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1441, 'JLIB_INSTALLER_ABORT_MOD_INSTALL_MANIFEST', 'Установка модуля: Не удалось скопировать манифест PHP-файла.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1442, 'JLIB_INSTALLER_ABORT_MOD_INSTALL_NOFILE', 'Модуль %s: Модуль не указан', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1443, 'JLIB_INSTALLER_ABORT_MOD_INSTALL_SQL_ERROR', 'Модуль %1$s: файл ошибок SQL %2$s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1444, 'JLIB_INSTALLER_ABORT_MOD_ROLLBACK', 'Модуль %1$s: %2$s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1445, 'JLIB_INSTALLER_ABORT_MOD_UNINSTALL_UNKNOWN_CLIENT', 'Удаление модуля: Тип клиента не определён [%s]', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1446, 'JLIB_INSTALLER_ABORT_MOD_UNKNOWN_CLIENT', 'Модуль %1$s: Тип клиента не определён [%2$s]', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1447, 'JLIB_INSTALLER_ABORT_NOINSTALLPATH', 'Путь установки не существует', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1448, 'JLIB_INSTALLER_ABORT_NOUPDATEPATH', 'Путь обновления не существует', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1449, 'JLIB_INSTALLER_ABORT_PACK_INSTALL_COPY_SETUP', 'Установка пакета: Не удалось скопировать установочный файл.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1450, 'JLIB_INSTALLER_ABORT_PACK_INSTALL_CREATE_DIRECTORY', 'Установка пакета: Не удалось создать каталог:%s ', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1451, 'JLIB_INSTALLER_ABORT_PACKAGE_INSTALL_CUSTOM_INSTALL_FAILURE', 'Установка пакета: Ошибка в пользовательском скрипте установки', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1452, 'JLIB_INSTALLER_ABORT_PACKAGE_INSTALL_MANIFEST', 'Установка прервана: Не удалось скопировать манифест PHP-файла.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1453, 'JLIB_INSTALLER_ABORT_PACK_INSTALL_ERROR_EXTENSION', 'Пакет %1$s: В процессе установки произошла ошибка: %2$s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1454, 'JLIB_INSTALLER_ABORT_PACK_INSTALL_NO_FILES', 'Пакет %s: Файлов для установки не обнаружено!', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1455, 'JLIB_INSTALLER_ABORT_PACK_INSTALL_NO_PACK', 'Пакет %s: Файл пакета не указан', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1456, 'JLIB_INSTALLER_ABORT_PACK_INSTALL_ROLLBACK', 'Установка пакета: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1457, 'JLIB_INSTALLER_ABORT_PLG_COPY_FILES', 'Плагин %s: Ошибка копирования исходных файлов.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1458, 'JLIB_INSTALLER_ABORT_PLG_INSTALL_ALLREADY_EXISTS', 'Плагин %1$s: Плагин %2$s уже существуют', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1459, 'JLIB_INSTALLER_ABORT_PLG_INSTALL_COPY_SETUP', 'Плагин %s: Не удалось скопировать установочный файл.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1460, 'JLIB_INSTALLER_ABORT_PLG_INSTALL_CREATE_DIRECTORY', 'Плагин %1$s: Не удалось создать каталог: %2$s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1461, 'JLIB_INSTALLER_ABORT_PLG_INSTALL_CUSTOM_INSTALL_FAILURE', 'Установка плагина: Ошибка в пользовательском скрипте установки', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1462, 'JLIB_INSTALLER_ABORT_PLG_INSTALL_DIRECTORY', 'Плагин %1$s: Ещё один плагин уже использует каталог: %2$s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1463, 'JLIB_INSTALLER_ABORT_PLG_INSTALL_MANIFEST', 'Плагин %s: Не удалось скопировать манифест PHP-файла.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1464, 'JLIB_INSTALLER_ABORT_PLG_INSTALL_NO_FILE', 'Плагин %s: Файл плагина не указан', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1465, 'JLIB_INSTALLER_ABORT_PLG_INSTALL_ROLLBACK', 'Плагин %1$s: %2$s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1466, 'JLIB_INSTALLER_ABORT_PLG_INSTALL_SQL_ERROR', 'Плагин %1$s: Файл ошибок SQL %2$s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1467, 'JLIB_INSTALLER_ABORT_PLG_UNINSTALL_SQL_ERROR', 'Удаление плагина: Файл ошибок SQL %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1468, 'JLIB_INSTALLER_ABORT_REFRESH_MANIFEST_CACHE', 'Обновить кэш манифеста не удалось: Расширение в настоящее время не установлено.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1469, 'JLIB_INSTALLER_ABORT_REFRESH_MANIFEST_CACHE_VALID', 'Обновить кэш манифеста не удалось: Расширение некорректно.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1470, 'JLIB_INSTALLER_ABORT_ROLLBACK', 'Расширение %1$s: %2$s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1471, 'JLIB_INSTALLER_ABORT_SQL_ERROR', 'Расширение %1$s: ошибка выполения SQL-запроса: %2$s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1472, 'JLIB_INSTALLER_ABORT_TPL_INSTALL_ALREADY_INSTALLED', 'Установка шаблона: Шаблон уже установлен', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1473, 'JLIB_INSTALLER_ABORT_TPL_INSTALL_ANOTHER_TEMPLATE_USING_DIRECTORY', 'Установка шаблона: Уже существует шаблон, использующий указанный каталог: %s. Вы пытаетесь установить тот же шаблон ещё раз?', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1474, 'JLIB_INSTALLER_ABORT_TPL_INSTALL_COPY_FILES', 'Установка шаблона: Ошибка копирования исходных файлов %s.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1475, 'JLIB_INSTALLER_ABORT_TPL_INSTALL_COPY_SETUP', 'Установка шаблона: Не удалось скопировать установочный файл.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1476, 'JLIB_INSTALLER_ABORT_TPL_INSTALL_FAILED_CREATE_DIRECTORY', 'Установка шаблона: Не удалось создать каталог: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1477, 'JLIB_INSTALLER_ABORT_TPL_INSTALL_ROLLBACK', 'Установка шаблона: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1478, 'JLIB_INSTALLER_ABORT_TPL_INSTALL_UNKNOWN_CLIENT', 'Установка шаблона: Тип клиента не определён [%s]', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1479, 'JLIB_INSTALLER_AVAILABLE_UPDATE_PHP_VERSION', 'Для расширения %1$s доступна версия %2$s, однако она требует PHP версии %3$s (установленная версия PHP: %4$s)', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1480, 'JLIB_INSTALLER_AVAILABLE_UPDATE_DB_MINIMUM', 'Для расширения %1$s версии %2$s это доступно, но ваша текущая база данных %3$s имеет версию %4$s и не поддерживает это. Пожалуйста, свяжитесь с веб-хостингом для обновления вашей версии базы данных, чтобы она была по крайней мере версии %5$s.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1481, 'JLIB_INSTALLER_AVAILABLE_UPDATE_DB_TYPE', 'Для расширения %1$s версии %2$s это доступно, но ваша текущая %3$s база данных больше не поддерживается.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1482, 'JLIB_INSTALLER_PURGED_UPDATES', 'Кэш обновлений очищен', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1483, 'JLIB_INSTALLER_FAILED_TO_PURGE_UPDATES', 'Не удалось очистить кэш обновлений', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1484, 'JLIB_INSTALLER_DEFAULT_STYLE', '%s - По умолчанию', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1485, 'JLIB_INSTALLER_DISCOVER', 'Поиск', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1486, 'JLIB_INSTALLER_ERROR_CANNOT_UNINSTALL_CHILD_OF_PACKAGE', 'Расширение %s является частью пакета, который не допускает удаления отдельных расширений.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1487, 'JLIB_INSTALLER_ERROR_COMP_DISCOVER_STORE_DETAILS', 'Поиск дистрибутивов компонентов: Не удалось сохранить детали компонента', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1488, 'JLIB_INSTALLER_ERROR_COMP_FAILED_TO_CREATE_DIRECTORY', 'Компонент %1$s: Ошибка создания каталога: %2$s.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1489, 'JLIB_INSTALLER_ERROR_COMP_INSTALL_ADMIN_ELEMENT', 'Установка компонента: В XML-файле отсутствует элемент управления', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1490, 'JLIB_INSTALLER_ERROR_COMP_INSTALL_DIR_ADMIN', 'Установка компонента: Другой компонент уже использует каталог: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1491, 'JLIB_INSTALLER_ERROR_COMP_INSTALL_DIR_SITE', 'Установка компонента: Другой компонент уже использует каталог: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1492, 'JLIB_INSTALLER_ERROR_COMP_INSTALL_FAILED_TO_CREATE_DIRECTORY_ADMIN', 'Установка компонента: Не удалось создать каталог для административной части системы: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1493, 'JLIB_INSTALLER_ERROR_COMP_INSTALL_FAILED_TO_CREATE_DIRECTORY_SITE', 'Установка компонента: Не удалось создать каталог в разделе сайта: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1494, 'JLIB_INSTALLER_ERROR_COMP_REFRESH_MANIFEST_CACHE', 'Обновление кэша манифеста компонента: не удалось сохранить детали компонента', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1495, 'JLIB_INSTALLER_ERROR_COMP_REMOVING_ADMIN_MENUS_FAILED', 'Нельзя удалять меню панели управления.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1496, 'JLIB_INSTALLER_ERROR_COMP_UNINSTALL_CUSTOM', 'Удаление компонента: Пользовательский сценарий удаления не выполнен', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1497, 'JLIB_INSTALLER_ERROR_COMP_UNINSTALL_FAILED_DELETE_CATEGORIES', 'Удаление компонента: Не удалось удалить категории компонента', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1498, 'JLIB_INSTALLER_ERROR_COMP_UNINSTALL_ERRORREMOVEMANUALLY', 'Удаление компонента: Не удаётся удалить. Пожалуйста, удалите вручную', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1499, 'JLIB_INSTALLER_ERROR_COMP_UNINSTALL_ERRORUNKOWNEXTENSION', 'Удаление компонента: Неизвестное расширение', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1500, 'JLIB_INSTALLER_ERROR_COMP_UNINSTALL_FAILED_REMOVE_DIRECTORY_ADMIN', 'Удаление компонента: Не удалось создать каталог в административном разделе', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1501, 'JLIB_INSTALLER_ERROR_COMP_UNINSTALL_FAILED_REMOVE_DIRECTORY_SITE', 'Удаление компонента: Не удалось удалить каталог в административном разделе', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1502, 'JLIB_INSTALLER_ERROR_COMP_UNINSTALL_NO_OPTION', 'Удаление компонента: Поле параметра не заполнено. Не удаётся удалить файлы', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1503, 'JLIB_INSTALLER_ERROR_COMP_UNINSTALL_SQL_ERROR', 'Удаление компонента: Файл ошибок SQL %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1504, 'JLIB_INSTALLER_ERROR_COMP_UNINSTALL_WARNCORECOMPONENT', 'Удаление компонента: Попытка удаления компонента ядра', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1505, 'JLIB_INSTALLER_ERROR_COMP_UPDATE_FAILED_TO_CREATE_DIRECTORY_ADMIN', 'Обновление компонента: Не удалось создать каталог в административном разделе: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1506, 'JLIB_INSTALLER_ERROR_COMP_UPDATE_FAILED_TO_CREATE_DIRECTORY_SITE', 'Обновление компонента: Не удалось создать каталог на сайте: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1507, 'JLIB_INSTALLER_ERROR_CREATE_DIRECTORY', 'JInstaller: :Install: Невозможно создать каталог: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1508, 'JLIB_INSTALLER_ERROR_CREATE_FOLDER_FAILED', 'Не удалось создать каталог [%s]', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1509, 'JLIB_INSTALLER_ERROR_DEPRECATED_FORMAT', 'Устаревший формат установки (client=\"both\"), рекомендуется использовать инсталлятор', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1510, 'JLIB_INSTALLER_ERROR_DISCOVER_INSTALL_UNSUPPORTED', 'Расширение %s не может быть установлено используя метод Найти. Пожалуйста, установите это расширение из Менеджера расширений: Установка.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1511, 'JLIB_INSTALLER_ERROR_DOWNGRADE', 'Извините! Вы не можете понизить версию с %s на %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1512, 'JLIB_INSTALLER_ERROR_DOWNLOAD_SERVER_CONNECT', 'Ошибка подключения к серверу: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1513, 'JLIB_INSTALLER_ERROR_FAIL_COPY_FILE', 'JInstaller: :Install: Не удалось скопировать файл %1$s to %2$s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1514, 'JLIB_INSTALLER_ERROR_FAIL_COPY_FOLDER', 'JInstaller: :Install: Не удалось скопировать каталог %1$s to %2$s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1515, 'JLIB_INSTALLER_ERROR_FAILED_READING_NETWORK_RESOURCES', 'Ошибка чтения сетевых ресурсов: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1516, 'JLIB_INSTALLER_ERROR_FILE_EXISTS', 'JInstaller: :Install: Файл уже существует %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1517, 'JLIB_INSTALLER_ERROR_FILE_FOLDER', 'Ошибка удаления файла или директории %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1518, 'JLIB_INSTALLER_ERROR_FILE_UNINSTALL_INVALID_MANIFEST', 'Удаление файлов: Недопустимый манифест файла', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1519, 'JLIB_INSTALLER_ERROR_FILE_UNINSTALL_INVALID_NOTFOUND_MANIFEST', 'Удаление файлов: манифест файла недопустим или не найден.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1520, 'JLIB_INSTALLER_ERROR_FILE_UNINSTALL_LOAD_ENTRY', 'Удаление файлов: Не удалось загрузить расширение', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1521, 'JLIB_INSTALLER_ERROR_FILE_UNINSTALL_LOAD_MANIFEST', 'Удаление файлов: Не удалось загрузить файл манифеста', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1522, 'JLIB_INSTALLER_ERROR_FILE_UNINSTALL_SQL_ERROR', 'Удаление файлов: файл ошибок SQL %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1523, 'JLIB_INSTALLER_ERROR_FILE_UNINSTALL_WARNCOREFILE', 'Удаление файлов: Попытка удаления системных файлов', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1524, 'JLIB_INSTALLER_ERROR_FOLDER_IN_USE', 'Другое расширение уже использует каталог [%s]', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1525, 'JLIB_INSTALLER_ERROR_LANG_DISCOVER_STORE_DETAILS', 'Поиск пакетов локализации: Не удалось сохранить параметры языка', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1526, 'JLIB_INSTALLER_ERROR_LANG_UNINSTALL_DEFAULT', 'Язык не может быть удалён, пока он используется в качестве языка сайта по умолчанию.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1527, 'JLIB_INSTALLER_ERROR_LANG_UNINSTALL_DIRECTORY', 'Удаление языка: Невозможно удалить указанный каталог языка.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1528, 'JLIB_INSTALLER_ERROR_LANG_UNINSTALL_ELEMENT_EMPTY', 'Удаление языка: Элемент пуст, невозможно удалить файлы', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1529, 'JLIB_INSTALLER_ERROR_LANG_UNINSTALL_PATH_EMPTY', 'Удаление языка: Путь к языку пуст. невозможно удалить файлы', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1530, 'JLIB_INSTALLER_ERROR_LANG_UNINSTALL_PROTECTED', 'Данный язык не может быть удалён. Язык помечен запрещённым к удалению в базе данных (обычно en-GB)', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1531, 'JLIB_INSTALLER_ERROR_LIB_DISCOVER_STORE_DETAILS', 'Поиск пакетов с библиотеками: Не удалось сохранить параметры библиотеки', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1532, 'JLIB_INSTALLER_ERROR_LIB_REFRESH_MANIFEST_CACHE', 'Обновление кэша манифеста библиотеки: Не удалось сохранить параметры библиотеки.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1533, 'JLIB_INSTALLER_ERROR_LIB_UNINSTALL_INVALID_MANIFEST', 'Удаление библиотеки: Недопустимый манифест файла', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1534, 'JLIB_INSTALLER_ERROR_LIB_UNINSTALL_INVALID_NOTFOUND_MANIFEST', 'Удаление библиотеки: Манифест файла недопустим или не найден.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1535, 'JLIB_INSTALLER_ERROR_LIB_UNINSTALL_LOAD_MANIFEST', 'Удаление библиотеки: Невозможно загрузить манифест файла', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1536, 'JLIB_INSTALLER_ERROR_LIB_UNINSTALL_WARNCORELIBRARY', 'Удаление библиотеки: Попытка удалить библиотеку ядра', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1537, 'JLIB_INSTALLER_ERROR_LOAD_XML', 'JInstaller: :Install: Не удалось загрузить XML-файл: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1538, 'JLIB_INSTALLER_ERROR_MOD_DISCOVER_STORE_DETAILS', 'Поиск дистрибутивов модулей: Не удалось сохранить параметры модуля', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1539, 'JLIB_INSTALLER_ERROR_MOD_REFRESH_MANIFEST_CACHE', 'Обновление кэша манифеста модуля: Не удалось сохранить параметры модуля', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1540, 'JLIB_INSTALLER_ERROR_MOD_UNINSTALL_ERRORUNKOWNEXTENSION', 'Удаление модуля: Неизвестное расширение', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1541, 'JLIB_INSTALLER_ERROR_MOD_UNINSTALL_EXCEPTION', 'Удаление модуля: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1542, 'JLIB_INSTALLER_ERROR_MOD_UNINSTALL_INVALID_NOTFOUND_MANIFEST', 'Удаление модуля: Манифест файла недопустим или не найден.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1543, 'JLIB_INSTALLER_ERROR_MOD_UNINSTALL_SQL_ERROR', 'Удаление модуля: Файл ошибок SQL %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1544, 'JLIB_INSTALLER_ERROR_MOD_UNINSTALL_WARNCOREMODULE', 'Удаление модуля: Попытка удалить модуль ядра: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1545, 'JLIB_INSTALLER_ERROR_NO_CORE_LANGUAGE', 'Основной пакет для языка не существует [%s]', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1546, 'JLIB_INSTALLER_ERROR_NO_FILE', 'JInstaller: :Install: Файл не существует %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1547, 'JLIB_INSTALLER_ERROR_NO_LANGUAGE_TAG', 'В пакете отсутствует указание на язык. Вы устанавливаете старую версию языкового пакета?', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1548, 'JLIB_INSTALLER_ERROR_NOTFINDJOOMLAXMLSETUPFILE', 'JInstaller: :Install: Не найден установочный XML-файл Joomla', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1549, 'JLIB_INSTALLER_ERROR_NOTFINDXMLSETUPFILE', 'JInstaller: :Install: Не удалось найти XML-файл установки', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1550, 'JLIB_INSTALLER_ERROR_PACK_REFRESH_MANIFEST_CACHE', 'Обновление кэша манифеста пакета: Не удалось сохранить параметры пакета.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1551, 'JLIB_INSTALLER_ERROR_PACK_SETTING_PACKAGE_ID', 'Не возможно записать идентификатор пакета для данного пакета расширений.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1552, 'JLIB_INSTALLER_ERROR_PACK_UNINSTALL_INVALID_MANIFEST', 'Удаление пакета: Недопустимый манифест файла', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1553, 'JLIB_INSTALLER_ERROR_PACK_UNINSTALL_INVALID_NOTFOUND_MANIFEST', 'Удаление пакета: Файл манифеста недействителен или не найден: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1554, 'JLIB_INSTALLER_ERROR_PACK_UNINSTALL_LOAD_MANIFEST', 'Удаление пакета: Невозможно загрузить манифест файла', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1555, 'JLIB_INSTALLER_ERROR_PACK_UNINSTALL_MANIFEST_NOT_REMOVED', 'Удаление пакета: Манифест файла не удалён, поскольку возникли ошибки!', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1556, 'JLIB_INSTALLER_ERROR_PACK_UNINSTALL_MISSINGMANIFEST', 'Удаление пакета: Отсутствует файл манифеста', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1557, 'JLIB_INSTALLER_ERROR_PACK_UNINSTALL_NOT_PROPER', 'Удаление пакета: Это расширение вероятно уже было удалено или же его удаление было прервано в результате ошибки: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1558, 'JLIB_INSTALLER_ERROR_PACK_UNINSTALL_WARNCOREPACK', 'Удаление пакета: Попытка удаления системного пакета', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1559, 'JLIB_INSTALLER_ERROR_PLG_DISCOVER_STORE_DETAILS', 'Поиск дистрибутивов плагинов: Не удалось сохранить параметры плагина', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1560, 'JLIB_INSTALLER_ERROR_PLG_REFRESH_MANIFEST_CACHE', 'Обновление кэша манифеста плагина: Не удалось сохранить параметры плагина', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1561, 'JLIB_INSTALLER_ERROR_PLG_UNINSTALL_ERRORUNKOWNEXTENSION', 'Удаление плагина: Неизвестное расширение', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1562, 'JLIB_INSTALLER_ERROR_PLG_UNINSTALL_FOLDER_FIELD_EMPTY', 'Удаление плагина: Поле каталога не заполнено, невозможно удалить файлы', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1563, 'JLIB_INSTALLER_ERROR_PLG_UNINSTALL_INVALID_MANIFEST', 'Удаление плагина: Недопустимый манифест файла', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1564, 'JLIB_INSTALLER_ERROR_PLG_UNINSTALL_INVALID_NOTFOUND_MANIFEST', 'Удаление плагина: Манифест файла недопустим или не найден.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1565, 'JLIB_INSTALLER_ERROR_PLG_UNINSTALL_LOAD_MANIFEST', 'Удаление плагина: Невозможно загрузить манифест файла', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1566, 'JLIB_INSTALLER_ERROR_PLG_UNINSTALL_WARNCOREPLUGIN', 'Удаление плагина: Попытка удалить плагин ядра: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1567, 'JLIB_INSTALLER_ERROR_SQL_ERROR', 'JInstaller: :Install: Ошибка SQL %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1568, 'JLIB_INSTALLER_ERROR_SQL_FILENOTFOUND', 'JInstaller: :Install: SQL-файл не найден %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1569, 'JLIB_INSTALLER_ERROR_SQL_READBUFFER', 'JInstaller: :Install: Ошибка чтения файла буфера SQL', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1570, 'JLIB_INSTALLER_ERROR_TPL_DISCOVER_STORE_DETAILS', 'Поиск дистрибутивов шаблонов: Не удалось сохранить параметры шаблона', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1571, 'JLIB_INSTALLER_ERROR_TPL_REFRESH_MANIFEST_CACHE', 'Обновление кэша манифеста шаблона: Не удалось сохранить параметры шаблона.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1572, 'JLIB_INSTALLER_ERROR_TPL_UNINSTALL_ERRORUNKOWNEXTENSION', 'Удаление шаблона: Неизвестное расширение', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1573, 'JLIB_INSTALLER_ERROR_TPL_UNINSTALL_INVALID_CLIENT', 'Удаление шаблона: Клиент недопустим.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1574, 'JLIB_INSTALLER_ERROR_TPL_UNINSTALL_INVALID_NOTFOUND_MANIFEST', 'Удаление шаблона: Манифест файла недопустим или не найден.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1575, 'JLIB_INSTALLER_ERROR_TPL_UNINSTALL_TEMPLATE_DEFAULT', 'Удаление шаблона: Нельзя удалять шаблон, назначенный \'по умолчанию\'.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1576, 'JLIB_INSTALLER_ERROR_TPL_UNINSTALL_TEMPLATE_DIRECTORY', 'Удаление шаблона: Каталог не существует, не удаётся удалить файлы', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1577, 'JLIB_INSTALLER_ERROR_TPL_UNINSTALL_TEMPLATE_ID_EMPTY', 'Удаление шаблона: ID шаблона не указано, не удаётся удалить файлы', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1578, 'JLIB_INSTALLER_ERROR_TPL_UNINSTALL_WARNCORETEMPLATE', 'Удаление шаблона: Попытка удалить базовый шаблон ядра: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1579, 'JLIB_INSTALLER_ERROR_UNKNOWN_CLIENT_TYPE', 'Тип клиента не определён [%s]', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1580, 'JLIB_INSTALLER_FILE_ERROR_MOVE', 'Ошибка при перемещении файла %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1581, 'JLIB_INSTALLER_INCORRECT_SEQUENCE', 'Понижение с версии %1$s до версии %2$s не допускается.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1582, 'JLIB_INSTALLER_INSTALL', 'Установить', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1583, 'JLIB_INSTALLER_MINIMUM_JOOMLA', 'Ваш сайт не удовлетворяет минимальным требованиям Joomla версии J%s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1584, 'JLIB_INSTALLER_MINIMUM_PHP', 'Ваш сервер не отвечает минимальным требованиям версии PHP %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1585, 'JLIB_INSTALLER_NOTICE_LANG_RESET_USERS_1', 'Язык назначен языком \'по умолчанию\' у %d пользователя', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1586, 'JLIB_INSTALLER_NOTICE_LANG_RESET_USERS_2', 'Язык назначен языком \'по умолчанию\' у %d пользователей', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini');
INSERT INTO `jm_overrider` (`id`, `constant`, `string`, `file`) VALUES
(1587, 'JLIB_INSTALLER_NOTICE_LANG_RESET_USERS', 'Язык назначен языком \'по умолчанию\' у %d пользователей', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1588, 'JLIB_INSTALLER_UNINSTALL', 'Деинсталлировать', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1589, 'JLIB_INSTALLER_UPDATE', 'Обновить', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1590, 'JLIB_INSTALLER_ERROR_EXTENSION_INVALID_CLIENT_IDENTIFIER', 'Неверный идентификатор клиента, указанный в продолжение манифеста.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1591, 'JLIB_INSTALLER_ERROR_PACK_UNINSTALL_UNKNOWN_EXTENSION', 'Попытка удалить неизвестное расширение из пакета. Это расширение вероятно уже было ранее удалено.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1592, 'JLIB_INSTALLER_NOT_ERROR', 'If the error is related to the installation of TinyMCE language files it has no effect on the installation of the language(s). Some языковые пакеты созданные для версий Joomla! меньше 3.2.0 могут содержать отдельную локализацию для TinyMCE В связи с тем, что локализация TinyMCE уже включена в дистрибутив, эти файлы более не требуются.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1593, 'JLIB_INSTALLER_UPDATE_LOG_QUERY', 'Выполнение запроса из файла %1$s. Текст запроса: %2$s.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1594, 'JLIB_INSTALLER_WARNING_UNABLE_TO_INSTALL_CONTENT_LANGUAGE', 'Не удается создать язык контента для %s языка: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1595, 'JLIB_JS_AJAX_ERROR_CONNECTION_ABORT', 'Произошло прерывание соединения во время выборки данных JSON.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1596, 'JLIB_JS_AJAX_ERROR_NO_CONTENT', 'Содержимое не было возвращено.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1597, 'JLIB_JS_AJAX_ERROR_OTHER', 'Произошла ошибка при получении данных JSON: код состояния HTTP %s.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1598, 'JLIB_JS_AJAX_ERROR_PARSE', 'Произошла ошибка парсинга при обработке следующих данных JSON: <br/> <code style=\"color:inherit;white-space:pre;padding:0;margin:0;border:0;background:inherit;\">%s</code>', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1599, 'JLIB_JS_AJAX_ERROR_TIMEOUT', 'Превышено время ожидания ответа при выборке данных JSON.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1600, 'JLIB_LANGUAGE_ERROR_CANNOT_LOAD_METAFILE', 'Не удалось загрузить XML-файл языка %s из %s.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1601, 'JLIB_LANGUAGE_ERROR_CANNOT_LOAD_METADATA', 'Не удалось загрузить метаданные %s из %s.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1602, 'JLIB_MAIL_FUNCTION_DISABLED', 'Почта не может быть оправлена, поскольку PHP-функция mail() заблокирована на данном сервере.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1603, 'JLIB_MAIL_FUNCTION_OFFLINE', 'Функция отправки почты временно выключена на данном сайте. Попробуйте позже.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1604, 'JLIB_MAIL_INVALID_EMAIL_SENDER', 'JMail: : Неправильный e-mail отправителя: %s, JMail: :setSender(%s)', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1605, 'JLIB_MEDIA_ERROR_UPLOAD_INPUT', 'Ошибка загрузки файла.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1606, 'JLIB_MEDIA_ERROR_WARNFILENAME', 'Имя файла должно содержать только буквы и цифры, без пробелов.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1607, 'JLIB_MEDIA_ERROR_WARNFILETOOLARGE', 'Размер данного файла слишком велик для загрузки.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1608, 'JLIB_MEDIA_ERROR_WARNFILETYPE', 'Данный тип файлов не поддерживается.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1609, 'JLIB_MEDIA_ERROR_WARNIEXSS', 'Зафиксирована попытка XSS-атаки.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1610, 'JLIB_MEDIA_ERROR_WARNINVALID_IMG', 'Изображение некорректно.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1611, 'JLIB_MEDIA_ERROR_WARNINVALID_MIME', 'Обнаружен запрещённый либо некорректный тип файла (MIME).', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1612, 'JLIB_MEDIA_ERROR_WARNINVALID_MIMETYPE', 'Обнаружены незаконные mime-типы: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1613, 'JLIB_MEDIA_ERROR_WARNNOTADMIN', 'Загружаемый файл не является изображением либо Ваши права ниже менеджера.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1614, 'JLIB_MENUS_PRESET_JOOMLA', 'Предустановка - Joomla', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1615, 'JLIB_MENUS_PRESET_MODERN', 'Предустановка - Modern', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1616, 'JLIB_NO_EDITOR_PLUGIN_PUBLISHED', 'Не удалось отобразить редактор, потому что не опубликован ни один плагин редактора.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1617, 'JLIB_PLUGIN_ERROR_LOADING_PLUGINS', 'Ошибка при установке плагинов: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1618, 'JLIB_REGISTRY_EXCEPTION_LOAD_FORMAT_CLASS', 'Не удаётся загрузить класс формата', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1619, 'JLIB_RULES_ACTION', 'Действие', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1620, 'JLIB_RULES_ALLOWED', 'Разрешено', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1621, 'JLIB_RULES_ALLOWED_ADMIN', 'Разрешено (Суперадминистратор)', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1622, 'JLIB_RULES_ALLOWED_INHERITED', 'Разрешено (унаследовано)', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1623, 'JLIB_RULES_CALCULATED_SETTING', 'Суммарное значение <sup>2</sup>', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1624, 'JLIB_RULES_CONFLICT', 'Конфликт', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1625, 'JLIB_RULES_DATABASE_FAILURE', 'Ошибка сохранения данных в базе данных.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1626, 'JLIB_RULES_DENIED', 'Запрещено', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1627, 'JLIB_RULES_GROUP', '%s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1628, 'JLIB_RULES_GROUPS', 'Менеджер групп', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1629, 'JLIB_RULES_INHERIT', 'Наследовать', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1630, 'JLIB_RULES_INHERITED', 'Унаследовано', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1631, 'JLIB_RULES_NOT_ALLOWED', 'Не разрешено', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1632, 'JLIB_RULES_NOT_ALLOWED_ADMIN_CONFLICT', 'Конфликт', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1633, 'JLIB_RULES_NOT_ALLOWED_DEFAULT', 'Не разрешено (по умолчанию)', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1634, 'JLIB_RULES_NOT_ALLOWED_INHERITED', 'Не разрешено (унаследовано)', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1635, 'JLIB_RULES_NOT_ALLOWED_LOCKED', 'Не разрешено (Заблокировано)', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1636, 'JLIB_RULES_NOT_SET', 'Не определено', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1637, 'JLIB_RULES_NOTICE_RECALCULATE_GROUP_PERMISSIONS', 'Права Суперпользователя изменены. Сохраните или перезагрузите для пересчёта разрешений этой группы.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1638, 'JLIB_RULES_NOTICE_RECALCULATE_GROUP_CHILDS_PERMISSIONS', 'Права изменены в текущей и дочерних группах. Сохраните или перезагрузите страницу для пересчета прав в дочерних группах.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1639, 'JLIB_RULES_REQUEST_FAILURE', 'Ошибка отправки данных на сервер.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1640, 'JLIB_RULES_SAVE_BEFORE_CHANGE_PERMISSIONS', 'Пожалуйста, сохраните перед изменением разрешений.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1641, 'JLIB_RULES_SELECT_ALLOW_DENY_GROUP', 'Разрешать или блокировать действие %s для пользователей группы %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1642, 'JLIB_RULES_SELECT_SETTING', 'Выбор нового значения <sup>1</sup>', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1643, 'JLIB_RULES_SETTING_NOTES', '1. Если изменить значение, оно будет применено здесь, а так же во всех дочерних группах, компонентах и содержимом. Обратите внимание: значение <em>Запрещено</em> переопределит любое унаследовано значение, а так же значение в любой дочерней группе, компоненте или содержимом. В случае противоречия в значениях, <em>Запрещено</em> будет иметь большую силу. Значение <em>Не задано</em> будут трактоваться, как <em>Запрещено</em>, но его можно будет переопределить в дочерних группах, компонентах и содержимом.<br />2. Если вы зададите новое значение, для обновления суммарных значений нажмите кнопку <em>Сохранить</em>.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1644, 'JLIB_RULES_SETTING_NOTES_ITEM', '1. Если изменить значение, оно будет применено для этого объекта. Обратите внимание: <br />Значение <em>Унаследовано</em> - означает, что будет применено значение данного права, указанное в общих настройках, вышестоящей группе и категории.<br /><em>Запрещено</em> - означает, что независимо от значения в общих настройках, вышестоящей группе или категории, пользователи данной группы не смогут выполнить указанное действие над этим объектом.<br /><em>Разрешено</em> - означает, что пользователи данной группы смогут выполнить указанное действие над этим объектом (но, в случае противоречия со значением в общих настройках, вышестоящей группе или категории, право предоставлено не будет. Противоречие будет отмечено в поле суммарных значений, как <em>Не разрешено (со значком блокировки)</em>).<br />2. Если вы зададите новое значение, для обновления суммарных значений, нажмите кнопку <em>Сохранить</em>.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1645, 'JLIB_RULES_SETTINGS_DESC', 'Управление настройками прав доступа для групп пользователей. Ознакомьтесь с примечаниями в нижней части страницы.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1646, 'JLIB_STEMMER_INVALID_STEMMER', 'Неправильный тип парадигмы модуля %s.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1647, 'JLIB_UNKNOWN', 'Неизвестный', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1648, 'JLIB_UPDATER_ERROR_COLLECTION_FOPEN', 'В конфигурации PHP параметр allow_url_fopen отключен. Для использования функций обновления необходимо включить allow_url_fopen.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1649, 'JLIB_UPDATER_ERROR_COLLECTION_OPEN_URL', 'Update: :Collection: Не удалось открыть %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1650, 'JLIB_UPDATER_ERROR_COLLECTION_PARSE_URL', 'Update: :Collection: Не удалось обработать %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1651, 'JLIB_UPDATER_ERROR_EXTENSION_OPEN_URL', 'Update: :Extension: Не удалось открыть %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1652, 'JLIB_UPDATER_ERROR_EXTENSION_PARSE_URL', 'Update: :Extension: Не удалось обработать %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1653, 'JLIB_UPDATER_ERROR_OPEN_UPDATE_SITE', 'Обновление: Ошибка открытия сервера обновлений #%d \"%s\", URL: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1654, 'JLIB_USER_ERROR_AUTHENTICATION_FAILED_LOAD_PLUGIN', 'JAuthentication: :authenticate: Не удалось загрузить плагин: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1655, 'JLIB_USER_ERROR_AUTHENTICATION_LIBRARIES', 'JAuthentication: :__construct: Не удаётся загрузить библиотеки проверки подлинности.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1656, 'JLIB_USER_ERROR_BIND_ARRAY', 'Невозможно сопоставить массив объекта пользователя', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1657, 'JLIB_USER_ERROR_CANNOT_CHANGE_SUPER_USER', 'Пользователю не разрешается изменять разрешения группы Суперпользователя.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1658, 'JLIB_USER_ERROR_CANNOT_CHANGE_OWN_GROUPS', 'Пользователю не разрешается изменять права собственных групп.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1659, 'JLIB_USER_ERROR_CANNOT_CHANGE_OWN_PARENT_GROUPS', 'Пользователю не разрешается изменять права собственных групп и родительских групп.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1660, 'JLIB_USER_ERROR_CANNOT_DEMOTE_SELF', 'Нельзя отменять права вашей собственно учётной записи Суперадминистратора.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1661, 'JLIB_USER_ERROR_CANNOT_REUSE_PASSWORD', 'Вы не можете использовать ваш старый пароль. Пожалуйста, введите новый пароль.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1662, 'JLIB_USER_ERROR_ID_NOT_EXISTS', 'JUser: :_load: Пользователь %s не существует', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1663, 'JLIB_USER_ERROR_NOT_SUPERADMIN', 'Изменять параметры пользователей, являющихся Суперадминистраторами могут только другие Суперадминистраторы.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1664, 'JLIB_USER_ERROR_PASSWORD_NOT_MATCH', 'Пароли не совпадают. Пожалуйста, введите их заново.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1665, 'JLIB_USER_ERROR_UNABLE_TO_FIND_USER', 'Не удалось найти пользователя с такой строкой активации', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1666, 'JLIB_USER_ERROR_UNABLE_TO_LOAD_USER', 'JUser: :_load: Не удалось загрузить пользователя с ID: %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1667, 'JLIB_USER_EXCEPTION_ACCESS_USERGROUP_INVALID', 'Группа пользователей не существует', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1668, 'JLIB_UTIL_ERROR_APP_INSTANTIATION', 'Ошибка при создании экземпляра приложения', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1669, 'JLIB_UTIL_ERROR_CONNECT_DATABASE', 'JDatabase: :getInstance: Не смог подключиться к базе данных <br />joomla.library: %1$s - %2$s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1670, 'JLIB_UTIL_ERROR_DOMIT', 'DommitDocument устарела. Используйте вместо неё DomDocument', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1671, 'JLIB_UTIL_ERROR_LOADING_FEED_DATA', 'Невозможно загрузить ленту новостей', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1672, 'JLIB_UTIL_ERROR_XML_LOAD', 'Не удалось загрузить XML-файл', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.ini'),
(1673, 'LIB_JOOMLA', 'Платформа Joomla!', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.sys.ini'),
(1674, 'LIB_JOOMLA_XML_DESCRIPTION', 'Joomla! Platform - программная платформа, на которой построена система управления сайтом Joomla!', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_joomla.sys.ini'),
(1675, 'LIB_PHPASS', 'phpass', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_phpass.sys.ini'),
(1676, 'LIB_PHPASS_XML_DESCRIPTION', 'phpass это PHP-фреймворк для шифрования паролей.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_phpass.sys.ini'),
(1677, 'LIB_PHPUTF8', 'phputf8', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_phputf8.sys.ini'),
(1678, 'LIB_PHPUTF8_XML_DESCRIPTION', 'Библиотека для работы с UTF-8', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_phputf8.sys.ini'),
(1679, 'LIB_SIMPLEPIE_XML_DESCRIPTION', 'Библиотека для работы с RSS и Atom', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.lib_simplepie.sys.ini'),
(1680, 'MOD_ARTICLES_ARCHIVE', 'Материалы - Материалы в архиве', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_archive.ini'),
(1681, 'MOD_ARTICLES_ARCHIVE_FIELD_COUNT_LABEL', 'Кол-во месяцев', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_archive.ini'),
(1682, 'MOD_ARTICLES_ARCHIVE_FIELD_COUNT_DESC', 'Количество отображаемых материалов (по умолчанию - 10)', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_archive.ini'),
(1683, 'MOD_ARTICLES_ARCHIVE_XML_DESCRIPTION', 'Этот модуль показывает список календарных месяцев, которые содержат архивные материалы. После того, как вы измените статус материала на \'архивный\', этот список будет сгенерирован автоматически.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_archive.ini'),
(1684, 'MOD_ARTICLES_ARCHIVE_DATE', '%1$s, %2$s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_archive.ini'),
(1685, 'MOD_ARTICLES_ARCHIVE', 'Материалы - Материалы в архиве', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_archive.sys.ini'),
(1686, 'MOD_ARTICLES_ARCHIVE_XML_DESCRIPTION', 'Этот модуль показывает список календарных месяцев, которые содержат архивные материалы. После того, как вы измените статус материала на \'архивный\', этот список будет сгенерирован автоматически.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_archive.sys.ini'),
(1687, 'MOD_ARTICLES_ARCHIVE_LAYOUT_DEFAULT', 'По умолчанию', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_archive.sys.ini'),
(1688, 'MOD_ARTICLES_CATEGORIES', 'Категории', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_categories.ini'),
(1689, 'MOD_ARTICLES_CATEGORIES_FIELD_COUNT_DESC', 'Укажите количество первых уровней подкатегорий, которые следует выводить. По умолчанию - все.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_categories.ini'),
(1690, 'MOD_ARTICLES_CATEGORIES_FIELD_COUNT_LABEL', 'Количество первых подкатегорий', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_categories.ini'),
(1691, 'MOD_ARTICLES_CATEGORIES_FIELD_MAXLEVEL_DESC', 'Введите здесь максимальную глубину вложения подкатегорий. По умолчанию - все.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_categories.ini'),
(1692, 'MOD_ARTICLES_CATEGORIES_FIELD_MAXLEVEL_LABEL', 'Максимальная глубина вложения', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_categories.ini'),
(1693, 'MOD_ARTICLES_CATEGORIES_FIELD_PARENT_DESC', 'Выберите родительскую категорию', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_categories.ini'),
(1694, 'MOD_ARTICLES_CATEGORIES_FIELD_PARENT_LABEL', 'Родительская категория', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_categories.ini'),
(1695, 'MOD_ARTICLES_CATEGORIES_FIELD_SHOW_CHILDREN_DESC', 'Показывать или скрывать подкатегории', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_categories.ini'),
(1696, 'MOD_ARTICLES_CATEGORIES_FIELD_SHOW_CHILDREN_LABEL', 'Показывать подкатегории', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_categories.ini'),
(1697, 'MOD_ARTICLES_CATEGORIES_FIELD_NUMITEMS_DESC', 'Показывать или скрывать количество материалов', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_categories.ini'),
(1698, 'MOD_ARTICLES_CATEGORIES_FIELD_NUMITEMS_LABEL', 'Показывать кол-во материалов', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_categories.ini'),
(1699, 'MOD_ARTICLES_CATEGORIES_FIELD_SHOW_DESCRIPTION_DESC', 'Показывать или скрывать описание категории', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_categories.ini'),
(1700, 'MOD_ARTICLES_CATEGORIES_FIELD_SHOW_DESCRIPTION_LABEL', 'Описание категории', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_categories.ini'),
(1701, 'MOD_ARTICLES_CATEGORIES_XML_DESCRIPTION', 'Этот модуль отображает список категорий, входящих в одну общую родительскую категорию.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_categories.ini'),
(1702, 'MOD_ARTICLES_CATEGORIES_TITLE_HEADING_LABEL', 'Стиль заголовка', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_categories.ini'),
(1703, 'MOD_ARTICLES_CATEGORIES_TITLE_HEADING_DESC', 'Определяет - какой именно стиль заголовка будет применён', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_categories.ini'),
(1704, 'MOD_ARTICLES_CATEGORIES', 'Категории', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_categories.sys.ini'),
(1705, 'MOD_ARTICLES_CATEGORIES_XML_DESCRIPTION', 'Этот модуль показывает список категорий, входящих в одну общую родительскую категорию.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_categories.sys.ini'),
(1706, 'MOD_ARTICLES_CATEGORIES_LAYOUT_DEFAULT', 'По умолчанию', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_categories.sys.ini'),
(1707, 'MOD_ARTICLES_CATEGORY', 'Материалы - Список материалов категории', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1708, 'MOD_ARTICLES_CATEGORY_FIELD_ARTICLEGROUPING_DESC', 'Выберите предпочтительный способ группировки материалов.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1709, 'MOD_ARTICLES_CATEGORY_FIELD_ARTICLEGROUPING_LABEL', 'Группировка материалов', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1710, 'MOD_ARTICLES_CATEGORY_FIELD_ARTICLEGROUPINGDIR_DESC', 'Выберите порядок, в котором следует выводить группы материалов.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1711, 'MOD_ARTICLES_CATEGORY_FIELD_ARTICLEGROUPINGDIR_LABEL', 'Порядок отображения групп', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1712, 'MOD_ARTICLES_CATEGORY_FIELD_ARTICLEORDERING_DESC', 'Выберите поле, по которому следует сортировать материалы. Значение \'Порядок Избранных материалов\' может использоваться лишь в том случае, если параметр \'Избранные материалы\' имеет значение \'Только Избранные\'.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1713, 'MOD_ARTICLES_CATEGORY_FIELD_ARTICLEORDERING_LABEL', 'Поле материала, по которому будет выполняться сортировка', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1714, 'MOD_ARTICLES_CATEGORY_FIELD_ARTICLEORDERINGDIR_DESC', 'Выберите направление сортировки, в котором следует выводить материалы.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1715, 'MOD_ARTICLES_CATEGORY_FIELD_ARTICLEORDERINGDIR_LABEL', 'Направление сортировки', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1716, 'MOD_ARTICLES_CATEGORY_FIELD_AUTHOR_DESC', 'Выберите одного или нескольких авторов из списка ниже.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1717, 'MOD_ARTICLES_CATEGORY_FIELD_AUTHOR_LABEL', 'Авторы', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1718, 'MOD_ARTICLES_CATEGORY_FIELD_AUTHORALIAS_DESC', 'Выберите один или несколько псевдонимов авторов из списка ниже.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1719, 'MOD_ARTICLES_CATEGORY_FIELD_AUTHORALIAS_LABEL', 'Псевдоним автора', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1720, 'MOD_ARTICLES_CATEGORY_FIELD_AUTHORALIASFILTERING_DESC', 'Выберите \'Включая\', чтобы включить выбранные псевдонимы авторов, или \'Исключая\', чтобы исключить их.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1721, 'MOD_ARTICLES_CATEGORY_FIELD_AUTHORALIASFILTERING_LABEL', 'Тип фильтра по псевдониму автора', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1722, 'MOD_ARTICLES_CATEGORY_FIELD_AUTHORFILTERING_DESC', 'Выберите \'Включая\', чтобы включить выбранных авторов, или \'Исключая\', чтобы исключить их.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1723, 'MOD_ARTICLES_CATEGORY_FIELD_AUTHORFILTERING_LABEL', 'Тип фильтра по автору', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1724, 'MOD_ARTICLES_CATEGORY_FIELD_CATDEPTH_DESC', 'Количество возвращаемых уровней дочерних категорий.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1725, 'MOD_ARTICLES_CATEGORY_FIELD_CATDEPTH_LABEL', 'Глубина категорий', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1726, 'MOD_ARTICLES_CATEGORY_FIELD_CATEGORY_DESC', 'Выберите, пожалуйста, одну или несколько категорий.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1727, 'MOD_ARTICLES_CATEGORY_FIELD_CATFILTERINGTYPE_DESC', 'Выберите \'Включая\', чтобы включить выбранные категории, или \'Исключая\', чтобы исключить их.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1728, 'MOD_ARTICLES_CATEGORY_FIELD_CATFILTERINGTYPE_LABEL', 'Тип фильтра по категории', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1729, 'MOD_ARTICLES_CATEGORY_FIELD_COUNT_DESC', 'Кол-во отображаемых объектов. Если установлено число \"0\" (значение по умолчанию), будут показаны все материалы.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1730, 'MOD_ARTICLES_CATEGORY_FIELD_COUNT_LABEL', 'Кол-во', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1731, 'MOD_ARTICLES_CATEGORY_FIELD_DATERANGEFIELD_DESC', 'Укажите, по которому из существующих полей даты следует ограничивать диапазон дат.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1732, 'MOD_ARTICLES_CATEGORY_FIELD_DATERANGEFIELD_LABEL', 'Поле для фильтрации', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1733, 'MOD_ARTICLES_CATEGORY_FIELD_DATEFIELD_DESC', 'Выберите, какое именно из существующих полей даты следует выводить.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1734, 'MOD_ARTICLES_CATEGORY_FIELD_DATEFIELD_LABEL', 'Поле даты', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1735, 'MOD_ARTICLES_CATEGORY_FIELD_DATEFIELDFORMAT_DESC', 'Введите пожалуйста корректный код формата. Для более подробной информации ознакомьтесь с материалами справочной системы языка PHP: http://php.net/date.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1736, 'MOD_ARTICLES_CATEGORY_FIELD_DATEFIELDFORMAT_LABEL', 'Формат даты', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1737, 'MOD_ARTICLES_CATEGORY_FIELD_DATEFILTERING_DESC', 'Выберите тип фильтрации по дате.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1738, 'MOD_ARTICLES_CATEGORY_FIELD_DATEFILTERING_LABEL', 'Фильтр по дате', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1739, 'MOD_ARTICLES_CATEGORY_FIELD_ENDDATE_DESC', 'Если выше указано значение в поле \'Диапазон дат\', выберите, пожалуйста, дату окончания.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1740, 'MOD_ARTICLES_CATEGORY_FIELD_ENDDATE_LABEL', 'Дата конца диапазона', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1741, 'MOD_ARTICLES_CATEGORY_FIELD_EXCLUDEDARTICLES_DESC', 'Пожалуйста, введите ID каждого материала на новой строке.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1742, 'MOD_ARTICLES_CATEGORY_FIELD_EXCLUDEDARTICLES_LABEL', 'ID материала, который необходимо исключать', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1743, 'MOD_ARTICLES_CATEGORY_FIELD_GROUP_DISPLAY_LABEL', 'Параметры отображения', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1744, 'MOD_ARTICLES_CATEGORY_FIELD_GROUP_DYNAMIC_LABEL', 'Параметры динамического режима', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1745, 'MOD_ARTICLES_CATEGORY_FIELD_GROUP_FILTERING_LABEL', 'Параметры фильтрации', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1746, 'MOD_ARTICLES_CATEGORY_FIELD_GROUP_GROUPING_LABEL', 'Параметры группировки', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1747, 'MOD_ARTICLES_CATEGORY_FIELD_GROUP_ORDERING_LABEL', 'Параметры сортировки', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1748, 'MOD_ARTICLES_CATEGORY_FIELD_INTROTEXTLIMIT_DESC', 'Пожалуйста, укажите максимально допустимое количество символов во вступительном тексте. Остальная часть вводного текста будет отсечена.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1749, 'MOD_ARTICLES_CATEGORY_FIELD_INTROTEXTLIMIT_LABEL', 'Ограничение вводного текста', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1750, 'MOD_ARTICLES_CATEGORY_FIELD_LINKTITLES_LABEL', 'Заголовок как ссылка', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1751, 'MOD_ARTICLES_CATEGORY_FIELD_LINKTITLES_DESC', 'Заголовок как ссылка', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1752, 'MOD_ARTICLES_CATEGORY_FIELD_MODE_DESC', 'Пожалуйста, выберите режим, который вы хотели бы использовать. Если выбрать \'Обычный\', то просто настройте модуль и он будет отображать статичный список статей в пункте меню, к которому будет привязан. Если выбрать \'Динамический\', то вы так же можете настроить модуль, однако значение параметра Категория учитываться не будет. Вместо этого, модуль будет динамически определять представление страницы. Если используется представление \'Список материалов категории\', будет отображать список материалов этой категории. Если выбран \'Динамический\', можно привязать модуль \'ко всем страницам\' сайта. В этом случае он будет автоматически определять, следует ли ему что-либо показывать.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1753, 'MOD_ARTICLES_CATEGORY_FIELD_MODE_LABEL', 'Режим', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1754, 'MOD_ARTICLES_CATEGORY_FIELD_MONTHYEARFORMAT_DESC', 'Введите пожалуйста корректный код формата. Для более подробной информации ознакомьтесь с материалами справочной системы языка PHP: http://php.net/date.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1755, 'MOD_ARTICLES_CATEGORY_FIELD_MONTHYEARFORMAT_LABEL', 'Формат показа месяца и года', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1756, 'MOD_ARTICLES_CATEGORY_FIELD_RELATIVEDATE_DESC', 'Если выше выбран режим \'Относительная дата\', то, введите количество дней. Продолжительность будет автоматически вычислена исходя из текущей даты и указанного вами значения.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1757, 'MOD_ARTICLES_CATEGORY_FIELD_RELATIVEDATE_LABEL', 'Относительная дата', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1758, 'MOD_ARTICLES_CATEGORY_FIELD_SHOWAUTHOR_DESC', 'Выберите <strong>Показать</strong>, если вы хотите, чтобы автор (или его псевдоним вместо имени) были видны на сайте.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1759, 'MOD_ARTICLES_CATEGORY_FIELD_SHOWCATEGORY_DESC', 'Выберите <strong>Показать</strong>, если вы хотели бы вывести название категории на странице сайта.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1760, 'MOD_ARTICLES_CATEGORY_FIELD_SHOWCHILDCATEGORYARTICLES_DESC', 'Включать или исключать из показа материалы, хранящиеся в дочерних категориях.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1761, 'MOD_ARTICLES_CATEGORY_FIELD_SHOWCHILDCATEGORYARTICLES_LABEL', 'Материалы дочерних категорий', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1762, 'MOD_ARTICLES_CATEGORY_FIELD_SHOWDATE_DESC', 'Выберите Показывать, если хотите отобразить дату.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1763, 'MOD_ARTICLES_CATEGORY_FIELD_SHOWFEATURED_DESC', 'Выберите <strong>Показать</strong>, если вы хотите показывать избранные материалы. Так же можно установить отображение только избранных материалов.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1764, 'MOD_ARTICLES_CATEGORY_FIELD_SHOWFEATURED_LABEL', 'Избранные материалы', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1765, 'MOD_ARTICLES_CATEGORY_FIELD_SHOWHITS_DESC', 'Выберите <strong>Показать</strong>, если вы хотите отобразить на сайте количество просмотров для каждого материала.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1766, 'MOD_ARTICLES_CATEGORY_FIELD_SHOWHITS_LABEL', 'Кол-во просмотров', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1767, 'MOD_ARTICLES_CATEGORY_FIELD_SHOWINTROTEXT_DESC', 'Выберите <strong>Показать</strong>, если вы хотите отображать вступительный текст материала.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1768, 'MOD_ARTICLES_CATEGORY_FIELD_SHOWINTROTEXT_LABEL', 'Вводный текст', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1769, 'MOD_ARTICLES_CATEGORY_FIELD_SHOWONARTICLEPAGE_DESC', 'Выберите, <strong>Показать</strong> ли список материалов на странице текста материала. Это означает, что модуль будет отображаться только на страницах Категорий.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1770, 'MOD_ARTICLES_CATEGORY_FIELD_SHOWONARTICLEPAGE_LABEL', 'Показывать на странице материала', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1771, 'MOD_ARTICLES_CATEGORY_FIELD_STARTDATE_DESC', 'Если выше включен параметр \'Период\' введите, пожалуйста, дату начала.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1772, 'MOD_ARTICLES_CATEGORY_FIELD_STARTDATE_LABEL', 'Дата начала диапазона', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1773, 'MOD_ARTICLES_CATEGORY_OPTION_ASCENDING_VALUE', 'По возрастанию', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1774, 'MOD_ARTICLES_CATEGORY_OPTION_CREATED_VALUE', 'Дата создания', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1775, 'MOD_ARTICLES_CATEGORY_OPTION_DATERANGE_VALUE', 'Диапазон дат', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1776, 'MOD_ARTICLES_CATEGORY_OPTION_DESCENDING_VALUE', 'По убыванию', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1777, 'MOD_ARTICLES_CATEGORY_OPTION_DYNAMIC_VALUE', 'Динамический', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1778, 'MOD_ARTICLES_CATEGORY_OPTION_EXCLUDE_VALUE', 'Исключать', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1779, 'MOD_ARTICLES_CATEGORY_OPTION_EXCLUSIVE_VALUE', 'Исключающий', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1780, 'MOD_ARTICLES_CATEGORY_OPTION_HITS_VALUE', 'Количество просмотров', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1781, 'MOD_ARTICLES_CATEGORY_OPTION_ID_VALUE', 'ID', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1782, 'MOD_ARTICLES_CATEGORY_OPTION_INCLUDE_VALUE', 'Включать', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1783, 'MOD_ARTICLES_CATEGORY_OPTION_INCLUSIVE_VALUE', 'Включающий', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1784, 'MOD_ARTICLES_CATEGORY_OPTION_MODIFIED_VALUE', 'Дата изменения', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1785, 'MOD_ARTICLES_CATEGORY_OPTION_MONTHYEAR_VALUE', 'Месяц и Год', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1786, 'MOD_ARTICLES_CATEGORY_OPTION_NORMAL_VALUE', 'Обычный', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1787, 'MOD_ARTICLES_CATEGORY_OPTION_OFF_VALUE', 'Выкл.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1788, 'MOD_ARTICLES_CATEGORY_OPTION_ONLYFEATURED_VALUE', 'Только Избранные', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1789, 'MOD_ARTICLES_CATEGORY_OPTION_ORDERING_VALUE', 'Порядок, определённый Joomla!', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1790, 'MOD_ARTICLES_CATEGORY_OPTION_ORDERINGFEATURED_VALUE', 'Порядок Избранных материалов', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1791, 'MOD_ARTICLES_CATEGORY_OPTION_RANDOM_VALUE', 'Случайный', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1792, 'MOD_ARTICLES_CATEGORY_OPTION_RATING_VALUE', 'Рейтинг', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1793, 'MOD_ARTICLES_CATEGORY_OPTION_RELATIVEDAY_VALUE', 'Относительная дата', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1794, 'MOD_ARTICLES_CATEGORY_OPTION_STARTPUBLISHING_VALUE', 'Дата начала публикации', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1795, 'MOD_ARTICLES_CATEGORY_OPTION_FINISHPUBLISHING_VALUE', 'Дата завершения публикации', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1796, 'MOD_ARTICLES_CATEGORY_OPTION_VOTE_VALUE', 'Голосование', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1797, 'MOD_ARTICLES_CATEGORY_OPTION_YEAR_VALUE', 'Год', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1798, 'MOD_ARTICLES_CATEGORY_READ_MORE', 'Подробнее: ', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1799, 'MOD_ARTICLES_CATEGORY_READ_MORE_TITLE', 'Подробнее...', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1800, 'MOD_ARTICLES_CATEGORY_REGISTER_TO_READ_MORE', '\'Подробнее\' только для зарегистрированных', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1801, 'MOD_ARTICLES_CATEGORY_XML_DESCRIPTION', 'Этот модуль отображает список материалов из одной или нескольких категорий.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.ini'),
(1802, 'MOD_ARTICLES_CATEGORY', 'Материалы - Список материалов категории', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.sys.ini'),
(1803, 'MOD_ARTICLES_CATEGORY_XML_DESCRIPTION', 'Этот модуль отображает список материалов из одной или нескольких категорий.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.sys.ini'),
(1804, 'MOD_ARTICLES_CATEGORY_LAYOUT_DEFAULT', 'По умолчанию', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_category.sys.ini'),
(1805, 'MOD_ARTICLES_LATEST', 'Материалы - Последние новости', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_latest.ini'),
(1806, 'MOD_LATEST_NEWS_FIELD_CATEGORY_DESC', 'Выделите категории, материалы из которых следует отображать. Если не выделить ни одной, будут показаны материалы из всех категорий.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_latest.ini'),
(1807, 'MOD_LATEST_NEWS_FIELD_COUNT_DESC', 'Количество отображаемых материалов (по умолчанию - 5)', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_latest.ini'),
(1808, 'MOD_LATEST_NEWS_FIELD_COUNT_LABEL', 'Кол-во', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_latest.ini'),
(1809, 'MOD_LATEST_NEWS_FIELD_FEATURED_DESC', 'Показывать/Скрывать материалы, отмеченные, как \'избранные\'', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_latest.ini'),
(1810, 'MOD_LATEST_NEWS_FIELD_FEATURED_LABEL', 'Избранные материалы', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_latest.ini'),
(1811, 'MOD_LATEST_NEWS_FIELD_ORDERING_DESC', '\'Последние созданные - первыми\': выводить материалы, отсортировав по дате создания.<br /><br />\'Последние изменённые - первыми\': выводить материалы, отсортировав по дате последнего изменения.<br /><br />\'Последние опубликованные - первыми\': выводить материалы, отсортировав по дате публикации.<br /><br />\'Последние обработанные - первыми\': выводить материалы, отсортировав по датам создания или модификации.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_latest.ini'),
(1812, 'MOD_LATEST_NEWS_FIELD_ORDERING_LABEL', 'Порядок', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_latest.ini'),
(1813, 'MOD_LATEST_NEWS_FIELD_USER_DESC', 'Фильтр по автору', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_latest.ini'),
(1814, 'MOD_LATEST_NEWS_FIELD_USER_LABEL', 'Авторы', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_latest.ini'),
(1815, 'MOD_LATEST_NEWS_VALUE_ADDED_BY_ME', 'Добавлены или изменены мной', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_latest.ini'),
(1816, 'MOD_LATEST_NEWS_VALUE_ANYONE', 'Кто угодно', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_latest.ini'),
(1817, 'MOD_LATEST_NEWS_VALUE_NOTADDED_BY_ME', 'Добавлены или изменены НЕ мной', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_latest.ini'),
(1818, 'MOD_LATEST_NEWS_VALUE_ONLY_SHOW_FEATURED', 'Показывать только избранные материалы', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_latest.ini'),
(1819, 'MOD_LATEST_NEWS_VALUE_RECENT_ADDED', 'Последние созданные - первыми', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_latest.ini'),
(1820, 'MOD_LATEST_NEWS_VALUE_RECENT_MODIFIED', 'Последние изменённые - первыми', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_latest.ini'),
(1821, 'MOD_LATEST_NEWS_VALUE_RECENT_RAND', 'Случайные материалы', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_latest.ini'),
(1822, 'MOD_LATEST_NEWS_VALUE_RECENT_PUBLISHED', 'Последние опубликованные - первыми', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_latest.ini'),
(1823, 'MOD_LATEST_NEWS_VALUE_RECENT_TOUCHED', 'Последние обработанные - первыми', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_latest.ini'),
(1824, 'MOD_LATEST_NEWS_XML_DESCRIPTION', 'Этот модуль отображает список самых последних опубликованных материалов, у которых не истёк срок публикации.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_latest.ini'),
(1825, 'MOD_ARTICLES_LATEST', 'Материалы - Последние новости', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_latest.sys.ini'),
(1826, 'MOD_LATEST_NEWS_XML_DESCRIPTION', 'Этот модуль отображает список самых последних опубликованных материалов, у которых не истёк срок публикации.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_latest.sys.ini'),
(1827, 'MOD_ARTICLES_LATEST_LAYOUT_DEFAULT', 'По умолчанию', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_latest.sys.ini'),
(1828, 'MOD_ARTICLES_NEWS', 'Материалы - Новости', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_news.ini'),
(1829, 'MOD_ARTICLES_NEWS_FIELD_FEATURED_DESC', 'Показывать/Скрывать материалы, отмеченные, как \'избранные\'', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_news.ini'),
(1830, 'MOD_ARTICLES_NEWS_FIELD_FEATURED_LABEL', 'Избранные материалы', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_news.ini'),
(1831, 'MOD_ARTICLES_NEWS_FIELD_CATEGORY_DESC', 'Выделите категории, материалы из которых следует отображать. Если не выделить ни одной, будут показаны материалы из всех категорий.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_news.ini'),
(1832, 'MOD_ARTICLES_NEWS_FIELD_IMAGES_DESC', 'Показывать изображения из материалов', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_news.ini'),
(1833, 'MOD_ARTICLES_NEWS_FIELD_IMAGES_LABEL', 'Показывать изображения', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_news.ini'),
(1834, 'MOD_ARTICLES_NEWS_FIELD_ITEMS_DESC', 'Количество отображаемых материалов', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_news.ini'),
(1835, 'MOD_ARTICLES_NEWS_FIELD_ITEMS_LABEL', 'Количество материалов', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_news.ini'),
(1836, 'MOD_ARTICLES_NEWS_FIELD_LINKTITLE_DESC', 'Выводит заголовки материалов как ссылки на полный текст материала.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_news.ini'),
(1837, 'MOD_ARTICLES_NEWS_FIELD_LINKTITLE_LABEL', 'Заголовок как ссылка', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_news.ini'),
(1838, 'MOD_ARTICLES_NEWS_FIELD_ORDERING_DESC', 'Порядок отображения материалов', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_news.ini'),
(1839, 'MOD_ARTICLES_NEWS_FIELD_ORDERING_LABEL', 'Порядок', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_news.ini'),
(1840, 'MOD_ARTICLES_NEWS_FIELD_ORDERING_CREATED_DATE', 'Дата создания', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_news.ini'),
(1841, 'MOD_ARTICLES_NEWS_FIELD_ORDERING_MODIFIED_DATE', 'Дата изменения', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_news.ini'),
(1842, 'MOD_ARTICLES_NEWS_FIELD_ORDERING_PUBLISHED_DATE', 'Дата публикации', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_news.ini'),
(1843, 'MOD_ARTICLES_NEWS_FIELD_ORDERING_ORDERING', 'Порядок', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_news.ini'),
(1844, 'MOD_ARTICLES_NEWS_FIELD_ORDERING_RANDOM', 'Случайно', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_news.ini'),
(1845, 'MOD_ARTICLES_NEWS_FIELD_READMORE_DESC', 'Если установлено значение <strong>Показать</strong>, вместо основной части материала будет выводиться ссылка \'Подробнее...\', ведущая на отдельную страницу просмотра полного текста.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_news.ini'),
(1846, 'MOD_ARTICLES_NEWS_FIELD_READMORE_LABEL', 'Ссылка \'Подробнее...\'', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_news.ini'),
(1847, 'MOD_ARTICLES_NEWS_FIELD_SEPARATOR_DESC', 'Показывать разделитель после последнего материала', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_news.ini'),
(1848, 'MOD_ARTICLES_NEWS_FIELD_SEPARATOR_LABEL', 'Показывать последний разделитель', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_news.ini'),
(1849, 'MOD_ARTICLES_NEWS_FIELD_TITLE_DESC', 'Показывать/Скрывать заголовок материала', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_news.ini'),
(1850, 'MOD_ARTICLES_NEWS_FIELD_TITLE_LABEL', 'Показывать заголовок', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_news.ini'),
(1851, 'MOD_ARTICLES_NEWS_FIELD_TRIGGEREVENTS_DESC', 'Триггеры дополнительных событий плагинов для отображения дополнительного содержимого, такие как настраиваемые поля или информация голосования.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_news.ini');
INSERT INTO `jm_overrider` (`id`, `constant`, `string`, `file`) VALUES
(1852, 'MOD_ARTICLES_NEWS_FIELD_TRIGGEREVENTS_LABEL', 'Триггер события плагина', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_news.ini'),
(1853, 'MOD_ARTICLES_NEWS_FIELD_SHOWINTROTEXT_DESC', 'Показывать/Скрывать вводный текст материала.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_news.ini'),
(1854, 'MOD_ARTICLES_NEWS_FIELD_SHOWINTROTEXT_LABEL', 'Показать вводный текст', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_news.ini'),
(1855, 'MOD_ARTICLES_NEWS_READMORE', 'Подробнее...', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_news.ini'),
(1856, 'MOD_ARTICLES_NEWS_READMORE_REGISTER', 'Зарегистрируйтесь для доступа к полному тексту материала', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_news.ini'),
(1857, 'MOD_ARTICLES_NEWS_TITLE_HEADING', 'Уровень заголовка', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_news.ini'),
(1858, 'MOD_ARTICLES_NEWS_TITLE_HEADING_DESCRIPTION', 'Выберите HTML-тег, в котором следует выводить заголовок материала.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_news.ini'),
(1859, 'MOD_ARTICLES_NEWS_VALUE_ONLY_SHOW_FEATURED', 'Показывать только избранные материалы', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_news.ini'),
(1860, 'MOD_ARTICLES_NEWS_XML_DESCRIPTION', 'Модуль Последних новостей выводит фиксированное количество материалов из конкретной категории или набора категорий.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_news.ini'),
(1861, 'MOD_ARTICLES_NEWS', 'Материалы - Новости', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_news.sys.ini'),
(1862, 'MOD_ARTICLES_NEWS_XML_DESCRIPTION', 'Модуль Новостей выводит фиксированное количество материалов из конкретной категории или набора категорий.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_news.sys.ini'),
(1863, 'MOD_ARTICLES_NEWS_LAYOUT_DEFAULT', 'По умолчанию', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_news.sys.ini'),
(1864, 'MOD_ARTICLES_POPULAR', 'Материалы - Самые читаемые', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_popular.ini'),
(1865, 'MOD_POPULAR_FIELD_CATEGORY_DESC', 'Выделите категории, материалы из которых следует отображать. Если не выделить ни одной, будут показаны материалы из всех категорий.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_popular.ini'),
(1866, 'MOD_POPULAR_FIELD_COUNT_DESC', 'Количество отображаемых материалов (по умолчанию - 5)', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_popular.ini'),
(1867, 'MOD_POPULAR_FIELD_COUNT_LABEL', 'Кол-во', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_popular.ini'),
(1868, 'MOD_POPULAR_FIELD_FEATURED_DESC', 'Показывать/Скрывать материалы, отмеченные, как \'избранные\'', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_popular.ini'),
(1869, 'MOD_POPULAR_FIELD_FEATURED_LABEL', 'Избранные материалы', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_popular.ini'),
(1870, 'MOD_POPULAR_XML_DESCRIPTION', 'Этот модуль отображает список опубликованных материалов, которые были просмотрены чаще всех - определяется по количеству просмотров.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_popular.ini'),
(1871, 'MOD_POPULAR_FIELD_DATEFIELD_DESC', 'Выберите поле с датой для фильтрации.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_popular.ini'),
(1872, 'MOD_POPULAR_FIELD_DATEFIELD_LABEL', 'Поле с датой', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_popular.ini'),
(1873, 'MOD_POPULAR_FIELD_DATEFILTERING_DESC', 'Выберите тип фильтрации', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_popular.ini'),
(1874, 'MOD_POPULAR_FIELD_DATEFILTERING_LABEL', 'Фильтрация дат', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_popular.ini'),
(1875, 'MOD_POPULAR_FIELD_ENDDATE_DESC', 'Если выше выбран Диапазон дат необходимо указать Дату окончания', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_popular.ini'),
(1876, 'MOD_POPULAR_FIELD_ENDDATE_LABEL', 'Дата окончания', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_popular.ini'),
(1877, 'MOD_POPULAR_FIELD_STARTDATE_DESC', 'Если выше выбран Диапазон дат необходимо указать Дату начала', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_popular.ini'),
(1878, 'MOD_POPULAR_FIELD_STARTDATE_LABEL', 'Дата начала', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_popular.ini'),
(1879, 'MOD_POPULAR_FIELD_RELATIVEDATE_DESC', 'Если выше выбрано Относительная дата, укажите количество дней..Результаты будут отфильтрованы относительно текущей даты и введенного значения.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_popular.ini'),
(1880, 'MOD_POPULAR_FIELD_RELATIVEDATE_LABEL', 'Относительная дата', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_popular.ini'),
(1881, 'MOD_POPULAR_OPTION_CREATED_VALUE', 'Дата создания', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_popular.ini'),
(1882, 'MOD_POPULAR_OPTION_DATERANGE_VALUE', 'Диапазон дат', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_popular.ini'),
(1883, 'MOD_POPULAR_OPTION_MODIFIED_VALUE', 'Дата изменения', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_popular.ini'),
(1884, 'MOD_POPULAR_OPTION_OFF_VALUE', 'Нет', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_popular.ini'),
(1885, 'MOD_POPULAR_OPTION_RELATIVEDAY_VALUE', 'Относительная дата', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_popular.ini'),
(1886, 'MOD_POPULAR_OPTION_STARTPUBLISHING_VALUE', 'Дата начала публикации', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_popular.ini'),
(1887, 'MOD_ARTICLES_POPULAR', 'Материалы - Самые читаемые', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_popular.sys.ini'),
(1888, 'MOD_POPULAR_XML_DESCRIPTION', 'Этот модуль отображает список опубликованных материалов, которые были просмотрены чаще всех - определяется по количеству просмотров.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_popular.sys.ini'),
(1889, 'MOD_ARTICLES_POPULAR_LAYOUT_DEFAULT', 'По умолчанию', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_articles_popular.sys.ini'),
(1890, 'COM_BANNERS_NO_CLIENT', '- Нет клиента -', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_banners.ini'),
(1891, 'MOD_BANNERS', 'Баннеры', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_banners.ini'),
(1892, 'MOD_BANNERS_BANNER', 'Баннер', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_banners.ini'),
(1893, 'MOD_BANNERS_FIELD_BANNERCLIENT_DESC', 'Показывать баннеры только одного клиента.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_banners.ini'),
(1894, 'MOD_BANNERS_FIELD_BANNERCLIENT_LABEL', 'Клиент', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_banners.ini'),
(1895, 'MOD_BANNERS_FIELD_CACHETIME_DESC', 'Время, по истечении которого кэш модуля будет обновлён', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_banners.ini'),
(1896, 'MOD_BANNERS_FIELD_CACHETIME_LABEL', 'Время кэширования', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_banners.ini'),
(1897, 'MOD_BANNERS_FIELD_CATEGORY_DESC', 'Показывать баннеры только из одной категории.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_banners.ini'),
(1898, 'MOD_BANNERS_FIELD_COUNT_DESC', 'Количество баннеров для отображения (по умолчанию - 5)', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_banners.ini'),
(1899, 'MOD_BANNERS_FIELD_COUNT_LABEL', 'Кол-во', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_banners.ini'),
(1900, 'MOD_BANNERS_FIELD_FOOTER_DESC', 'Текст или HTML-код, который будет выводиться после группы баннеров', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_banners.ini'),
(1901, 'MOD_BANNERS_FIELD_FOOTER_LABEL', 'Нижний колонтитул', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_banners.ini'),
(1902, 'MOD_BANNERS_FIELD_HEADER_DESC', 'Текст или HTML-код, который будет выводиться перед группой баннеров', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_banners.ini'),
(1903, 'MOD_BANNERS_FIELD_HEADER_LABEL', 'Текст заголовка', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_banners.ini'),
(1904, 'MOD_BANNERS_FIELD_RANDOMISE_DESC', 'Выводить баннеры в случайном порядке', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_banners.ini'),
(1905, 'MOD_BANNERS_FIELD_RANDOMISE_LABEL', 'Случайно', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_banners.ini'),
(1906, 'MOD_BANNERS_FIELD_TAG_DESC', 'Баннер выбирается посредством поиска баннерных тегов в ключевых словах текущего документа.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_banners.ini'),
(1907, 'MOD_BANNERS_FIELD_TAG_LABEL', 'Поиск по тегу', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_banners.ini'),
(1908, 'MOD_BANNERS_FIELD_TARGET_DESC', 'Окно, в котором откроется ссылка', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_banners.ini'),
(1909, 'MOD_BANNERS_FIELD_TARGET_LABEL', 'Где открывать ссылку', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_banners.ini'),
(1910, 'MOD_BANNERS_VALUE_STICKYORDERING', 'По порядку', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_banners.ini'),
(1911, 'MOD_BANNERS_VALUE_STICKYRANDOMISE', 'Случайным образом', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_banners.ini'),
(1912, 'MOD_BANNERS_XML_DESCRIPTION', 'Модуль отображает действующие баннеры, созданные в компоненте баннеров.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_banners.ini'),
(1913, 'MOD_BANNERS', 'Баннеры', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_banners.sys.ini'),
(1914, 'MOD_BANNERS_XML_DESCRIPTION', 'Модуль отображает действующие баннеры, созданные в компоненте баннеров.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_banners.sys.ini'),
(1915, 'MOD_BANNERS_LAYOUT_DEFAULT', 'По умолчанию', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_banners.sys.ini'),
(1916, 'MOD_BREADCRUMBS', 'Навигатор сайта', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_breadcrumbs.ini'),
(1917, 'MOD_BREADCRUMBS_FIELD_HOMETEXT_DESC', 'Название самого первого пункта (главной страницы) в строке навигатора сайта. Если оставить поле пустым, будет использовано значение по умолчанию из файла mod_breadcrumbs.ini', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_breadcrumbs.ini'),
(1918, 'MOD_BREADCRUMBS_FIELD_HOMETEXT_LABEL', 'Название главной страницы', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_breadcrumbs.ini'),
(1919, 'MOD_BREADCRUMBS_FIELD_SEPARATOR_DESC', 'Текстовый разделитель.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_breadcrumbs.ini'),
(1920, 'MOD_BREADCRUMBS_FIELD_SEPARATOR_LABEL', 'Разделитель текста', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_breadcrumbs.ini'),
(1921, 'MOD_BREADCRUMBS_FIELD_SHOWHERE_DESC', 'Показывать/Скрывать текст \"Вы здесь\" в строке пути', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_breadcrumbs.ini'),
(1922, 'MOD_BREADCRUMBS_FIELD_SHOWHERE_LABEL', 'Показывать надпись \"Вы здесь\"', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_breadcrumbs.ini'),
(1923, 'MOD_BREADCRUMBS_FIELD_SHOWHOME_DESC', 'Показывать/Скрывать элемент Главная в навигаторе', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_breadcrumbs.ini'),
(1924, 'MOD_BREADCRUMBS_FIELD_SHOWHOME_LABEL', 'Показывать главную', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_breadcrumbs.ini'),
(1925, 'MOD_BREADCRUMBS_FIELD_SHOWLAST_DESC', 'Показывать/Скрывать последний элемент в навигаторе', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_breadcrumbs.ini'),
(1926, 'MOD_BREADCRUMBS_FIELD_SHOWLAST_LABEL', 'Показывать последний', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_breadcrumbs.ini'),
(1927, 'MOD_BREADCRUMBS_HERE', 'Вы здесь: ', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_breadcrumbs.ini'),
(1928, 'MOD_BREADCRUMBS_HOME', 'Главная', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_breadcrumbs.ini'),
(1929, 'MOD_BREADCRUMBS_XML_DESCRIPTION', 'Этот модуль выводит путь к текущей странице в виде строки, аналогично пути к каталогу в файловом менеджере.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_breadcrumbs.ini'),
(1930, 'MOD_BREADCRUMBS', 'Навигатор сайта', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_breadcrumbs.sys.ini'),
(1931, 'MOD_BREADCRUMBS_XML_DESCRIPTION', 'Этот модуль выводит путь к текущей странице в виде строки, аналогично пути к каталогу в файловом менеджере.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_breadcrumbs.sys.ini'),
(1932, 'MOD_BREADCRUMBS_LAYOUT_DEFAULT', 'По умолчанию', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_breadcrumbs.sys.ini'),
(1933, 'MOD_CUSTOM', 'HTML-код', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_custom.ini'),
(1934, 'MOD_CUSTOM_FIELD_PREPARE_CONTENT_DESC', 'Разрешает/запрещает обработку содержимого модуля плагинами.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_custom.ini'),
(1935, 'MOD_CUSTOM_FIELD_PREPARE_CONTENT_LABEL', 'Обрабатывать плагинами', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_custom.ini'),
(1936, 'MOD_CUSTOM_XML_DESCRIPTION', 'Модуль отображает на сайте фрагмент HTML-кода, набранного вручную или с помощью визуального HTML-редактора (WYSIWYG).', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_custom.ini'),
(1937, 'MOD_CUSTOM_FIELD_BACKGROUNDIMAGE_LABEL', 'Укажите фоновое изображение', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_custom.ini'),
(1938, 'MOD_BACKGROUNDIMAGE_FIELD_LOGO_DESC', 'Если вы укажете изображение в этом поле, оно автоматически будет привязано как inline-элемент для окружающего DIV-элемента', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_custom.ini'),
(1939, 'MOD_CUSTOM', 'HTML-код', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_custom.sys.ini'),
(1940, 'MOD_CUSTOM_XML_DESCRIPTION', 'Модуль отображает на сайте фрагмент HTML-кода, набранного вручную или с помощью визуального HTML-редактора (WYSIWYG).', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_custom.sys.ini'),
(1941, 'MOD_CUSTOM_LAYOUT_DEFAULT', 'По умолчанию', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_custom.sys.ini'),
(1942, 'MOD_FEED', 'RSS-лента новостей', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_feed.ini'),
(1943, 'MOD_FEED_ERR_CACHE', 'Пожалуйста, установите права на запись в каталог кэша', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_feed.ini'),
(1944, 'MOD_FEED_ERR_FEED_NOT_RETRIEVED', 'Лента не найдена', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_feed.ini'),
(1945, 'MOD_FEED_ERR_NO_URL', 'Не указан URL ленты новостей.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_feed.ini'),
(1946, 'MOD_FEED_FIELD_DESCRIPTION_DESC', 'Показывать описание ленты новостей', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_feed.ini'),
(1947, 'MOD_FEED_FIELD_DESCRIPTION_LABEL', 'Описание ленты новостей', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_feed.ini'),
(1948, 'MOD_FEED_FIELD_IMAGE_DESC', 'Показывать изображение, связанное с лентой новостей', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_feed.ini'),
(1949, 'MOD_FEED_FIELD_IMAGE_LABEL', 'Иконка/логотип ленты', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_feed.ini'),
(1950, 'MOD_FEED_FIELD_ITEMDESCRIPTION_DESC', 'Отображать описание или вступительную часть отдельных элементов RSS', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_feed.ini'),
(1951, 'MOD_FEED_FIELD_ITEMDESCRIPTION_LABEL', 'Описание элемента', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_feed.ini'),
(1952, 'MOD_FEED_FIELD_ITEMS_DESC', 'Укажите количество материалов из RSS, которые будут отображаться', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_feed.ini'),
(1953, 'MOD_FEED_FIELD_ITEMS_LABEL', 'Количество материалов', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_feed.ini'),
(1954, 'MOD_FEED_FIELD_RSSTITLE_DESC', 'Отображать заголовок RSS-ленты', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_feed.ini'),
(1955, 'MOD_FEED_FIELD_RSSTITLE_LABEL', 'Заголовок ленты', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_feed.ini'),
(1956, 'MOD_FEED_FIELD_RSSURL_DESC', 'Введите URL ленты RSS/RDF', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_feed.ini'),
(1957, 'MOD_FEED_FIELD_RSSURL_LABEL', 'URL ленты новостей', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_feed.ini'),
(1958, 'MOD_FEED_FIELD_RTL_DESC', 'Отображать текст справа налево', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_feed.ini'),
(1959, 'MOD_FEED_FIELD_RTL_LABEL', 'Текст справа налево', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_feed.ini'),
(1960, 'MOD_FEED_FIELD_WORDCOUNT_DESC', 'Позволяет ограничить длину видимой части текста описания. При значении 0 будет отображаться весь текст', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_feed.ini'),
(1961, 'MOD_FEED_FIELD_WORDCOUNT_LABEL', 'Количество слов', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_feed.ini'),
(1962, 'MOD_FEED_XML_DESCRIPTION', 'Этот модуль позволяет показывать ленту новостей', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_feed.ini'),
(1963, 'MOD_FEED', 'RSS-лента новостей', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_feed.sys.ini'),
(1964, 'MOD_FEED_XML_DESCRIPTION', 'Этот модуль позволяет показывать ленту новостей', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_feed.sys.ini'),
(1965, 'MOD_FEED_LAYOUT_DEFAULT', 'По умолчанию', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_feed.sys.ini'),
(1966, 'COM_FINDER_FILTER_BRANCH_LABEL', 'Искать по %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_finder.ini'),
(1967, 'COM_FINDER_FILTER_SELECT_ALL_LABEL', 'Искать всё', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_finder.ini'),
(1968, 'COM_FINDER_ADVANCED_SEARCH', 'Расширенный поиск', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_finder.ini'),
(1969, 'COM_FINDER_SELECT_SEARCH_FILTER', '- Без фильтра -', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_finder.ini'),
(1970, 'MOD_FINDER', 'Умный поиск', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_finder.ini'),
(1971, 'MOD_FINDER_CONFIG_OPTION_BOTTOM', 'Ниже', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_finder.ini'),
(1972, 'MOD_FINDER_CONFIG_OPTION_TOP', 'Выше', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_finder.ini'),
(1973, 'MOD_FINDER_FIELDSET_ADVANCED_ALT_DESCRIPTION', 'Альтернативный заголовок поля поиска.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_finder.ini'),
(1974, 'MOD_FINDER_FIELDSET_ADVANCED_ALT_LABEL', 'Альтернативный заголовок', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_finder.ini'),
(1975, 'MOD_FINDER_FIELDSET_ADVANCED_BUTTON_POS_DESCRIPTION', 'Положение кнопки относительно поля поиска.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_finder.ini'),
(1976, 'MOD_FINDER_FIELDSET_ADVANCED_BUTTON_POS_LABEL', 'Позиция кнопки', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_finder.ini'),
(1977, 'MOD_FINDER_FIELDSET_ADVANCED_FIELD_SIZE_DESCRIPTION', 'Ширина поля в символах.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_finder.ini'),
(1978, 'MOD_FINDER_FIELDSET_ADVANCED_FIELD_SIZE_LABEL', 'Размер поля поиска', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_finder.ini'),
(1979, 'MOD_FINDER_FIELDSET_ADVANCED_LABEL_POS_DESCRIPTION', 'Положение заголовка относительно поля поиска.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_finder.ini'),
(1980, 'MOD_FINDER_FIELDSET_ADVANCED_LABEL_POS_LABEL', 'Позиция заголовка', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_finder.ini'),
(1981, 'MOD_FINDER_FIELDSET_ADVANCED_SETITEMID_DESCRIPTION', 'Устанавливает значение параметра Itemid посредством выбора пункта меню, который будет использован в результатах поиска, если в меню нет ссылки на компонент поиска (com_finder). Если вы не знаете, что это такое - скорее всего вам это не требуется.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_finder.ini'),
(1982, 'MOD_FINDER_FIELDSET_ADVANCED_SETITEMID_LABEL', 'ItemID', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_finder.ini'),
(1983, 'MOD_FINDER_FIELDSET_ADVANCED_SHOW_BUTTON_DESCRIPTION', 'Показывать кнопку в форме поиска?', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_finder.ini'),
(1984, 'MOD_FINDER_FIELDSET_ADVANCED_SHOW_BUTTON_LABEL', 'Кнопка поиска', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_finder.ini'),
(1985, 'MOD_FINDER_FIELDSET_ADVANCED_SHOW_LABEL_DESCRIPTION', 'Показывать заголовок в форме поиска?', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_finder.ini'),
(1986, 'MOD_FINDER_FIELDSET_ADVANCED_SHOW_LABEL_LABEL', 'Заголовок поля поиска', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_finder.ini'),
(1987, 'MOD_FINDER_FIELDSET_BASIC_AUTOSUGGEST_DESCRIPTION', 'Показывать подсказки автоматического поиска?', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_finder.ini'),
(1988, 'MOD_FINDER_FIELDSET_BASIC_AUTOSUGGEST_LABEL', 'Автоматические подсказки', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_finder.ini'),
(1989, 'MOD_FINDER_FIELDSET_BASIC_SEARCHFILTER_DESCRIPTION', 'Установка фильтра ограничит область поиска через данный модуль.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_finder.ini'),
(1990, 'MOD_FINDER_FIELDSET_BASIC_SEARCHFILTER_LABEL', 'Фильтр поиска', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_finder.ini'),
(1991, 'MOD_FINDER_FIELDSET_BASIC_SHOW_ADVANCED_DESCRIPTION', 'Показывать навигационные элементы расширенного поиска?<br /><br />Если выбрать значение <strong>Ссылка на компонент</strong>, будет показана ссылка на отдельную страницу компонента <em>Умный Поиск</em>.<br /><br />Если выбрать значение <strong>Показать</strong>, инструменты расширенного поиска будут отображены на этой же странице.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_finder.ini'),
(1992, 'MOD_FINDER_FIELDSET_BASIC_SHOW_ADVANCED_LABEL', 'Расширенный поиск', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_finder.ini'),
(1993, 'MOD_FINDER_FIELDSET_BASIC_SHOW_ADVANCED_OPTION_LINK', 'Ссылка на компонент', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_finder.ini'),
(1994, 'MOD_FINDER_FIELD_OPENSEARCH_DESCRIPTION', 'Если эта настройка включена, некоторые браузеры смогут поддерживать поиск на вашем сайте собственными специальными инструментами.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_finder.ini'),
(1995, 'MOD_FINDER_FIELD_OPENSEARCH_LABEL', 'OpenSearch - автопоиск', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_finder.ini'),
(1996, 'MOD_FINDER_FIELD_OPENSEARCH_TEXT_DESCRIPTION', 'Текст, показываемый в браузерах, при добавлении вашего сайта, как провайдера поиска (не все браузеры поддерживают такую возможность).', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_finder.ini'),
(1997, 'MOD_FINDER_FIELD_OPENSEARCH_TEXT_LABEL', 'OpenSearch - заголовок', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_finder.ini'),
(1998, 'MOD_FINDER_SEARCHBUTTON_TEXT', 'Поиск', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_finder.ini'),
(1999, 'MOD_FINDER_SEARCH_BUTTON', 'Искать', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_finder.ini'),
(2000, 'MOD_FINDER_SEARCH_VALUE', 'Текст для поиска...', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_finder.ini'),
(2001, 'MOD_FINDER_SELECT_MENU_ITEMID', 'Выберите пункт меню', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_finder.ini'),
(2002, 'MOD_FINDER_XML_DESCRIPTION', 'Модуль - Умный Поиск.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_finder.ini'),
(2003, 'MOD_FINDER', 'Умный поиск', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_finder.sys.ini'),
(2004, 'MOD_FINDER_XML_DESCRIPTION', 'Это - модуль системы Умный Поиск.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_finder.sys.ini'),
(2005, 'MOD_FINDER_LAYOUT_DEFAULT', 'По умолчанию', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_finder.sys.ini'),
(2006, 'MOD_FOOTER', 'Нижний колонтитул (footer)', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_footer.ini'),
(2007, 'MOD_FOOTER_LINE1', '&#169; %date% %sitename%. Все права защищены.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_footer.ini'),
(2008, 'MOD_FOOTER_LINE2', '<a href=\"http://www.joomla.org\">Joomla!</a> - бесплатное программное обеспечение, распространяемое по лицензии <a href=\"http://www.gnu.org/licenses/gpl-2.0.html\">GNU General Public License.</a>', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_footer.ini'),
(2009, 'MOD_FOOTER_XML_DESCRIPTION', 'Этот модуль выводит информацию об авторских правах сайта и используемом программном обеспечении.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_footer.ini'),
(2010, 'MOD_FOOTER', 'Нижний колонтитул (footer)', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_footer.sys.ini'),
(2011, 'MOD_FOOTER_XML_DESCRIPTION', 'Этот модуль выводит информацию об авторских правах сайта и используемом программном обеспечении.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_footer.sys.ini'),
(2012, 'MOD_FOOTER_LAYOUT_DEFAULT', 'По умолчанию', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_footer.sys.ini'),
(2013, 'MOD_LANGUAGES', 'Переключение языков', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_languages.ini'),
(2014, 'MOD_LANGUAGES_FIELD_ACTIVE_DESC', 'Отображать или нет активный язык. Если включено отображение активного языка, CSS-класс \'lang-active\' будет добавлен элементу, соответствующему активному языку.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_languages.ini'),
(2015, 'MOD_LANGUAGES_FIELD_ACTIVE_LABEL', 'Активный язык', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_languages.ini'),
(2016, 'MOD_LANGUAGES_FIELD_CACHING_DESC', 'Выберите следует ли кэшировать содержимое этого модуля.<br />Если вы используете Связи элементов, необходимо выбрать значение \'Не кэшировать\'.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_languages.ini'),
(2017, 'MOD_LANGUAGES_FIELD_DROPDOWN_DESC', 'Если \'Да\', параметры, приведённые ниже, не будут учитываться. В списке будут выводиться названия языков контента.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_languages.ini'),
(2018, 'MOD_LANGUAGES_FIELD_DROPDOWN_LABEL', 'Включить выпадающий список', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_languages.ini'),
(2019, 'MOD_LANGUAGES_FIELD_DROPDOWN_IMAGE_DESC', 'Добавляет изображения флагов в раскрывающемся списке.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_languages.ini'),
(2020, 'MOD_LANGUAGES_FIELD_DROPDOWN_IMAGE_LABEL', 'Использовать флаги в выпадающем списке', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_languages.ini'),
(2021, 'MOD_LANGUAGES_FIELD_FOOTER_DESC', 'Текст или HTML-код, который отображается в нижней части модуля переключения языка', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_languages.ini'),
(2022, 'MOD_LANGUAGES_FIELD_FOOTER_LABEL', 'Заключительный текст', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_languages.ini'),
(2023, 'MOD_LANGUAGES_FIELD_FULL_NAME_DESC', 'Если \'Да\' и параметр \'Включить изображения флагов\' выключен, будут показаны полные названия языков контента. Если \'Нет\', будут показаны аббревиатуры языков, принятые в системе коротких ссылок (SEF), в верхнем регистре. Например: EN для английского, FR для французского, RU для русского.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_languages.ini'),
(2024, 'MOD_LANGUAGES_FIELD_FULL_NAME_LABEL', 'Полные названия языков', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_languages.ini'),
(2025, 'MOD_LANGUAGES_FIELD_HEADER_DESC', 'Текст или HTML-код, который отображается в верхней части модуля переключения языка', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_languages.ini'),
(2026, 'MOD_LANGUAGES_FIELD_HEADER_LABEL', 'Начальный текст', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_languages.ini'),
(2027, 'MOD_LANGUAGES_FIELD_INLINE_DESC', 'По умолчанию список языков отображается в строку, при необходимости можно включить отображение столбцом (один под другим).', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_languages.ini'),
(2028, 'MOD_LANGUAGES_FIELD_INLINE_LABEL', 'Показывать строкой', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_languages.ini'),
(2029, 'MOD_LANGUAGES_FIELD_LINEHEIGHT_DESC', 'Если выбрано \'Да\', уменьшит высоту строки при использовании флагов.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_languages.ini'),
(2030, 'MOD_LANGUAGES_FIELD_LINEHEIGHT_LABEL', 'Высота строки', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_languages.ini'),
(2031, 'MOD_LANGUAGES_FIELD_MODULE_LAYOUT_DESC', 'Использовать другой макет из имеющихся в комплекте модуля или переопределить в шаблоне по умолчанию. При значении \'По умолчанию\' будут показаны флаги языков.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_languages.ini'),
(2032, 'MOD_LANGUAGES_FIELD_USEIMAGE_DESC', 'Включить изображения флагов стран', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_languages.ini'),
(2033, 'MOD_LANGUAGES_FIELD_USEIMAGE_LABEL', 'Включить изображения флагов', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_languages.ini'),
(2034, 'MOD_LANGUAGES_OPTION_DEFAULT_LANGUAGE', 'По умолчанию', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_languages.ini'),
(2035, 'MOD_LANGUAGES_SPACERDROP_LABEL', '<u>Если включен параметр \'Включить выпадающий список\', <br />указанные ниже настройки будут игнорироваться</u>', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_languages.ini'),
(2036, 'MOD_LANGUAGES_SPACERNAME_LABEL', '<u>Если включен параметр \'Включить изображения флагов\', <br />указанные ниже настройки будут игнорироваться</u>', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_languages.ini'),
(2037, 'MOD_LANGUAGES_SPACER_USENAME_LABEL', '<u>\'Использования раскрывающегося меню\' и \'Использование изображения флагов\' были установлены в \'Нет\', < br / > переключатель будет отображать названия языков.</u>', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_languages.ini'),
(2038, 'MOD_LANGUAGES_XML_DESCRIPTION', 'Этот модуль отображает список доступных Языков контента (их можно найти на странице \'Языки контента\' в Менеджере языков), между которыми можно переключаться при использовании на сайте системы многоязычности.<br />-- Плагин <strong>Система - Фильтр языка</strong> должен быть опубликован.<br />-- При переключении языков, если пункт меню данной страницы не привязан к другому пункту меню, модуль перенаправит посетителя на Главную страницу сайта, соответствующую данному языку.<br />В противном случае, если включен соответствующий параметр в плагине «Система - Фильтр языка», пользователь будет перенаправлен на пункт меню, соответствующий данной странице на выбранном им языке. Соответственно будут перестроены и прочие элементы навигации. <br />Обратите внимание, что если плагин <strong>Система - Фильтр языка</strong> снят с публикации, может возникнуть непредвиденная ситуация, которая приведёт к ошибке в системе.<br /><strong>Метод решения проблемы:</strong><br />1. Перейдите в Менеджер языков, на закладку Языки контента, и убедитесь, что языки, для которых вы хотите создать на сайте связанные страницы, опубликованы и каждому из них назначен Код языка для использования в URL. Так же убедитесь, что указан префикс файла изображения, которое будет выводиться в модуле выбора языка.<br />2. Укажите страницу, которая будет являться Главной для каждого опубликованного языка контента. <br />3. После этого вы можете привязать к языку любой Материал, Категорию, Ленту новостей и прочее содержимое Joomla!<br /> 4. Убедитесь, что модуль и плагин опубликованы. <br />5. При использовании привязки пунктов меню к языку проверяйте, что модуль опубликован на всех привязываемых страницах. <br />6. Порядок показа полных названий языков или изображений флагов определяется в Менеджере языков, на странице Языки контента.<br /><br />Если этот модуль опубликован, рекомендуется опубликовать модуль панели управления «Мультиязычность».', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_languages.ini'),
(2039, 'MOD_LANGUAGES', 'Переключение языков', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_languages.sys.ini'),
(2040, 'MOD_LANGUAGES_XML_DESCRIPTION', 'Этот модуль отображает список доступных Языков контента (их можно найти на странице \'Языки контента\' в Менеджере языков), между которыми можно переключаться при использовании на сайте системы многоязычности.<br />-- Плагин \'Система - Фильтр языков\' должен быть опубликован.<br />-- При переключении языков, если пункт меню данной страницы не привязан к другому пункту меню, модуль перенаправит посетителя на Главную страницу сайта, соответствующую данному языку.<br />В противном случае, если включен соответствующий параметр в плагине ‘Система - Фильтр языка’, пользователь будет перенаправлен на пункт меню, соответствующий данной странице на выбранном им языке. Соответственно будут перестроены и прочие элементы навигации. <br />Обратите внимание, что, если плагин <strong>‘Система - Фильтр языка’</strong> снят с публикации, может возникнуть непредвиденная ситуация, которая приведёт к ошибке в системе.<br /><strong>Метод решения проблемы:</strong><br />1. Перейдите в Менеджер Языков, на закладку Содержимое, и убедитесь, что языки, для которых вы хотите создать на сайте связанные страницы, опубликованы и каждому из них назначен Код Языка для использования в URL. Так же убедитесь, что указан префикс файла изображения, которое будет выводиться в модуле выбора языка.<br />2. Укажите страницу, которая будет являться Главной для каждого опубликованного языка содержимого. <br />3. После этого вы можете привязать к языку любой Материал, Категорию, Ленту новостей и прочее содержимое Joomla!<br /> 4. Убедитесь, что модуль и плагин опубликованы. <br />5. При использовании привязки пунктов меню к языку проверяйте, что модуль опубликован на всех привязываемых страницах. <br />6. Порядок показа полных названий языков или изображений флагов определяется в Менеджере Языков, на странице Содержимое.<br ><br >Если этот модуль опубликован, рекомендуется опубликовать модуль панели управления «Мультиязычность».', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_languages.sys.ini'),
(2041, 'MOD_LANGUAGES_LAYOUT_DEFAULT', 'По умолчанию', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_languages.sys.ini'),
(2042, 'MOD_LOGIN', 'Вход на сайт', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_login.ini'),
(2043, 'MOD_LOGIN_FIELD_GREETING_DESC', 'Показывать/Скрывать текст приветствия', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_login.ini'),
(2044, 'MOD_LOGIN_FIELD_GREETING_LABEL', 'Показывать приветствие', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_login.ini'),
(2045, 'MOD_LOGIN_FIELD_LOGIN_REDIRECTURL_DESC', 'Укажите страницу, на которую следует перенаправить пользователя после выполнения входа в систему. Выберите нужную из выпадающего списка. Выбор значения \"По умолчанию\" вернёт пользователя на ту же страницу.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_login.ini'),
(2046, 'MOD_LOGIN_FIELD_LOGIN_REDIRECTURL_LABEL', 'Перенаправление при входе', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_login.ini'),
(2047, 'MOD_LOGIN_FIELD_LOGOUT_REDIRECTURL_DESC', 'Укажите страницу, на которую следует перенаправить пользователя после выполнения выхода из системы. Выберите нужную из выпадающего списка. Выбор значения \"По умолчанию\" вернёт пользователя на ту же страницу.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_login.ini'),
(2048, 'MOD_LOGIN_FIELD_LOGOUT_REDIRECTURL_LABEL', 'Перенаправление при выходе', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_login.ini'),
(2049, 'MOD_LOGIN_FIELD_NAME_DESC', 'Показывает имя или логин пользователя после входа в систему', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_login.ini'),
(2050, 'MOD_LOGIN_FIELD_NAME_LABEL', 'Показывать имя/логин', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_login.ini'),
(2051, 'MOD_LOGIN_FIELD_POST_TEXT_DESC', 'HTML-текст, отображаемый под формой авторизации.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_login.ini'),
(2052, 'MOD_LOGIN_FIELD_POST_TEXT_LABEL', 'Заключительный текст', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_login.ini'),
(2053, 'MOD_LOGIN_FIELD_PRE_TEXT_DESC', 'HTML-текст, отображаемый над формой авторизации.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_login.ini'),
(2054, 'MOD_LOGIN_FIELD_PRE_TEXT_LABEL', 'Начальный текст', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_login.ini'),
(2055, 'MOD_LOGIN_FIELD_PROFILE_LABEL', 'Показать ссылку на профиль', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_login.ini'),
(2056, 'MOD_LOGIN_FIELD_PROFILE_DESC', 'Показать ссылку на страницу профиля пользователя после входа в систему.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_login.ini'),
(2057, 'MOD_LOGIN_FIELD_USESECURE_DESC', 'Отправлять учётные данные в шифрованном виде (необходима поддержка SSL). Не включайте эту опцию, если Joomla! не настроена на использование протокола https.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_login.ini'),
(2058, 'MOD_LOGIN_FIELD_USESECURE_LABEL', 'Защищённая форма регистрации', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_login.ini'),
(2059, 'MOD_LOGIN_FIELD_USETEXT_DESC', 'Определяет режим отображения наименования полей в форме &mdash; в виде иконок или в виде текста. По умолчанию &mdash; иконки.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_login.ini'),
(2060, 'MOD_LOGIN_FIELD_USETEXT_LABEL', 'Название полей формы', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_login.ini'),
(2061, 'MOD_LOGIN_FORGOT_YOUR_PASSWORD', 'Забыли пароль?', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_login.ini'),
(2062, 'MOD_LOGIN_FORGOT_YOUR_USERNAME', 'Забыли логин?', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_login.ini'),
(2063, 'MOD_LOGIN_HINAME', 'Здравствуйте, %s', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_login.ini'),
(2064, 'MOD_LOGIN_PROFILE', 'Показать Профиль', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_login.ini'),
(2065, 'MOD_LOGIN_REGISTER', 'Регистрация', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_login.ini'),
(2066, 'MOD_LOGIN_REMEMBER_ME', 'Запомнить меня', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_login.ini'),
(2067, 'MOD_LOGIN_VALUE_ICONS', 'Иконки', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_login.ini'),
(2068, 'MOD_LOGIN_VALUE_NAME', 'Имя', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_login.ini'),
(2069, 'MOD_LOGIN_VALUE_TEXT', 'Текст', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_login.ini'),
(2070, 'MOD_LOGIN_VALUE_USERNAME', 'Логин', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_login.ini'),
(2071, 'MOD_LOGIN_XML_DESCRIPTION', 'Этот модуль отображает форму для ввода логина и пароля пользователя при входе в систему. Также он отображает ссылку на страницу восстановления забытого пароля. Если включена система самостоятельной регистрации пользователей (на странице настроек Менеджера пользователей), будет показана так же ссылка на страницу регистрации.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_login.ini'),
(2072, 'MOD_LOGIN', 'Вход на сайт', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_login.sys.ini'),
(2073, 'MOD_LOGIN_XML_DESCRIPTION', 'Этот модуль отображает форму для ввода логина и пароля пользователя при входе в систему. Также он отображает ссылку на страницу восстановления забытого пароля. Если включена система самостоятельной регистрации пользователей (на странице настроек Менеджера пользователей), будет показана так же ссылка на страницу регистрации.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_login.sys.ini'),
(2074, 'MOD_LOGIN_LAYOUT_DEFAULT', 'По умолчанию', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_login.sys.ini'),
(2075, 'MOD_MENU', 'Меню', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_menu.ini'),
(2076, 'MOD_MENU_FIELD_ACTIVE_DESC', 'Выберите пункт меню, который будет использован в качестве базового для данного меню. Вы должны установить Начальный уровень таким же (или выше) как у базового пункта меню. Это позволит модулю отображаться на всех назначенных страницах. Если выбрано значение «Текущий», то активный пункт меню будет использован в качестве базового. Это позволит модулю отображаться только в том случае, если активен родительский пункт меню.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_menu.ini'),
(2077, 'MOD_MENU_FIELD_ACTIVE_LABEL', 'Базовый пункт меню', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_menu.ini'),
(2078, 'MOD_MENU_FIELD_ALLCHILDREN_DESC', 'Раскрывать меню и показывать его подменю.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_menu.ini'),
(2079, 'MOD_MENU_FIELD_ALLCHILDREN_LABEL', 'Показывать подпункты меню', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_menu.ini'),
(2080, 'MOD_MENU_FIELD_CLASS_DESC', 'Суффикс добавляется к имени CSS-класса меню по умолчанию', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_menu.ini'),
(2081, 'MOD_MENU_FIELD_CLASS_LABEL', 'Суффикс класса меню', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_menu.ini'),
(2082, 'MOD_MENU_FIELD_ENDLEVEL_DESC', 'Уровень, на котором будет прекращено построение дерева пунктов меню. Если выбрать \'Все\', будут показаны все уровни, в зависимости от значения параметра \'Показывать подпункты меню\'.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_menu.ini'),
(2083, 'MOD_MENU_FIELD_ENDLEVEL_LABEL', 'Последний уровень', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_menu.ini'),
(2084, 'MOD_MENU_FIELD_MENUTYPE_DESC', 'Выберите меню из списка', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_menu.ini'),
(2085, 'MOD_MENU_FIELD_MENUTYPE_LABEL', 'Выбор меню', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_menu.ini'),
(2086, 'MOD_MENU_FIELD_STARTLEVEL_DESC', 'Уровень, с которого будет начато построение дерева меню. Если установить номер уровня начала и номера окончания одинаковыми, а так же выбрать значение \'Да\' для параметра \'Показывать подпункты меню\', будет отображаться только один уровень.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_menu.ini'),
(2087, 'MOD_MENU_FIELD_STARTLEVEL_LABEL', 'Начальный уровень', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_menu.ini'),
(2088, 'MOD_MENU_FIELD_TAG_ID_DESC', 'Атрибут ID, назначаемый для корневого тега UL меню (необязательно)', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_menu.ini'),
(2089, 'MOD_MENU_FIELD_TAG_ID_LABEL', 'ID Меню', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_menu.ini'),
(2090, 'MOD_MENU_FIELD_TARGET_DESC', 'Параметры JavaScript для определения позиции всплывающего окна. Например: top=50,left=50,width=200,height=300', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_menu.ini'),
(2091, 'MOD_MENU_FIELD_TARGET_LABEL', 'Позиция назначения', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_menu.ini'),
(2092, 'MOD_MENU_XML_DESCRIPTION', 'Этот модуль отображает меню на страницах сайта.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_menu.ini'),
(2093, 'MOD_MENU', 'Меню', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_menu.sys.ini'),
(2094, 'MOD_MENU_XML_DESCRIPTION', 'Этот модуль отображает меню на страницах сайта.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_menu.sys.ini'),
(2095, 'MOD_MENU_LAYOUT_DEFAULT', 'По умолчанию', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_menu.sys.ini'),
(2096, 'MOD_RANDOM_IMAGE', 'Произвольное изображение', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_random_image.ini'),
(2097, 'MOD_RANDOM_IMAGE_FIELD_FOLDER_DESC', 'Путь к каталогу изображений, относительно URL-адреса сайта (например, images).', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_random_image.ini'),
(2098, 'MOD_RANDOM_IMAGE_FIELD_FOLDER_LABEL', 'Каталог с изображениями', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_random_image.ini'),
(2099, 'MOD_RANDOM_IMAGE_FIELD_HEIGHT_DESC', 'Показывать все изображения одинаковой высоты (высота задаётся в пикселях).', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_random_image.ini'),
(2100, 'MOD_RANDOM_IMAGE_FIELD_HEIGHT_LABEL', 'Высота', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_random_image.ini'),
(2101, 'MOD_RANDOM_IMAGE_FIELD_LINK_DESC', 'Укажите URL, на который будет перенаправлен пользователь, при нажатии на изображение.<br/>Например: http://joomlaportal.ru', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_random_image.ini'),
(2102, 'MOD_RANDOM_IMAGE_FIELD_LINK_LABEL', 'Ссылка', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_random_image.ini'),
(2103, 'MOD_RANDOM_IMAGE_FIELD_TYPE_DESC', 'Тип картинки PNG/GIF/JPG и т.д. (по умолчанию JPG)', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_random_image.ini'),
(2104, 'MOD_RANDOM_IMAGE_FIELD_TYPE_LABEL', 'Тип изображения', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_random_image.ini'),
(2105, 'MOD_RANDOM_IMAGE_FIELD_WIDTH_DESC', 'Показывать все изображения одинаковой ширины (ширина задаётся в пикселях).', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_random_image.ini'),
(2106, 'MOD_RANDOM_IMAGE_FIELD_WIDTH_LABEL', 'Ширина', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_random_image.ini'),
(2107, 'MOD_RANDOM_IMAGE_NO_IMAGES', 'Нет изображений', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_random_image.ini'),
(2108, 'MOD_RANDOM_IMAGE_XML_DESCRIPTION', 'Этот модуль выводит случайно выбранное изображение из заданного каталога.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_random_image.ini'),
(2109, 'MOD_RANDOM_IMAGE', 'Случайное изображение', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_random_image.sys.ini'),
(2110, 'MOD_RANDOM_IMAGE_XML_DESCRIPTION', 'Этот модуль выводит случайно выбранное изображение из заданного каталога.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_random_image.sys.ini'),
(2111, 'MOD_RANDOM_IMAGE_LAYOUT_DEFAULT', 'По умолчанию', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_random_image.sys.ini'),
(2112, 'MOD_RELATED_FIELD_MAX_DESC', 'Количество отображаемых материалов (по умолчанию - 5)', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_related_items.ini'),
(2113, 'MOD_RELATED_FIELD_MAX_LABEL', 'Кол-во материалов', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_related_items.ini'),
(2114, 'MOD_RELATED_FIELD_SHOWDATE_DESC', 'Показывать/Скрывать дату', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_related_items.ini'),
(2115, 'MOD_RELATED_FIELD_SHOWDATE_LABEL', 'Показывать дату', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_related_items.ini'),
(2116, 'MOD_RELATED_ITEMS', 'Материалы - Связанные материалы', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_related_items.ini'),
(2117, 'MOD_RELATED_XML_DESCRIPTION', 'Этот модуль отображает список ссылок на материалы, которые связаны с тем, что в данный момент отображается в центральной области страницы. Связи определяются по ключевым словам, введённым в параметрах материала.<br />Все ключевые слова данной статьи ищутся в списках ключевых слов других опубликованных материалов. Например, у вас есть материалы \"Разведение попугаев\" и другой материал \"Руководство по разведению чёрных какаду\". Если вы включите ключевое слово \"попугай\" в оба эти материала, модуль \'Связанные материалы\' будет считать их связанными и покажет ссылку на материал \"Разведение попугаев\" при просмотре материала \"Руководство по разведению чёрных какаду\" и так далее.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_related_items.ini'),
(2118, 'MOD_RELATED_ITEMS', 'Материалы - Связанные материалы', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_related_items.sys.ini');
INSERT INTO `jm_overrider` (`id`, `constant`, `string`, `file`) VALUES
(2119, 'MOD_RELATED_XML_DESCRIPTION', 'Этот модуль отображает список ссылок на материалы, которые связаны с тем, что в данный момент отображается в центральной области страницы. Связи определяются по ключевым словам, введённым в параметрах материала.<br />Все ключевые слова данной статьи ищутся в списках ключевых слов других опубликованных материалов. Например, у вас есть материалы \"Разведение попугаев\" и другой материал \"Руководство по разведению чёрных какаду\". Если вы включите ключевое слово \"попугай\" в оба эти материала, модуль \'Связанные материалы\' будет считать их связанными и покажет ссылку на материал \"Разведение попугаев\" при просмотре материала \"Руководство по разведению чёрных какаду\" и так далее.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_related_items.sys.ini'),
(2120, 'MOD_RELATED_ITEMS_LAYOUT_DEFAULT', 'По умолчанию', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_related_items.sys.ini'),
(2121, 'MOD_SEARCH', 'Поиск', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_search.ini'),
(2122, 'MOD_SEARCH_FIELD_BOXWIDTH_DESC', 'Размер поля поиска (в символах)', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_search.ini'),
(2123, 'MOD_SEARCH_FIELD_BOXWIDTH_LABEL', 'Ширина поля', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_search.ini'),
(2124, 'MOD_SEARCH_FIELD_BUTTON_DESC', 'Показывать кнопку поиска', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_search.ini'),
(2125, 'MOD_SEARCH_FIELD_BUTTON_LABEL', 'Кнопка поиска', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_search.ini'),
(2126, 'MOD_SEARCH_FIELD_BUTTONPOS_DESC', 'Положение кнопки по отношению к полю поиска.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_search.ini'),
(2127, 'MOD_SEARCH_FIELD_BUTTONPOS_LABEL', 'Позиция кнопки', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_search.ini'),
(2128, 'MOD_SEARCH_FIELD_BUTTONTEXT_DESC', 'Текст, который будет отображён на кнопке поиска. Если оставить пустым, будет использоваться значение переменной \'searchbutton\' из языкового файла.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_search.ini'),
(2129, 'MOD_SEARCH_FIELD_BUTTONTEXT_LABEL', 'Текст на кнопке', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_search.ini'),
(2130, 'MOD_SEARCH_FIELD_IMAGEBUTTON_DESC', 'Использовать изображения в качестве кнопки. Файл изображения должен иметь имя \'searchButton.gif\' и должен быть расположен в каталоге: templates/*имя вашего шаблона*/images/', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_search.ini'),
(2131, 'MOD_SEARCH_FIELD_IMAGEBUTTON_LABEL', 'Изображение кнопки поиска', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_search.ini'),
(2132, 'MOD_SEARCH_FIELD_SETITEMID_DESC', 'Устанавливает значение параметра Itemid, который будет использован в результатах поиска, если в меню нет ссылки на компонент поиска (com_search).', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_search.ini'),
(2133, 'MOD_SEARCH_FIELD_SETITEMID_LABEL', 'Itemid', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_search.ini'),
(2134, 'MOD_SEARCH_FIELD_LABEL_TEXT_DESC', 'Текст, который будет выведен в качестве заголовка, рядом с полем поиска. Если оставить пустым, будет использоваться значение переменной \'label\' из языкового файла.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_search.ini'),
(2135, 'MOD_SEARCH_FIELD_LABEL_TEXT_LABEL', 'Заголовок поля', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_search.ini'),
(2136, 'MOD_SEARCH_FIELD_OPENSEARCH_LABEL', 'OpenSearch - автопоиск', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_search.ini'),
(2137, 'MOD_SEARCH_FIELD_OPENSEARCH_TEXT_LABEL', 'OpenSearch - заголовок', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_search.ini'),
(2138, 'MOD_SEARCH_FIELD_OPENSEARCH_TEXT_DESC', 'Текст, который будет отображаться в браузерах, при добавлении вашего сайта, как Провайдера поиска (не все браузеры поддерживают такую возможность).', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_search.ini'),
(2139, 'MOD_SEARCH_FIELD_OPENSEARCH_DESC', 'Если данный параметр включен, некоторые браузеры смогут выполнять поиск по вашему сайту.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_search.ini'),
(2140, 'MOD_SEARCH_FIELD_TEXT_DESC', 'Текст, который будет выведен в поле поиска. Если оставить пустым, будет использоваться значение переменной \'searchbox\' из языкового файла.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_search.ini'),
(2141, 'MOD_SEARCH_FIELD_TEXT_LABEL', 'Текст в поле', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_search.ini'),
(2142, 'MOD_SEARCH_FIELD_VALUE_BOTTOM', 'Снизу', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_search.ini'),
(2143, 'MOD_SEARCH_FIELD_VALUE_LEFT', 'Слева', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_search.ini'),
(2144, 'MOD_SEARCH_FIELD_VALUE_RIGHT', 'Справа', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_search.ini'),
(2145, 'MOD_SEARCH_FIELD_VALUE_TOP', 'Сверху', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_search.ini'),
(2146, 'MOD_SEARCH_LABEL_TEXT', 'Искать...', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_search.ini'),
(2147, 'MOD_SEARCH_SEARCHBOX_TEXT', 'Поиск...', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_search.ini'),
(2148, 'MOD_SEARCH_SEARCHBUTTON_TEXT', 'Искать', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_search.ini'),
(2149, 'MOD_SEARCH_SELECT_MENU_ITEMID', 'Выберите пункт меню', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_search.ini'),
(2150, 'MOD_SEARCH_XML_DESCRIPTION', 'Этот модуль отображает форму поиска.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_search.ini'),
(2151, 'MOD_SEARCH', 'Поиск', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_search.sys.ini'),
(2152, 'MOD_SEARCH_XML_DESCRIPTION', 'Этот модуль отображает форму поиска.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_search.sys.ini'),
(2153, 'MOD_SEARCH_LAYOUT_DEFAULT', 'По умолчанию', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_search.sys.ini'),
(2154, 'MOD_STATS', 'Статистика', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_stats.ini'),
(2155, 'MOD_STATS_ARTICLES', 'Материалы', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_stats.ini'),
(2156, 'MOD_STATS_ARTICLES_VIEW_HITS', 'Количество просмотров материалов', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_stats.ini'),
(2157, 'MOD_STATS_CACHING', 'Кэширование', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_stats.ini'),
(2158, 'MOD_STATS_FIELD_COUNTER_DESC', 'Показывать счётчик просмотров', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_stats.ini'),
(2159, 'MOD_STATS_FIELD_COUNTER_LABEL', 'Счётчик просмотров', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_stats.ini'),
(2160, 'MOD_STATS_FIELD_INCREASECOUNTER_DESC', 'Введите кол-во просмотров для увеличения показаний счётчика.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_stats.ini'),
(2161, 'MOD_STATS_FIELD_INCREASECOUNTER_LABEL', 'Увеличить показания счётчика', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_stats.ini'),
(2162, 'MOD_STATS_FIELD_SERVERINFO_DESC', 'Отображать информацию о веб-сервере', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_stats.ini'),
(2163, 'MOD_STATS_FIELD_SERVERINFO_LABEL', 'Информация о сервере', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_stats.ini'),
(2164, 'MOD_STATS_FIELD_SITEINFO_DESC', 'Отображать информацию о сайте', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_stats.ini'),
(2165, 'MOD_STATS_FIELD_SITEINFO_LABEL', 'Информация о сайте', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_stats.ini'),
(2166, 'MOD_STATS_GZIP', 'GZip', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_stats.ini'),
(2167, 'MOD_STATS_MYSQL', 'MySQL', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_stats.ini'),
(2168, 'MOD_STATS_OS', 'ОС', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_stats.ini'),
(2169, 'MOD_STATS_PHP', 'PHP', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_stats.ini'),
(2170, 'MOD_STATS_TIME', 'Время', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_stats.ini'),
(2171, 'MOD_STATS_USERS', 'Посетители', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_stats.ini'),
(2172, 'MOD_STATS_WEBLINKS', 'Ссылки', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_stats.ini'),
(2173, 'MOD_STATS_XML_DESCRIPTION', 'Модуль статистики отображает информацию о сервере вместе со статистикой о пользователях сайта, количестве статей и ссылок в БД.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_stats.ini'),
(2174, 'MOD_STATS', 'Статистика', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_stats.sys.ini'),
(2175, 'MOD_STATS_XML_DESCRIPTION', 'Модуль статистики отображает информацию о сервере вместе со статистикой о пользователях сайта, количестве статей и ссылок в БД.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_stats.sys.ini'),
(2176, 'MOD_STATS_LAYOUT_DEFAULT', 'По умолчанию', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_stats.sys.ini'),
(2177, 'MOD_SYNDICATE', 'RSS-ленты', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_syndicate.ini'),
(2178, 'MOD_SYNDICATE_DEFAULT_FEED_ENTRIES', 'RSS-лента', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_syndicate.ini'),
(2179, 'MOD_SYNDICATE_FIELD_DISPLAYTEXT_DESC', 'Если выбрано \'Да\', то рядом со значком ссылки на RSS-ленту новостей будет отображаться текст', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_syndicate.ini'),
(2180, 'MOD_SYNDICATE_FIELD_DISPLAYTEXT_LABEL', 'Показывать текст', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_syndicate.ini'),
(2181, 'MOD_SYNDICATE_FIELD_FORMAT_DESC', 'Укажите формат выводимых данных', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_syndicate.ini'),
(2182, 'MOD_SYNDICATE_FIELD_FORMAT_LABEL', 'Формат ленты', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_syndicate.ini'),
(2183, 'MOD_SYNDICATE_FIELD_TEXT_DESC', 'Если параметр &laquo;Показывать текст&raquo; имеет значение \'Да\', то введённый текст будет отображаться рядом со значком ссылки на RSS-ленту новостей. Если данное поле оставить пустым, то будет использоваться значение из языкового файла', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_syndicate.ini'),
(2184, 'MOD_SYNDICATE_FIELD_TEXT_LABEL', 'Текст', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_syndicate.ini'),
(2185, 'MOD_SYNDICATE_FIELD_VALUE_ATOM', 'Atom 1.0', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_syndicate.ini'),
(2186, 'MOD_SYNDICATE_FIELD_VALUE_RSS', 'RSS 2.0', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_syndicate.ini'),
(2187, 'MOD_SYNDICATE_XML_DESCRIPTION', 'Модуль создаёт RSS-ленту для страницы, на которой отображается.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_syndicate.ini'),
(2188, 'MOD_SYNDICATE', 'Ленты новостей', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_syndicate.sys.ini'),
(2189, 'MOD_SYNDICATE_XML_DESCRIPTION', 'Модуль создаёт RSS-ленту для страницы, на которой отображается.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_syndicate.sys.ini'),
(2190, 'MOD_SYNDICATE_LAYOUT_DEFAULT', 'По умолчанию', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_syndicate.sys.ini'),
(2191, 'MOD_TAGS_POPULAR', 'Популярные метки', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_tags_popular.ini'),
(2192, 'MOD_TAGS_POPULAR_FIELD_ALL_TIME', 'Всё время', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_tags_popular.ini'),
(2193, 'MOD_TAGS_POPULAR_FIELD_DISPLAY_COUNT_DESC', 'Позволяет включить отображение количества элементов, отмеченных метками.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_tags_popular.ini'),
(2194, 'MOD_TAGS_POPULAR_FIELD_DISPLAY_COUNT_LABEL', 'Показывать кол-во элементов', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_tags_popular.ini'),
(2195, 'MOD_TAGS_POPULAR_FIELD_LAST_DAY', 'Последний день', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_tags_popular.ini'),
(2196, 'MOD_TAGS_POPULAR_FIELD_LAST_HOUR', 'Последний час', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_tags_popular.ini'),
(2197, 'MOD_TAGS_POPULAR_FIELD_LAST_MONTH', 'Последний месяц', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_tags_popular.ini'),
(2198, 'MOD_TAGS_POPULAR_FIELD_LAST_WEEK', 'Последняя неделя', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_tags_popular.ini'),
(2199, 'MOD_TAGS_POPULAR_FIELD_LAST_YEAR', 'Последний год', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_tags_popular.ini'),
(2200, 'MOD_TAGS_POPULAR_FIELD_MAX_DESC', 'Устанавливает максимальное количество меток для отображения в модуле. Введите \"0\" для отображения всех имеющихся меток.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_tags_popular.ini'),
(2201, 'MOD_TAGS_POPULAR_FIELD_MAX_LABEL', 'Кол-во меток', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_tags_popular.ini'),
(2202, 'MOD_TAGS_POPULAR_FIELD_MAXSIZE_DESC', 'Максимальный размер шрифта, используемый для меток (пропорционально размеру шрифта сайта по умолчанию - \"2\" означает 200% от размера шрифта сайта).', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_tags_popular.ini'),
(2203, 'MOD_TAGS_POPULAR_FIELD_MAXSIZE_LABEL', 'Максимальный шрифт', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_tags_popular.ini'),
(2204, 'MOD_TAGS_POPULAR_FIELD_MINSIZE_DESC', 'Минимальный размер шрифта, используемый для меток (пропорционально размеру шрифта сайта по умолчанию - \"2\" означает 200% от размера шрифта сайта).', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_tags_popular.ini'),
(2205, 'MOD_TAGS_POPULAR_FIELD_MINSIZE_LABEL', 'Минимальный шрифт', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_tags_popular.ini'),
(2206, 'MOD_TAGS_POPULAR_FIELD_NO_RESULTS_DESC', 'Показывать сообщение если метки не найдены или скрывать модуль.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_tags_popular.ini'),
(2207, 'MOD_TAGS_POPULAR_FIELD_NO_RESULTS_LABEL', 'Показывать текст \"Метки отсутствуют\"', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_tags_popular.ini'),
(2208, 'MOD_TAGS_POPULAR_FIELD_ORDER_VALUE_COUNT', 'Кол-во элементов', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_tags_popular.ini'),
(2209, 'MOD_TAGS_POPULAR_FIELD_ORDER_VALUE_DESC', 'Порядок отображения меток.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_tags_popular.ini'),
(2210, 'MOD_TAGS_POPULAR_FIELD_ORDER_VALUE_LABEL', 'Порядок', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_tags_popular.ini'),
(2211, 'MOD_TAGS_POPULAR_FIELD_ORDER_VALUE_RANDOM', 'Случайный', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_tags_popular.ini'),
(2212, 'MOD_TAGS_POPULAR_FIELD_ORDER_VALUE_TITLE', 'Заголовок', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_tags_popular.ini'),
(2213, 'MOD_TAGS_POPULAR_FIELD_TIMEFRAME_DESC', 'Позволяет задать период времени, в течение которого будет вычисляться популярность меток', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_tags_popular.ini'),
(2214, 'MOD_TAGS_POPULAR_FIELD_TIMEFRAME_LABEL', 'Период', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_tags_popular.ini'),
(2215, 'MOD_TAGS_POPULAR_FIELDSET_CLOUD_LABEL', 'Облако меток', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_tags_popular.ini'),
(2216, 'MOD_TAGS_POPULAR_MAX_DESC', 'Устанавливает максимальное количество меток для отображения в модуле', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_tags_popular.ini'),
(2217, 'MOD_TAGS_POPULAR_MAX_LABEL', 'Кол-во меток', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_tags_popular.ini'),
(2218, 'MOD_TAGS_POPULAR_NO_ITEMS_FOUND', 'Метки отсутствуют.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_tags_popular.ini'),
(2219, 'MOD_TAGS_POPULAR_PARENT_TAG_DESC', 'Ограничивает показанные метки дочерними этого родительского тега.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_tags_popular.ini'),
(2220, 'MOD_TAGS_POPULAR_PARENT_TAG_LABEL', 'Родительская метка', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_tags_popular.ini'),
(2221, 'MOD_TAGS_POPULAR_XML_DESCRIPTION', 'Отображает список наиболее популярных меток (в параметрах модуля можно задать период времени, за который выбираются метки).', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_tags_popular.ini'),
(2222, 'MOD_TAGS_POPULAR', 'Популярные метки', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_tags_popular.sys.ini'),
(2223, 'MOD_TAGS_POPULAR_LAYOUT_CLOUD', 'Облако меток', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_tags_popular.sys.ini'),
(2224, 'MOD_TAGS_POPULAR_LAYOUT_DEFAULT', 'По умолчанию', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_tags_popular.sys.ini'),
(2225, 'MOD_TAGS_POPULAR_XML_DESCRIPTION', 'Отображает список наиболее популярных меток (в параметрах модуля можно задать период времени, за который выбираются метки).', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_tags_popular.sys.ini'),
(2226, 'MOD_TAGS_SIMILAR', 'Похожие метки', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_tags_similar.ini'),
(2227, 'MOD_TAGS_SIMILAR_FIELD_ALL', 'Все', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_tags_similar.ini'),
(2228, 'MOD_TAGS_SIMILAR_FIELD_HALF', 'Половина', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_tags_similar.ini'),
(2229, 'MOD_TAGS_SIMILAR_FIELD_MATCHTYPE_DESC', 'Определяет насколько метки элементов должны совпадать. Значение <strong>Все</strong> требует наличия у элементов всех меток, которые присутствуют у текущего элемента. Значение <strong>Любая</strong> требует наличие у элементов хотя бы одной метки, из меток текущего элемента. Значение <strong>Половина</strong> требует наличия у элементов половины меток, из меток текущего элемента.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_tags_similar.ini'),
(2230, 'MOD_TAGS_SIMILAR_FIELD_MATCHTYPE_LABEL', 'Совпадение', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_tags_similar.ini'),
(2231, 'MOD_TAGS_SIMILAR_FIELD_ONE', 'Любая', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_tags_similar.ini'),
(2232, 'MOD_TAGS_SIMILAR_LAYOUT_DEFAULT', 'По умолчанию', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_tags_similar.ini'),
(2233, 'MOD_TAGS_SIMILAR_MAX_DESC', 'Количество отображаемых элементов', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_tags_similar.ini'),
(2234, 'MOD_TAGS_SIMILAR_MAX_LABEL', 'Кол-во элементов', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_tags_similar.ini'),
(2235, 'MOD_TAGS_SIMILAR_NO_MATCHING_TAGS', 'Нет похожих меток', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_tags_similar.ini'),
(2236, 'MOD_TAGS_SIMILAR_XML_DESCRIPTION', 'Модуль отображает ссылки на другие элементы с похожими метками. Степень совпадения меток может быть настроена в параметрах модуля', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_tags_similar.ini'),
(2237, 'MOD_TAGS_SIMILAR_FIELD_ORDERING_LABEL', 'Порядок отображния', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_tags_similar.ini'),
(2238, 'MOD_TAGS_SIMILAR_FIELD_ORDERING_DESC', 'Выберите порядок отображения результатов.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_tags_similar.ini'),
(2239, 'MOD_TAGS_SIMILAR_FIELD_ORDERING_COUNT', 'Кол-во найденных меток', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_tags_similar.ini'),
(2240, 'MOD_TAGS_SIMILAR_FIELD_ORDERING_RANDOM', 'Случайный', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_tags_similar.ini'),
(2241, 'MOD_TAGS_SIMILAR_FIELD_ORDERING_COUNT_AND_RANDOM', 'Кол-во найденных & Случайный', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_tags_similar.ini'),
(2242, 'MOD_TAGS_SIMILAR', 'Похожие метки', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_tags_similar.sys.ini'),
(2243, 'MOD_TAGS_SIMILAR_LAYOUT_DEFAULT', 'По умолчанию', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_tags_similar.sys.ini'),
(2244, 'MOD_TAGS_SIMILAR_XML_DESCRIPTION', 'Модуль отображает ссылки на другие элементы с похожими метками. Степень совпадения меток может быть настроена в параметрах модуля', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_tags_similar.sys.ini'),
(2245, 'MOD_USERS_LATEST', 'Новые пользователи', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_users_latest.ini'),
(2246, 'MOD_USERS_LATEST_FIELD_FILTER_GROUPS_DESC', 'Выберите для фильтрации по группам пользователя', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_users_latest.ini'),
(2247, 'MOD_USERS_LATEST_FIELD_FILTER_GROUPS_LABEL', 'Фильтр групп', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_users_latest.ini'),
(2248, 'MOD_USERS_LATEST_FIELD_LINKTOWHAT_DESC', 'Выберите тип сведений для отображения', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_users_latest.ini'),
(2249, 'MOD_USERS_LATEST_FIELD_LINKTOWHAT_LABEL', 'Информация пользователя', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_users_latest.ini'),
(2250, 'MOD_USERS_LATEST_FIELD_NUMBER_DESC', 'Количество последних зарегистрированных пользователей, которое следует показывать', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_users_latest.ini'),
(2251, 'MOD_USERS_LATEST_FIELD_NUMBER_LABEL', 'Кол-во пользователей', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_users_latest.ini'),
(2252, 'MOD_USERS_LATEST_FIELD_VALUE_CONTACT', 'Контакт', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_users_latest.ini'),
(2253, 'MOD_USERS_LATEST_FIELD_VALUE_PROFILE', 'Профиль', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_users_latest.ini'),
(2254, 'MOD_USERS_LATEST_XML_DESCRIPTION', 'Этот модуль выводит список последних, зарегистрированных пользователей', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_users_latest.ini'),
(2255, 'MOD_USERS_LATEST', 'Новые пользователи', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_users_latest.sys.ini'),
(2256, 'MOD_USERS_LATEST_XML_DESCRIPTION', 'Этот модуль выводит список последних, зарегистрированных пользователей', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_users_latest.sys.ini'),
(2257, 'MOD_USERS_LATEST_LAYOUT_DEFAULT', 'По умолчанию', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_users_latest.sys.ini'),
(2258, 'MOD_WEBLINKS', 'Ссылки', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_weblinks.ini'),
(2259, 'MOD_WEBLINKS_FIELD_CATEGORY_DESC', 'Выберите категорию ссылок, которую следует показывать', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_weblinks.ini'),
(2260, 'MOD_WEBLINKS_FIELD_GROUPBY_DESC', 'Если установлено \"да\", веб-ссылки будут сгруппированы по подкатегории.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_weblinks.ini'),
(2261, 'MOD_WEBLINKS_FIELD_GROUPBY_LABEL', 'Группировать по подкатегории', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_weblinks.ini'),
(2262, 'MOD_WEBLINKS_FIELD_GROUPBYSHOWTITLE_DESC', 'Если установлено \"да\", будут показаны названия групп (действует только если включена группировка).', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_weblinks.ini'),
(2263, 'MOD_WEBLINKS_FIELD_GROUPBYSHOWTITLE_LABEL', 'Показать заголовок группы', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_weblinks.ini'),
(2264, 'MOD_WEBLINKS_FIELD_GROUPBYORDERING_DESC', 'Сортировка для подкатегорий (действует только если включена группировка).', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_weblinks.ini'),
(2265, 'MOD_WEBLINKS_FIELD_GROUPBYORDERING_LABEL', 'Сортировка групп', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_weblinks.ini'),
(2266, 'MOD_WEBLINKS_FIELD_GROUPBYDIRECTION_DESC', 'Направление сортировки для подкатегорий (действует только если включена группировка).', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_weblinks.ini'),
(2267, 'MOD_WEBLINKS_FIELD_GROUPBYDIRECTION_LABEL', 'Направление сортировки групп', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_weblinks.ini'),
(2268, 'MOD_WEBLINKS_FIELD_COLUMNS_DESC', 'При группировке по подкатегории, разделить на # столбцы.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_weblinks.ini'),
(2269, 'MOD_WEBLINKS_FIELD_COLUMNS_LABEL', 'Колонки', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_weblinks.ini'),
(2270, 'MOD_WEBLINKS_FIELD_COUNT_DESC', 'Кол-во ссылок, которое следует показывать', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_weblinks.ini'),
(2271, 'MOD_WEBLINKS_FIELD_COUNT_LABEL', 'Кол-во', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_weblinks.ini'),
(2272, 'MOD_WEBLINKS_FIELD_COUNTCLICKS_DESC', 'Если установлено <strong>Да</strong>, система будет регистрировать количество переходов по ссылке.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_weblinks.ini'),
(2273, 'MOD_WEBLINKS_FIELD_COUNTCLICKS_LABEL', 'Подсчёт кликов', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_weblinks.ini'),
(2274, 'MOD_WEBLINKS_FIELD_DESCRIPTION_DESC', 'Показывать описание ссылки', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_weblinks.ini'),
(2275, 'MOD_WEBLINKS_FIELD_DESCRIPTION_LABEL', 'Описание', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_weblinks.ini'),
(2276, 'MOD_WEBLINKS_FIELD_FOLLOW_DESC', 'Инструкции для роботов поисковых систем. <strong>Follow</strong> - сообщает поисковым системам о необходимости проиндексировать ссылку, <strong>No follow</strong> - запрещает индексацию ссылки поисковыми системами.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_weblinks.ini'),
(2277, 'MOD_WEBLINKS_FIELD_FOLLOW_LABEL', 'Индексация ссылок', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_weblinks.ini'),
(2278, 'MOD_WEBLINKS_FIELD_HITS_DESC', 'Показывать количество просмотров ссылок', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_weblinks.ini'),
(2279, 'MOD_WEBLINKS_FIELD_HITS_LABEL', 'Кол-во просмотров', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_weblinks.ini'),
(2280, 'MOD_WEBLINKS_FIELD_ORDERDIRECTION_DESC', 'Установить направление сортировки', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_weblinks.ini'),
(2281, 'MOD_WEBLINKS_FIELD_ORDERDIRECTION_LABEL', 'Направление', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_weblinks.ini'),
(2282, 'MOD_WEBLINKS_FIELD_ORDERING_DESC', 'Порядок отображения ссылок', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_weblinks.ini'),
(2283, 'MOD_WEBLINKS_FIELD_ORDERING_LABEL', 'Порядок', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_weblinks.ini'),
(2284, 'MOD_WEBLINKS_FIELD_TARGET_DESC', 'Окно, в котором откроется ссылка', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_weblinks.ini'),
(2285, 'MOD_WEBLINKS_FIELD_TARGET_LABEL', 'Целевое окно', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_weblinks.ini'),
(2286, 'MOD_WEBLINKS_FIELD_VALUE_ASCENDING', 'По возрастанию', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_weblinks.ini'),
(2287, 'MOD_WEBLINKS_FIELD_VALUE_DESCENDING', 'По убыванию', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_weblinks.ini'),
(2288, 'MOD_WEBLINKS_FIELD_VALUE_FOLLOW', 'Follow', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_weblinks.ini'),
(2289, 'MOD_WEBLINKS_FIELD_VALUE_HITS', 'Количество просмотров', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_weblinks.ini'),
(2290, 'MOD_WEBLINKS_FIELD_VALUE_NOFOLLOW', 'No follow', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_weblinks.ini'),
(2291, 'MOD_WEBLINKS_FIELD_VALUE_ORDER', 'Порядок', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_weblinks.ini'),
(2292, 'MOD_WEBLINKS_HITS', 'Просмотры', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_weblinks.ini'),
(2293, 'MOD_WEBLINKS_XML_DESCRIPTION', 'Этот модуль отображает ссылки из указанной категории компонента Ссылки.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_weblinks.ini'),
(2294, 'MOD_WEBLINKS', 'Ссылки', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_weblinks.sys.ini'),
(2295, 'MOD_WEBLINKS_XML_DESCRIPTION', 'Этот модуль отображает ссылки из указанной категории компонента Ссылки.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_weblinks.sys.ini'),
(2296, 'MOD_WEBLINKS_LAYOUT_DEFAULT', 'По умолчанию', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_weblinks.sys.ini'),
(2297, 'MOD_WHOSONLINE', 'Кто на сайте', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_whosonline.ini'),
(2298, 'MOD_WHOSONLINE_FIELD_FILTER_GROUPS_DESC', 'Выберите для фильтрации по группам пользователя', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_whosonline.ini'),
(2299, 'MOD_WHOSONLINE_FIELD_FILTER_GROUPS_LABEL', 'Фильтр групп', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_whosonline.ini'),
(2300, 'MOD_WHOSONLINE_FIELD_LINKTOWHAT_DESC', 'Выберите тип сведений для отображения', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_whosonline.ini'),
(2301, 'MOD_WHOSONLINE_FIELD_LINKTOWHAT_LABEL', 'Информация', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_whosonline.ini'),
(2302, 'MOD_WHOSONLINE_FIELD_VALUE_BOTH', 'И то и другое', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_whosonline.ini'),
(2303, 'MOD_WHOSONLINE_FIELD_VALUE_CONTACT', 'Контакт', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_whosonline.ini'),
(2304, 'MOD_WHOSONLINE_FIELD_VALUE_NAMES', 'Логины пользователей', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_whosonline.ini'),
(2305, 'MOD_WHOSONLINE_FIELD_VALUE_NUMBER', 'Кол-во гостей/пользователей', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_whosonline.ini'),
(2306, 'MOD_WHOSONLINE_FIELD_VALUE_PROFILE', 'Профиль', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_whosonline.ini'),
(2307, 'MOD_WHOSONLINE_GUESTS_0', 'гостей нет', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_whosonline.ini'),
(2308, 'MOD_WHOSONLINE_GUESTS_1', 'один гость', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_whosonline.ini'),
(2309, 'MOD_WHOSONLINE_GUESTS_2', '%s&#160;гостей', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_whosonline.ini'),
(2310, 'MOD_WHOSONLINE_GUESTS', '%s&#160;гостей', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_whosonline.ini'),
(2311, 'MOD_WHOSONLINE_MEMBERS_0', 'ни одного зарегистрированного пользователя', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_whosonline.ini'),
(2312, 'MOD_WHOSONLINE_MEMBERS_1', 'один зарегистрированный пользователь', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_whosonline.ini'),
(2313, 'MOD_WHOSONLINE_MEMBERS_2', '%s&#160;зарегистрированных пользователей', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_whosonline.ini'),
(2314, 'MOD_WHOSONLINE_MEMBERS', '%s&#160;зарегистрированных пользователей', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_whosonline.ini'),
(2315, 'MOD_WHOSONLINE_SAME_GROUP_MESSAGE', 'Список пользователей, которые относятся к вашим группам пользователей (включая дочерние группы)', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_whosonline.ini'),
(2316, 'MOD_WHOSONLINE_SHOWMODE_DESC', 'Выберите, что должно быть показано', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_whosonline.ini'),
(2317, 'MOD_WHOSONLINE_SHOWMODE_LABEL', 'Показывать', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_whosonline.ini'),
(2318, 'MOD_WHOSONLINE_XML_DESCRIPTION', 'Модуль отображает количество гостей и авторизованных пользователей (тех, что ввели логин и пароль), которые в данный момент просматривают различные страницы сайта.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_whosonline.ini'),
(2319, 'MOD_WHOSONLINE_WE_HAVE', 'Сейчас %1$s и %2$s на сайте', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_whosonline.ini'),
(2320, 'MOD_WHOSONLINE', 'Кто на сайте', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_whosonline.sys.ini'),
(2321, 'MOD_WHOSONLINE_XML_DESCRIPTION', 'Модуль отображает количество гостей и авторизованных пользователей (тех, что ввели логин и пароль), которые в данный момент просматривают различные страницы сайта.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_whosonline.sys.ini'),
(2322, 'MOD_WHOSONLINE_LAYOUT_DEFAULT', 'По умолчанию', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_whosonline.sys.ini'),
(2323, 'MOD_WRAPPER', 'Обёртка (Wrapper)', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_wrapper.ini'),
(2324, 'MOD_WRAPPER_FIELD_ADD_DESC', 'По умолчанию, префикс http:// будет добавлен, если ни один из этих префиксов http:// или https:// не был найден в ссылке. Вы можете отключить эту функцию.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_wrapper.ini'),
(2325, 'MOD_WRAPPER_FIELD_ADD_LABEL', 'Авто доб.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_wrapper.ini'),
(2326, 'MOD_WRAPPER_FIELD_AUTOHEIGHT_DESC', 'Высота будет установлена автоматически под размер внешней страницы. Это работает только для страниц вашего домена.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_wrapper.ini'),
(2327, 'MOD_WRAPPER_FIELD_AUTOHEIGHT_LABEL', 'Высота авто', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_wrapper.ini'),
(2328, 'MOD_WRAPPER_FIELD_HEIGHT_DESC', 'Высота IFrame окна', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_wrapper.ini'),
(2329, 'MOD_WRAPPER_FIELD_HEIGHT_LABEL', 'Высота', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_wrapper.ini'),
(2330, 'MOD_WRAPPER_FIELD_SCROLL_DESC', 'Показать/Скрыть полосы прокрутки.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_wrapper.ini'),
(2331, 'MOD_WRAPPER_FIELD_SCROLL_LABEL', 'Полосы прокрутки', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_wrapper.ini'),
(2332, 'MOD_WRAPPER_FIELD_TARGET_DESC', 'Название IFrame-а когда используется как Target', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_wrapper.ini'),
(2333, 'MOD_WRAPPER_FIELD_TARGET_LABEL', 'Target', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_wrapper.ini'),
(2334, 'MOD_WRAPPER_FIELD_URL_DESC', 'URL на сайт/файл, который необходимо отобразить в окне.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_wrapper.ini'),
(2335, 'MOD_WRAPPER_FIELD_URL_LABEL', 'Ссылка', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_wrapper.ini'),
(2336, 'MOD_WRAPPER_FIELD_VALUE_AUTO', 'Авто', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_wrapper.ini'),
(2337, 'MOD_WRAPPER_FIELD_WIDTH_DESC', 'Ширина IFrame окна. Вы можете ввести абсолютное значение в пикселях или относительное, добавив %.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_wrapper.ini'),
(2338, 'MOD_WRAPPER_FIELD_WIDTH_LABEL', 'Ширина', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_wrapper.ini'),
(2339, 'MOD_WRAPPER_NO_IFRAMES', 'Без IFRAME', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_wrapper.ini'),
(2340, 'MOD_WRAPPER_XML_DESCRIPTION', 'Этот модуль отображает в IFrame-окне содержимое по заданной ссылке (сайт или файл).', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_wrapper.ini'),
(2341, 'MOD_WRAPPER_FIELD_FRAME_LABEL', 'Рамка', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_wrapper.ini'),
(2342, 'MOD_WRAPPER_FIELD_FRAME_DESC', 'Показывать рамку окна IFrame.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_wrapper.ini'),
(2343, 'MOD_WRAPPER', 'Обёртка (Wrapper)', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_wrapper.sys.ini'),
(2344, 'MOD_WRAPPER_NO_IFRAMES', 'Без IFRAME', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_wrapper.sys.ini'),
(2345, 'MOD_WRAPPER_XML_DESCRIPTION', 'Этот модуль отображает в IFrame-окне содержимое по заданной ссылке (сайт или файл).', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_wrapper.sys.ini'),
(2346, 'MOD_WRAPPER_LAYOUT_DEFAULT', 'По умолчанию', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.mod_wrapper.sys.ini'),
(2347, 'TPL_BEEZ3_ADDITIONAL_INFORMATION', 'Дополнительная информация', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.ini'),
(2348, 'TPL_BEEZ3_ALTCLOSE', 'закрыто', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.ini'),
(2349, 'TPL_BEEZ3_ALTOPEN', 'открыт', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.ini'),
(2350, 'TPL_BEEZ3_BIGGER', 'Больше', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.ini'),
(2351, 'TPL_BEEZ3_CLICK', 'Клик', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.ini'),
(2352, 'TPL_BEEZ3_CLOSEMENU', 'Свернуть меню', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.ini'),
(2353, 'TPL_BEEZ3_DECREASE_SIZE', 'Уменьшить размер', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.ini'),
(2354, 'TPL_BEEZ3_ERROR_JUMP_TO_NAV', 'Переход к навигации', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.ini'),
(2355, 'TPL_BEEZ3_FIELD_BOOTSTRAP_DESC', 'Список расширений (используйте запятую в качестве разделителя) для работы которых требуется Bootstrap, например com_name, com_anothername.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.ini'),
(2356, 'TPL_BEEZ3_FIELD_BOOTSTRAP_LABEL', 'Компоненты требующие<br/> Bootstrap', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.ini'),
(2357, 'TPL_BEEZ3_FIELD_DESCRIPTION_DESC', 'Введите здесь описание вашего сайта.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.ini'),
(2358, 'TPL_BEEZ3_FIELD_DESCRIPTION_LABEL', 'Описание сайта', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.ini'),
(2359, 'TPL_BEEZ3_FIELD_HEADER_BACKGROUND_COLOR_DESC', 'Значение используется если в качестве цветовой схемы выбрано «Custom».', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.ini'),
(2360, 'TPL_BEEZ3_FIELD_HEADER_BACKGROUND_COLOR_LABEL', 'Цвет фона', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.ini'),
(2361, 'TPL_BEEZ3_FIELD_HEADER_IMAGE_DESC', 'Значение используется если в качестве цветовой схемы выбрано «Custom».', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.ini'),
(2362, 'TPL_BEEZ3_FIELD_HEADER_IMAGE_LABEL', 'Изображение для шапки', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.ini'),
(2363, 'TPL_BEEZ3_FIELD_LOGO_DESC', 'Пожалуйста, выберите изображение. Если вы не хотите отображать графический логотип, то нажмите на кнопку <strong>Выбрать</strong>, не выделяйте никакого изображения, а затем нажмите <strong>Вставить</strong> в модальном окне.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.ini'),
(2364, 'TPL_BEEZ3_FIELD_LOGO_LABEL', 'Логотип', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.ini'),
(2365, 'TPL_BEEZ3_FIELD_NAVPOSITION_DESC', 'Показывать элементы навигации до или после основного контента', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.ini'),
(2366, 'TPL_BEEZ3_FIELD_NAVPOSITION_LABEL', 'Позиция навигации', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.ini'),
(2367, 'TPL_BEEZ3_FIELD_SITETITLE_DESC', 'Пожалуйста, введите здесь название сайта. Оно будет отображено только если не будет использоваться графический логотип.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.ini'),
(2368, 'TPL_BEEZ3_FIELD_SITETITLE_LABEL', 'Заголовок сайта', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.ini'),
(2369, 'TPL_BEEZ3_FIELD_TEMPLATECOLOR_DESC', 'Цветовая схема шаблона', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.ini'),
(2370, 'TPL_BEEZ3_FIELD_TEMPLATECOLOR_LABEL', 'Цветовая схема', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.ini'),
(2371, 'TPL_BEEZ3_FIELD_WRAPPERLARGE_DESC', 'Ширина обёртки (Wrapper) при скрытых боковых столбцах, в процентах.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.ini'),
(2372, 'TPL_BEEZ3_FIELD_WRAPPERLARGE_LABEL', 'Большая обёртка (%)', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.ini'),
(2373, 'TPL_BEEZ3_FIELD_WRAPPERSMALL_DESC', 'Ширина обёртки (Wrapper) при отображаемых боковых столбцах, в процентах.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.ini'),
(2374, 'TPL_BEEZ3_FIELD_WRAPPERSMALL_LABEL', 'Малая обёртка (%)', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.ini'),
(2375, 'TPL_BEEZ3_FONTSIZE', 'Размер шрифта', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.ini'),
(2376, 'TPL_BEEZ3_INCREASE_SIZE', 'Увеличение размера', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.ini'),
(2377, 'TPL_BEEZ3_JUMP_TO_INFO', 'Перейти к дополнительной информации', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.ini'),
(2378, 'TPL_BEEZ3_JUMP_TO_NAV', 'Перейти к Главной навигации и Войти', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.ini'),
(2379, 'TPL_BEEZ3_NAVIGATION', 'Навигация', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.ini'),
(2380, 'TPL_BEEZ3_NAV_VIEW_SEARCH', 'Nav view search', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.ini'),
(2381, 'TPL_BEEZ3_NEXTTAB', 'Следующая вкладка', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.ini'),
(2382, 'TPL_BEEZ3_OPENMENU', 'Раскрыть меню', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.ini'),
(2383, 'TPL_BEEZ3_OPTION_AFTER_CONTENT', 'после контента', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.ini'),
(2384, 'TPL_BEEZ3_OPTION_BEFORE_CONTENT', 'перед контентом', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.ini'),
(2385, 'TPL_BEEZ3_OPTION_IMAGE', 'Custom', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.ini'),
(2386, 'TPL_BEEZ3_OPTION_NATURE', 'Nature', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.ini'),
(2387, 'TPL_BEEZ3_OPTION_PERSONAL', 'Personal', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.ini'),
(2388, 'TPL_BEEZ3_OPTION_RED', 'Red', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.ini'),
(2389, 'TPL_BEEZ3_OPTION_TURQ', 'Turquoise', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.ini'),
(2390, 'TPL_BEEZ3_POWERED_BY', 'Работает на', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.ini'),
(2391, 'TPL_BEEZ3_RESET', 'Сброс', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.ini'),
(2392, 'TPL_BEEZ3_REVERT_STYLES_TO_DEFAULT', 'Вернуть стили по умолчанию', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.ini'),
(2393, 'TPL_BEEZ3_SEARCH', 'Искать', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.ini'),
(2394, 'TPL_BEEZ3_SKIP_TO_CONTENT', 'Пропустить и перейти к материалам', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.ini'),
(2395, 'TPL_BEEZ3_SKIP_TO_ERROR_CONTENT', 'Переход к сообщению об ошибке и поиску', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.ini'),
(2396, 'TPL_BEEZ3_SMALLER', 'Меньше', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.ini'),
(2397, 'TPL_BEEZ3_SYSTEM_MESSAGE', 'Информация', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.ini'),
(2398, 'TPL_BEEZ3_TEXTRIGHTCLOSE', 'Скрыть информацию', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.ini'),
(2399, 'TPL_BEEZ3_TEXTRIGHTOPEN', 'Показать информацию', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.ini'),
(2400, 'TPL_BEEZ3_XML_DESCRIPTION', 'Шаблон Joomla! Beez (версия с поддержкой HTML 4)', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.ini'),
(2401, 'TPL_BEEZ3_YOUR_SITE_DESCRIPTION', 'Описание вашего сайта', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.ini'),
(2402, 'TPL_BEEZ3_POSITION_DEBUG', 'Debug', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.sys.ini'),
(2403, 'TPL_BEEZ3_POSITION_POSITION-0', 'Search', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.sys.ini'),
(2404, 'TPL_BEEZ3_POSITION_POSITION-10', 'Footer middle', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.sys.ini'),
(2405, 'TPL_BEEZ3_POSITION_POSITION-11', 'Footer bottom', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.sys.ini'),
(2406, 'TPL_BEEZ3_POSITION_POSITION-12', 'Middle top', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.sys.ini'),
(2407, 'TPL_BEEZ3_POSITION_POSITION-13', 'Unused', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.sys.ini'),
(2408, 'TPL_BEEZ3_POSITION_POSITION-14', 'Footer last', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.sys.ini'),
(2409, 'TPL_BEEZ3_POSITION_POSITION-15', 'Header', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.sys.ini'),
(2410, 'TPL_BEEZ3_POSITION_POSITION-1', 'Top', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.sys.ini'),
(2411, 'TPL_BEEZ3_POSITION_POSITION-2', 'Breadcrumbs', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.sys.ini'),
(2412, 'TPL_BEEZ3_POSITION_POSITION-3', 'Right bottom', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.sys.ini'),
(2413, 'TPL_BEEZ3_POSITION_POSITION-4', 'Left middle', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.sys.ini'),
(2414, 'TPL_BEEZ3_POSITION_POSITION-5', 'Left bottom', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.sys.ini'),
(2415, 'TPL_BEEZ3_POSITION_POSITION-6', 'Right top', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.sys.ini'),
(2416, 'TPL_BEEZ3_POSITION_POSITION-7', 'Left top', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.sys.ini'),
(2417, 'TPL_BEEZ3_POSITION_POSITION-8', 'Right middle', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.sys.ini'),
(2418, 'TPL_BEEZ3_POSITION_POSITION-9', 'Footer top', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.sys.ini'),
(2419, 'TPL_BEEZ3_XML_DESCRIPTION', 'Шаблон Joomla! 3.x. Beez3 с поддержкой HTML 5', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_beez3.sys.ini'),
(2420, 'TPL_PROTOSTAR_BACKGROUND_COLOR_DESC', 'Выберите цвет фона для фиксированных макетов. Оставьте пустым для использования значения по умолчанию (#F4F6F7)', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_protostar.ini'),
(2421, 'TPL_PROTOSTAR_BACKGROUND_COLOR_LABEL', 'Цвет фона', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_protostar.ini'),
(2422, 'TPL_PROTOSTAR_BACKTOTOP', 'Наверх', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_protostar.ini'),
(2423, 'TPL_PROTOSTAR_COLOR_DESC', 'Выберите основной цвет для шаблона. Оставьте пустым для использования значения по умолчанию (#0088CC)', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_protostar.ini'),
(2424, 'TPL_PROTOSTAR_COLOR_LABEL', 'Цвет текста', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_protostar.ini'),
(2425, 'TPL_PROTOSTAR_FLUID_DESC', 'Выберите тип контейнера Bootstrap - «Резиновый» (Fluid) или «Фиксированный» (Static).', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_protostar.ini'),
(2426, 'TPL_PROTOSTAR_FLUID_LABEL', 'Тип контейнера', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_protostar.ini'),
(2427, 'TPL_PROTOSTAR_FLUID', 'Резиновый', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_protostar.ini'),
(2428, 'TPL_PROTOSTAR_FONT_DESC', 'Загружать шрифт Google для заголовков (H1, H2, H3, etc.)', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_protostar.ini'),
(2429, 'TPL_PROTOSTAR_FONT_LABEL', 'Шрифт Google для заголовков', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_protostar.ini'),
(2430, 'TPL_PROTOSTAR_FONT_NAME_DESC', 'Например: Open+Sans или Source+Sans+Pro', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_protostar.ini'),
(2431, 'TPL_PROTOSTAR_FONT_NAME_LABEL', 'Название шрифта Google', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_protostar.ini'),
(2432, 'TPL_PROTOSTAR_LOGO_DESC', 'Загрузить пользовательский логотип для шаблона сайта.', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_protostar.ini'),
(2433, 'TPL_PROTOSTAR_LOGO_LABEL', 'Логотип', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_protostar.ini'),
(2434, 'TPL_PROTOSTAR_STATIC', 'Фиксированный', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_protostar.ini'),
(2435, 'TPL_PROTOSTAR_TOGGLE_MENU', 'Включить/выключить навигацию', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_protostar.ini');
INSERT INTO `jm_overrider` (`id`, `constant`, `string`, `file`) VALUES
(2436, 'TPL_PROTOSTAR_XML_DESCRIPTION', 'Protostar - шаблон для Joomla 3, продолжающий космическую тематику шаблонов Joomla (Solarflare для 1.0 и Milkyway для 1.5)) и построенный с использованием Bootstrap от Twitter и библиотеки Joomla User Interface (JUI).', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_protostar.ini'),
(2437, 'TPL_PROTOSTAR_POSITION_BANNER', 'Banner', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_protostar.sys.ini'),
(2438, 'TPL_PROTOSTAR_POSITION_DEBUG', 'Debug', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_protostar.sys.ini'),
(2439, 'TPL_PROTOSTAR_POSITION_POSITION-0', 'Search', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_protostar.sys.ini'),
(2440, 'TPL_PROTOSTAR_POSITION_POSITION-10', 'Unused', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_protostar.sys.ini'),
(2441, 'TPL_PROTOSTAR_POSITION_POSITION-11', 'Unused', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_protostar.sys.ini'),
(2442, 'TPL_PROTOSTAR_POSITION_POSITION-12', 'Unused', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_protostar.sys.ini'),
(2443, 'TPL_PROTOSTAR_POSITION_POSITION-13', 'Unused', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_protostar.sys.ini'),
(2444, 'TPL_PROTOSTAR_POSITION_POSITION-14', 'Unused', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_protostar.sys.ini'),
(2445, 'TPL_PROTOSTAR_POSITION_POSITION-15', 'Unused', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_protostar.sys.ini'),
(2446, 'TPL_PROTOSTAR_POSITION_POSITION-1', 'Navigation', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_protostar.sys.ini'),
(2447, 'TPL_PROTOSTAR_POSITION_POSITION-2', 'Breadcrumbs', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_protostar.sys.ini'),
(2448, 'TPL_PROTOSTAR_POSITION_POSITION-3', 'Top center', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_protostar.sys.ini'),
(2449, 'TPL_PROTOSTAR_POSITION_POSITION-4', 'Unused', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_protostar.sys.ini'),
(2450, 'TPL_PROTOSTAR_POSITION_POSITION-5', 'Unused', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_protostar.sys.ini'),
(2451, 'TPL_PROTOSTAR_POSITION_POSITION-6', 'Unused', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_protostar.sys.ini'),
(2452, 'TPL_PROTOSTAR_POSITION_POSITION-7', 'Right', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_protostar.sys.ini'),
(2453, 'TPL_PROTOSTAR_POSITION_POSITION-8', 'Left', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_protostar.sys.ini'),
(2454, 'TPL_PROTOSTAR_POSITION_POSITION-9', 'Unused', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_protostar.sys.ini'),
(2455, 'TPL_PROTOSTAR_POSITION_FOOTER', 'Footer', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_protostar.sys.ini'),
(2456, 'TPL_PROTOSTAR_XML_DESCRIPTION', 'Protostar - шаблон для Joomla 3, продолжающий космическую тематику шаблонов Joomla (Solarflare для 1.0 и Milkyway для 1.5)) и построенный с использованием Bootstrap от Twitter и библиотеки Joomla User Interface (JUI).', '/home/d/d99796fq/joomla/public_html/language/ru-RU/ru-RU.tpl_protostar.sys.ini');

-- --------------------------------------------------------

--
-- Структура таблицы `jm_postinstall_messages`
--
-- Создание: Мар 30 2018 г., 11:27
--

DROP TABLE IF EXISTS `jm_postinstall_messages`;
CREATE TABLE `jm_postinstall_messages` (
  `postinstall_message_id` bigint(20) UNSIGNED NOT NULL,
  `extension_id` bigint(20) NOT NULL DEFAULT '700' COMMENT 'FK to #__extensions',
  `title_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'Lang key for the title',
  `description_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'Lang key for description',
  `action_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `language_extension` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'com_postinstall' COMMENT 'Extension holding lang keys',
  `language_client_id` tinyint(3) NOT NULL DEFAULT '1',
  `type` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'link' COMMENT 'Message type - message, link, action',
  `action_file` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT 'RAD URI to the PHP file containing action method',
  `action` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT 'Action method name or URL',
  `condition_file` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'RAD URI to file holding display condition method',
  `condition_method` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Display condition method, must return boolean',
  `version_introduced` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '3.2.0' COMMENT 'Version when this message was introduced',
  `enabled` tinyint(3) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `jm_postinstall_messages`
--

INSERT INTO `jm_postinstall_messages` (`postinstall_message_id`, `extension_id`, `title_key`, `description_key`, `action_key`, `language_extension`, `language_client_id`, `type`, `action_file`, `action`, `condition_file`, `condition_method`, `version_introduced`, `enabled`) VALUES
(1, 700, 'PLG_TWOFACTORAUTH_TOTP_POSTINSTALL_TITLE', 'PLG_TWOFACTORAUTH_TOTP_POSTINSTALL_BODY', 'PLG_TWOFACTORAUTH_TOTP_POSTINSTALL_ACTION', 'plg_twofactorauth_totp', 1, 'action', 'site://plugins/twofactorauth/totp/postinstall/actions.php', 'twofactorauth_postinstall_action', 'site://plugins/twofactorauth/totp/postinstall/actions.php', 'twofactorauth_postinstall_condition', '3.2.0', 1),
(2, 700, 'COM_CPANEL_WELCOME_BEGINNERS_TITLE', 'COM_CPANEL_WELCOME_BEGINNERS_MESSAGE', '', 'com_cpanel', 1, 'message', '', '', '', '', '3.2.0', 1),
(3, 700, 'COM_CPANEL_MSG_STATS_COLLECTION_TITLE', 'COM_CPANEL_MSG_STATS_COLLECTION_BODY', '', 'com_cpanel', 1, 'message', '', '', 'admin://components/com_admin/postinstall/statscollection.php', 'admin_postinstall_statscollection_condition', '3.5.0', 1),
(4, 700, 'PLG_SYSTEM_UPDATENOTIFICATION_POSTINSTALL_UPDATECACHETIME', 'PLG_SYSTEM_UPDATENOTIFICATION_POSTINSTALL_UPDATECACHETIME_BODY', 'PLG_SYSTEM_UPDATENOTIFICATION_POSTINSTALL_UPDATECACHETIME_ACTION', 'plg_system_updatenotification', 1, 'action', 'site://plugins/system/updatenotification/postinstall/updatecachetime.php', 'updatecachetime_postinstall_action', 'site://plugins/system/updatenotification/postinstall/updatecachetime.php', 'updatecachetime_postinstall_condition', '3.6.3', 1),
(5, 700, 'COM_CPANEL_MSG_JOOMLA40_PRE_CHECKS_TITLE', 'COM_CPANEL_MSG_JOOMLA40_PRE_CHECKS_BODY', '', 'com_cpanel', 1, 'message', '', '', 'admin://components/com_admin/postinstall/joomla40checks.php', 'admin_postinstall_joomla40checks_condition', '3.7.0', 1),
(6, 700, 'TPL_HATHOR_MESSAGE_POSTINSTALL_TITLE', 'TPL_HATHOR_MESSAGE_POSTINSTALL_BODY', 'TPL_HATHOR_MESSAGE_POSTINSTALL_ACTION', 'tpl_hathor', 1, 'action', 'admin://templates/hathor/postinstall/hathormessage.php', 'hathormessage_postinstall_action', 'admin://templates/hathor/postinstall/hathormessage.php', 'hathormessage_postinstall_condition', '3.7.0', 1),
(7, 700, 'PLG_PLG_RECAPTCHA_VERSION_1_POSTINSTALL_TITLE', 'PLG_PLG_RECAPTCHA_VERSION_1_POSTINSTALL_BODY', 'PLG_PLG_RECAPTCHA_VERSION_1_POSTINSTALL_ACTION', 'plg_captcha_recaptcha', 1, 'action', 'site://plugins/captcha/recaptcha/postinstall/actions.php', 'recaptcha_postinstall_action', 'site://plugins/captcha/recaptcha/postinstall/actions.php', 'recaptcha_postinstall_condition', '3.8.6', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `jm_redirect_links`
--
-- Создание: Мар 30 2018 г., 11:27
--

DROP TABLE IF EXISTS `jm_redirect_links`;
CREATE TABLE `jm_redirect_links` (
  `id` int(10) UNSIGNED NOT NULL,
  `old_url` varchar(2048) COLLATE utf8mb4_unicode_ci NOT NULL,
  `new_url` varchar(2048) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referer` varchar(2048) COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `hits` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `published` tinyint(4) NOT NULL,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `header` smallint(3) NOT NULL DEFAULT '301'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `jm_schemas`
--
-- Создание: Мар 30 2018 г., 11:27
--

DROP TABLE IF EXISTS `jm_schemas`;
CREATE TABLE `jm_schemas` (
  `extension_id` int(11) NOT NULL,
  `version_id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `jm_schemas`
--

INSERT INTO `jm_schemas` (`extension_id`, `version_id`) VALUES
(700, '3.8.6-2018-02-14');

-- --------------------------------------------------------

--
-- Структура таблицы `jm_session`
--
-- Создание: Мар 30 2018 г., 11:27
-- Последнее обновление: Апр 11 2018 г., 09:30
--

DROP TABLE IF EXISTS `jm_session`;
CREATE TABLE `jm_session` (
  `session_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `client_id` tinyint(3) UNSIGNED DEFAULT NULL,
  `guest` tinyint(4) UNSIGNED DEFAULT '1',
  `time` varchar(14) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `data` mediumtext COLLATE utf8mb4_unicode_ci,
  `userid` int(11) DEFAULT '0',
  `username` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `jm_session`
--

INSERT INTO `jm_session` (`session_id`, `client_id`, `guest`, `time`, `data`, `userid`, `username`) VALUES
('020d560e030734d5bf93ecbc233b12e6', 0, 1, '1523438084', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzODA4NDtzOjQ6Imxhc3QiO2k6MTUyMzQzODA4NDtzOjM6Im5vdyI7aToxNTIzNDM4MDg0O319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('07a5c5cad27808c8932fec199a7e7eb6', 0, 1, '1523438078', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzODA3ODtzOjQ6Imxhc3QiO2k6MTUyMzQzODA3ODtzOjM6Im5vdyI7aToxNTIzNDM4MDc4O319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('0a880ad70739f348eba509f085374a75', 0, 1, '1523436528', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzNjUyODtzOjQ6Imxhc3QiO2k6MTUyMzQzNjUyODtzOjM6Im5vdyI7aToxNTIzNDM2NTI4O319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('0af514d710461c5d93473bcf2633eb84', 0, 1, '1523438655', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzODY1NTtzOjQ6Imxhc3QiO2k6MTUyMzQzODY1NTtzOjM6Im5vdyI7aToxNTIzNDM4NjU1O319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('122c25e92c7574374ad8906c49efce42', 0, 1, '1523437638', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzNzYzODtzOjQ6Imxhc3QiO2k6MTUyMzQzNzYzODtzOjM6Im5vdyI7aToxNTIzNDM3NjM4O319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('1e3032b75192ba3377afee7ecd3084b7', 0, 1, '1523437988', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzNzk4ODtzOjQ6Imxhc3QiO2k6MTUyMzQzNzk4ODtzOjM6Im5vdyI7aToxNTIzNDM3OTg4O319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('23ad878274e59fb34ec9a4c927c06333', 0, 1, '1523436861', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzNjg2MTtzOjQ6Imxhc3QiO2k6MTUyMzQzNjg2MTtzOjM6Im5vdyI7aToxNTIzNDM2ODYxO319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('2563d349437fe2607c51dcdb24a9307e', 0, 1, '1523437940', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzNzk0MDtzOjQ6Imxhc3QiO2k6MTUyMzQzNzk0MDtzOjM6Im5vdyI7aToxNTIzNDM3OTQwO319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('26e926d054aad9472210a9beb8847abf', 0, 1, '1523437304', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzNzMwNDtzOjQ6Imxhc3QiO2k6MTUyMzQzNzMwNDtzOjM6Im5vdyI7aToxNTIzNDM3MzA0O319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('279bd3ec3b1a2bc4a65c2cf5b06ddedd', 0, 1, '1523438018', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzODAxODtzOjQ6Imxhc3QiO2k6MTUyMzQzODAxODtzOjM6Im5vdyI7aToxNTIzNDM4MDE4O319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('29d7827446cc0f9cbab6643071eca6a3', 0, 1, '1523436875', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzNjg3NTtzOjQ6Imxhc3QiO2k6MTUyMzQzNjg3NTtzOjM6Im5vdyI7aToxNTIzNDM2ODc1O319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('33bf7f5dcf71ec6a348951c3ac092645', 0, 1, '1523437751', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzNzc1MTtzOjQ6Imxhc3QiO2k6MTUyMzQzNzc1MTtzOjM6Im5vdyI7aToxNTIzNDM3NzUxO319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('3addd1e94384bf5dc9addf6b30278c72', 0, 1, '1523438161', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzODE2MTtzOjQ6Imxhc3QiO2k6MTUyMzQzODE2MTtzOjM6Im5vdyI7aToxNTIzNDM4MTYxO319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('4613ade702bb6abd1bfabbe2dcaef3b5', 0, 1, '1523437513', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzNzUxMztzOjQ6Imxhc3QiO2k6MTUyMzQzNzUxMztzOjM6Im5vdyI7aToxNTIzNDM3NTEzO319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('46b2b4854145c0769a90a9b31734933b', 0, 1, '1523436865', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzNjg2NTtzOjQ6Imxhc3QiO2k6MTUyMzQzNjg2NTtzOjM6Im5vdyI7aToxNTIzNDM2ODY1O319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('4843d4bb70b7a888dfc1ff6763d2b6ce', 0, 1, '1523435379', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzNTM3OTtzOjQ6Imxhc3QiO2k6MTUyMzQzNTM3OTtzOjM6Im5vdyI7aToxNTIzNDM1Mzc5O319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('4931d7672f87ad63ccbeeae3176fac72', 0, 1, '1523436839', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzNjgzOTtzOjQ6Imxhc3QiO2k6MTUyMzQzNjgzOTtzOjM6Im5vdyI7aToxNTIzNDM2ODM5O319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('49f047244b9b6a2a3430f9b31e4ea63b', 0, 1, '1523437183', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzNzE4MztzOjQ6Imxhc3QiO2k6MTUyMzQzNzE4MztzOjM6Im5vdyI7aToxNTIzNDM3MTgzO319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('4a9362e6260c47af764d99569f98ccb8', 0, 1, '1523437308', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzNzMwODtzOjQ6Imxhc3QiO2k6MTUyMzQzNzMwODtzOjM6Im5vdyI7aToxNTIzNDM3MzA4O319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('4ca9255aaeb9f661b4d260dcac557a03', 0, 1, '1523437900', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzNzkwMDtzOjQ6Imxhc3QiO2k6MTUyMzQzNzkwMDtzOjM6Im5vdyI7aToxNTIzNDM3OTAwO319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('585af5c88117a294dcfdb3ea91d97f0e', 0, 1, '1523437938', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzNzkzODtzOjQ6Imxhc3QiO2k6MTUyMzQzNzkzODtzOjM6Im5vdyI7aToxNTIzNDM3OTM4O319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('59202af9ca1de46808a25c1c697ffad5', 0, 1, '1523438826', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzODgyNjtzOjQ6Imxhc3QiO2k6MTUyMzQzODgyNjtzOjM6Im5vdyI7aToxNTIzNDM4ODI2O319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('5c7f422eb1dfe7f2af16e5ddc024ceb9', 0, 1, '1523437041', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzNzA0MTtzOjQ6Imxhc3QiO2k6MTUyMzQzNzA0MTtzOjM6Im5vdyI7aToxNTIzNDM3MDQxO319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('5fd4b41fe8a1594e564af6c075c90b6f', 0, 1, '1523438216', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzODIxNjtzOjQ6Imxhc3QiO2k6MTUyMzQzODIxNjtzOjM6Im5vdyI7aToxNTIzNDM4MjE2O319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('6368591ea41dbdc4a650f134f22ed2bf', 0, 1, '1523437984', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzNzk4MztzOjQ6Imxhc3QiO2k6MTUyMzQzNzk4MztzOjM6Im5vdyI7aToxNTIzNDM3OTgzO319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('652b672cd93bdbf6c25dcefef42f69d0', 0, 1, '1523438275', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzODI3NTtzOjQ6Imxhc3QiO2k6MTUyMzQzODI3NTtzOjM6Im5vdyI7aToxNTIzNDM4Mjc1O319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('67e19aae301f791b06acf92921565ef6', 1, 1, '1523439002', 'joomla|s:736:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjM6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzOTAwMjtzOjQ6Imxhc3QiO2k6MTUyMzQzOTAwMjtzOjM6Im5vdyI7aToxNTIzNDM5MDAyO31zOjU6InRva2VuIjtzOjMyOiJmeFN1SUNCS0ZVcHJVZjlxTjltRXhNR1pvbENybmZ1aSI7fXM6ODoicmVnaXN0cnkiO086MjQ6Ikpvb21sYVxSZWdpc3RyeVxSZWdpc3RyeSI6Mzp7czo3OiIAKgBkYXRhIjtPOjg6InN0ZENsYXNzIjowOnt9czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9czo0OiJ1c2VyIjtPOjIwOiJKb29tbGFcQ01TXFVzZXJcVXNlciI6MTp7czoyOiJpZCI7aTowO319fXM6MTQ6IgAqAGluaXRpYWxpemVkIjtiOjA7czo5OiJzZXBhcmF0b3IiO3M6MToiLiI7fQ==\";', 0, ''),
('78d911c854734ded8b580d015583039f', 0, 1, '1523437841', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzNzg0MTtzOjQ6Imxhc3QiO2k6MTUyMzQzNzg0MTtzOjM6Im5vdyI7aToxNTIzNDM3ODQxO319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('7d5c1677e5fe5cdab09f849d5d476bb2', 0, 1, '1523437517', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzNzUxNztzOjQ6Imxhc3QiO2k6MTUyMzQzNzUxNztzOjM6Im5vdyI7aToxNTIzNDM3NTE3O319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('80b18963d04a15dedcb3b2d98d209a2f', 0, 1, '1523437120', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzNzEyMDtzOjQ6Imxhc3QiO2k6MTUyMzQzNzEyMDtzOjM6Im5vdyI7aToxNTIzNDM3MTIwO319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('82100b84d861af3af69b5085710b1c8e', 0, 1, '1523436207', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzNjIwNjtzOjQ6Imxhc3QiO2k6MTUyMzQzNjIwNjtzOjM6Im5vdyI7aToxNTIzNDM2MjA2O319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('87a2e159e6a6372d5b0c104e1d337ccd', 0, 1, '1523437905', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzNzkwNTtzOjQ6Imxhc3QiO2k6MTUyMzQzNzkwNTtzOjM6Im5vdyI7aToxNTIzNDM3OTA1O319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('8c343847c3e949f4e728d9b00809a9cb', 0, 1, '1523438034', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzODAzNDtzOjQ6Imxhc3QiO2k6MTUyMzQzODAzNDtzOjM6Im5vdyI7aToxNTIzNDM4MDM0O319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('8edd392eb167043d2e8e6dbce10781b2', 0, 1, '1523438577', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzODU3NztzOjQ6Imxhc3QiO2k6MTUyMzQzODU3NztzOjM6Im5vdyI7aToxNTIzNDM4NTc3O319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('9142e6cb8359dcbae8b0b28d62d62f6e', 0, 1, '1523438311', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzODMxMTtzOjQ6Imxhc3QiO2k6MTUyMzQzODMxMTtzOjM6Im5vdyI7aToxNTIzNDM4MzExO319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('917a93cb603b98c9acaac2d042b489d2', 0, 1, '1523438708', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzODcwODtzOjQ6Imxhc3QiO2k6MTUyMzQzODcwODtzOjM6Im5vdyI7aToxNTIzNDM4NzA4O319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('96ce1e0822f07956ea62b220128e0da8', 0, 1, '1523435362', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzNTM2MjtzOjQ6Imxhc3QiO2k6MTUyMzQzNTM2MjtzOjM6Im5vdyI7aToxNTIzNDM1MzYyO319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('9816753f8b08d9d9aaf6ff05815b8f02', 0, 1, '1523435221', 'joomla|s:736:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjM6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzNTIyMTtzOjQ6Imxhc3QiO2k6MTUyMzQzNTIyMTtzOjM6Im5vdyI7aToxNTIzNDM1MjIxO31zOjU6InRva2VuIjtzOjMyOiJSdHVFY2FLRUdPMEpSZ2IzdjdSRWhwYUltVDQ5b2V1bCI7fXM6ODoicmVnaXN0cnkiO086MjQ6Ikpvb21sYVxSZWdpc3RyeVxSZWdpc3RyeSI6Mzp7czo3OiIAKgBkYXRhIjtPOjg6InN0ZENsYXNzIjowOnt9czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9czo0OiJ1c2VyIjtPOjIwOiJKb29tbGFcQ01TXFVzZXJcVXNlciI6MTp7czoyOiJpZCI7aTowO319fXM6MTQ6IgAqAGluaXRpYWxpemVkIjtiOjA7czo5OiJzZXBhcmF0b3IiO3M6MToiLiI7fQ==\";', 0, ''),
('98eed544e5a91d13a34e3f81ef9a0b42', 0, 1, '1523437542', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzNzU0MjtzOjQ6Imxhc3QiO2k6MTUyMzQzNzU0MjtzOjM6Im5vdyI7aToxNTIzNDM3NTQyO319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('99587bc338a55b56ee6e008a952ea702', 0, 1, '1523436437', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzNjQzNztzOjQ6Imxhc3QiO2k6MTUyMzQzNjQzNztzOjM6Im5vdyI7aToxNTIzNDM2NDM3O319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('9ac62d6671093ddff684f43687e567ac', 0, 1, '1523438824', 'joomla|s:1008:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjo0OntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjM6e3M6NzoiY291bnRlciI7aTo3MDtzOjU6InRpbWVyIjtPOjg6InN0ZENsYXNzIjozOntzOjU6InN0YXJ0IjtpOjE1MjM0MzQ0Njc7czo0OiJsYXN0IjtpOjE1MjM0Mzg3MDY7czozOiJub3ciO2k6MTUyMzQzODgyNDt9czo1OiJ0b2tlbiI7czozMjoiWlRTVVZLM2FrWElUMDNGTVlXeVA0TzNodWhTY3Bja0EiO31zOjg6InJlZ2lzdHJ5IjtPOjI0OiJKb29tbGFcUmVnaXN0cnlcUmVnaXN0cnkiOjM6e3M6NzoiACoAZGF0YSI7Tzo4OiJzdGRDbGFzcyI6MDp7fXM6MTQ6IgAqAGluaXRpYWxpemVkIjtiOjA7czo5OiJzZXBhcmF0b3IiO3M6MToiLiI7fXM6NDoidXNlciI7TzoyMDoiSm9vbWxhXENNU1xVc2VyXFVzZXIiOjE6e3M6MjoiaWQiO2k6MDt9czoxMDoiY29tX21haWx0byI7Tzo4OiJzdGRDbGFzcyI6MTp7czo1OiJsaW5rcyI7YToxOntzOjQwOiIwYTczYThjNTA0MThkM2UwYzI3NTQzZGY2NzQ4MjM1Mjg2YTY2YzY2IjtPOjg6InN0ZENsYXNzIjoyOntzOjQ6ImxpbmsiO3M6MzY6Imh0dHA6Ly9kOTk3OTZmcS5iZWdldC50ZWNoL2luZGV4LnBocCI7czo2OiJleHBpcnkiO2k6MTUyMzQzODgyNDt9fX19fXM6MTQ6IgAqAGluaXRpYWxpemVkIjtiOjA7czo5OiJzZXBhcmF0b3IiO3M6MToiLiI7fQ==\";', 0, ''),
('a3e4bc34e0322a814e038a79d0db80f9', 0, 1, '1523438451', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzODQ1MTtzOjQ6Imxhc3QiO2k6MTUyMzQzODQ1MTtzOjM6Im5vdyI7aToxNTIzNDM4NDUxO319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('a6a86fe5b981ee590c023686b297df29', 0, 1, '1523438346', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzODM0NjtzOjQ6Imxhc3QiO2k6MTUyMzQzODM0NjtzOjM6Im5vdyI7aToxNTIzNDM4MzQ2O319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('ab81feeef688b7dfb920761c31e25027', 0, 1, '1523437180', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzNzE4MDtzOjQ6Imxhc3QiO2k6MTUyMzQzNzE4MDtzOjM6Im5vdyI7aToxNTIzNDM3MTgwO319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('acb36d14a8438d5917d0766f7672b019', 0, 1, '1523436205', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzNjIwNTtzOjQ6Imxhc3QiO2k6MTUyMzQzNjIwNTtzOjM6Im5vdyI7aToxNTIzNDM2MjA1O319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('acbedf155c425df417e15ceabb359223', 0, 1, '1523436609', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzNjYwOTtzOjQ6Imxhc3QiO2k6MTUyMzQzNjYwOTtzOjM6Im5vdyI7aToxNTIzNDM2NjA5O319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('b0f42614669d722fa2631f6de81c07b0', 0, 1, '1523437782', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzNzc4MjtzOjQ6Imxhc3QiO2k6MTUyMzQzNzc4MjtzOjM6Im5vdyI7aToxNTIzNDM3NzgyO319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('b3a0c534a602d59c91d2751019ed4270', 0, 1, '1523437013', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzNzAxMztzOjQ6Imxhc3QiO2k6MTUyMzQzNzAxMztzOjM6Im5vdyI7aToxNTIzNDM3MDEzO319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('b3b906668b03d51acb6c599b351b6581', 0, 1, '1523437430', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzNzQzMDtzOjQ6Imxhc3QiO2k6MTUyMzQzNzQzMDtzOjM6Im5vdyI7aToxNTIzNDM3NDMwO319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('b4af9fcfd919c6059b1a4a0cd67af948', 0, 1, '1523437470', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzNzQ3MDtzOjQ6Imxhc3QiO2k6MTUyMzQzNzQ3MDtzOjM6Im5vdyI7aToxNTIzNDM3NDcwO319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('b5d4737daeeefb7e36124c7608b962ef', 0, 1, '1523437687', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzNzY4NztzOjQ6Imxhc3QiO2k6MTUyMzQzNzY4NztzOjM6Im5vdyI7aToxNTIzNDM3Njg3O319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('b94c17f906300403da9344069cf84796', 0, 1, '1523438182', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzODE4MjtzOjQ6Imxhc3QiO2k6MTUyMzQzODE4MjtzOjM6Im5vdyI7aToxNTIzNDM4MTgyO319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('be42d5d5f96a225196342d73a673da34', 0, 1, '1523438437', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzODQzNztzOjQ6Imxhc3QiO2k6MTUyMzQzODQzNztzOjM6Im5vdyI7aToxNTIzNDM4NDM3O319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('c150cf63ef4124f2fce9eb49f2e5f241', 0, 1, '1523435225', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzNTIyNTtzOjQ6Imxhc3QiO2k6MTUyMzQzNTIyNTtzOjM6Im5vdyI7aToxNTIzNDM1MjI1O319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('c1cb26193d080f32b835ed1b06b931d4', 0, 1, '1523437283', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzNzI4MztzOjQ6Imxhc3QiO2k6MTUyMzQzNzI4MztzOjM6Im5vdyI7aToxNTIzNDM3MjgzO319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('c2913f2fb9e74024917ee9eb0815bd21', 0, 1, '1523438632', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzODYzMjtzOjQ6Imxhc3QiO2k6MTUyMzQzODYzMjtzOjM6Im5vdyI7aToxNTIzNDM4NjMyO319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('c982a90b1f52446701d9b6e8604f8b39', 0, 1, '1523437933', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzNzkzMztzOjQ6Imxhc3QiO2k6MTUyMzQzNzkzMztzOjM6Im5vdyI7aToxNTIzNDM3OTMzO319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('cad2b447a9fe3497adf9284851da43bf', 0, 1, '1523435238', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzNTIzODtzOjQ6Imxhc3QiO2k6MTUyMzQzNTIzODtzOjM6Im5vdyI7aToxNTIzNDM1MjM4O319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('ce129781fd04c57b4499bf3c2d630ffe', 0, 1, '1523436990', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzNjk5MDtzOjQ6Imxhc3QiO2k6MTUyMzQzNjk5MDtzOjM6Im5vdyI7aToxNTIzNDM2OTkwO319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('d1be6f84cba6cb6fcfcde1193474f9c0', 0, 1, '1523435223', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzNTIyMztzOjQ6Imxhc3QiO2k6MTUyMzQzNTIyMztzOjM6Im5vdyI7aToxNTIzNDM1MjIzO319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('dbc456e612119dd09fc8c839db33b722', 0, 1, '1523436948', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzNjk0ODtzOjQ6Imxhc3QiO2k6MTUyMzQzNjk0ODtzOjM6Im5vdyI7aToxNTIzNDM2OTQ4O319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('e4084158336b3bf04e1aae013fe1ffff', 0, 1, '1523438087', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzODA4NztzOjQ6Imxhc3QiO2k6MTUyMzQzODA4NztzOjM6Im5vdyI7aToxNTIzNDM4MDg3O319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('e5cba6a293d1b7d6ac2161ef928be774', 0, 1, '1523436951', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzNjk1MTtzOjQ6Imxhc3QiO2k6MTUyMzQzNjk1MTtzOjM6Im5vdyI7aToxNTIzNDM2OTUxO319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('e5e5f026d58ab249e73570bbf60e0f40', 0, 1, '1523438504', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzODUwMztzOjQ6Imxhc3QiO2k6MTUyMzQzODUwMztzOjM6Im5vdyI7aToxNTIzNDM4NTAzO319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('ec52819146c52d28546092101fc5d975', 0, 1, '1523438545', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzODU0NTtzOjQ6Imxhc3QiO2k6MTUyMzQzODU0NTtzOjM6Im5vdyI7aToxNTIzNDM4NTQ1O319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, '');
INSERT INTO `jm_session` (`session_id`, `client_id`, `guest`, `time`, `data`, `userid`, `username`) VALUES
('f3fbe64979557bb1a16a181d91505bb9', 0, 1, '1523438600', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzODYwMDtzOjQ6Imxhc3QiO2k6MTUyMzQzODYwMDtzOjM6Im5vdyI7aToxNTIzNDM4NjAwO319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('f4afc219c74c9b926f207bdebf128383', 0, 1, '1523436747', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzNjc0NztzOjQ6Imxhc3QiO2k6MTUyMzQzNjc0NztzOjM6Im5vdyI7aToxNTIzNDM2NzQ3O319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('fda7c25cbac7754bfa0899213bebcf0e', 0, 1, '1523437117', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzNzExNztzOjQ6Imxhc3QiO2k6MTUyMzQzNzExNztzOjM6Im5vdyI7aToxNTIzNDM3MTE3O319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, ''),
('fee8e69056d9ccc4c4a7456a2b015d2f', 0, 1, '1523437022', 'joomla|s:664:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aToxO3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTUyMzQzNzAyMjtzOjQ6Imxhc3QiO2k6MTUyMzQzNzAyMjtzOjM6Im5vdyI7aToxNTIzNDM3MDIyO319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjA6e31zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086MjA6Ikpvb21sYVxDTVNcVXNlclxVc2VyIjoxOntzOjI6ImlkIjtpOjA7fX19czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', 0, '');

-- --------------------------------------------------------

--
-- Структура таблицы `jm_tags`
--
-- Создание: Мар 30 2018 г., 11:27
--

DROP TABLE IF EXISTS `jm_tags`;
CREATE TABLE `jm_tags` (
  `id` int(10) UNSIGNED NOT NULL,
  `parent_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `lft` int(11) NOT NULL DEFAULT '0',
  `rgt` int(11) NOT NULL DEFAULT '0',
  `level` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `path` varchar(400) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(400) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `note` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `params` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `metadesc` varchar(1024) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The meta description for the page.',
  `metakey` varchar(1024) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The meta keywords for the page.',
  `metadata` varchar(2048) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'JSON encoded metadata properties.',
  `created_user_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `created_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by_alias` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `modified_user_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `modified_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `images` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `urls` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `hits` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `language` char(7) COLLATE utf8mb4_unicode_ci NOT NULL,
  `version` int(10) UNSIGNED NOT NULL DEFAULT '1',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `jm_tags`
--

INSERT INTO `jm_tags` (`id`, `parent_id`, `lft`, `rgt`, `level`, `path`, `title`, `alias`, `note`, `description`, `published`, `checked_out`, `checked_out_time`, `access`, `params`, `metadesc`, `metakey`, `metadata`, `created_user_id`, `created_time`, `created_by_alias`, `modified_user_id`, `modified_time`, `images`, `urls`, `hits`, `language`, `version`, `publish_up`, `publish_down`) VALUES
(1, 0, 0, 3, 0, '', 'ROOT', 'root', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{}', '', '', '', 0, '2017-10-19 14:54:23', '', 0, '0000-00-00 00:00:00', '', '', 0, '*', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(2, 1, 1, 2, 1, 'joomla', 'Joomla', 'joomla', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{\"tag_layout\":\"\",\"tag_link_class\":\"label label-info\",\"image_intro\":\"\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}', '', '', '{\"author\":\"\",\"robots\":\"\"}', 494, '2017-10-19 14:54:23', '', 0, '0000-00-00 00:00:00', '', '', 0, '*', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Структура таблицы `jm_template_styles`
--
-- Создание: Мар 30 2018 г., 11:27
-- Последнее обновление: Апр 11 2018 г., 08:29
--

DROP TABLE IF EXISTS `jm_template_styles`;
CREATE TABLE `jm_template_styles` (
  `id` int(10) UNSIGNED NOT NULL,
  `template` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `client_id` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `home` char(7) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `params` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `jm_template_styles`
--

INSERT INTO `jm_template_styles` (`id`, `template`, `client_id`, `home`, `title`, `params`) VALUES
(4, 'beez3', 0, '0', 'Beez3 - Default', '{\"wrapperSmall\":\"53\",\"wrapperLarge\":\"72\",\"logo\":\"images\\/joomla_black.png\",\"sitetitle\":\"Joomla!\",\"sitedescription\":\"Open Source Content Management\",\"navposition\":\"left\",\"templatecolor\":\"personal\",\"html5\":\"0\"}'),
(5, 'hathor', 1, '0', 'Hathor - Default', '{\"showSiteName\":\"0\",\"colourChoice\":\"\",\"boldText\":\"0\"}'),
(7, 'protostar', 0, '1', 'protostar - Default', '{\"templateColor\":\"\",\"logoFile\":\"\",\"googleFont\":\"1\",\"googleFontName\":\"Open+Sans\",\"fluidContainer\":\"0\"}'),
(8, 'isis', 1, '1', 'isis - Default', '{\"templateColor\":\"\",\"logoFile\":\"\"}'),
(9, 'purity_iii', 0, '0', 'purity_III - По умолчанию', '{\"tpl_article_info_datetime_format\":\"d M Y\"}'),
(10, 'protostar', 0, '0', 'cocoate', '{\"templateColor\":\"#f88638\",\"templateBackgroundColor\":\"#f4f6f7\",\"logoFile\":\"\",\"sitetitle\":\"\",\"sitedescription\":\"\",\"googleFont\":\"1\",\"googleFontName\":\"Roboto\",\"fluidContainer\":\"1\"}');

-- --------------------------------------------------------

--
-- Структура таблицы `jm_ucm_base`
--
-- Создание: Мар 30 2018 г., 11:27
--

DROP TABLE IF EXISTS `jm_ucm_base`;
CREATE TABLE `jm_ucm_base` (
  `ucm_id` int(10) UNSIGNED NOT NULL,
  `ucm_item_id` int(10) NOT NULL,
  `ucm_type_id` int(11) NOT NULL,
  `ucm_language_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `jm_ucm_base`
--

INSERT INTO `jm_ucm_base` (`ucm_id`, `ucm_item_id`, `ucm_type_id`, `ucm_language_id`) VALUES
(1, 1, 1, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `jm_ucm_content`
--
-- Создание: Мар 30 2018 г., 11:27
--

DROP TABLE IF EXISTS `jm_ucm_content`;
CREATE TABLE `jm_ucm_content` (
  `core_content_id` int(10) UNSIGNED NOT NULL,
  `core_type_alias` varchar(400) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'FK to the content types table',
  `core_title` varchar(400) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `core_alias` varchar(400) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `core_body` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `core_state` tinyint(1) NOT NULL DEFAULT '0',
  `core_checked_out_time` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0000-00-00 00:00:00',
  `core_checked_out_user_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `core_access` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `core_params` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `core_featured` tinyint(4) UNSIGNED NOT NULL DEFAULT '0',
  `core_metadata` varchar(2048) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'JSON encoded metadata properties.',
  `core_created_user_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `core_created_by_alias` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `core_created_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `core_modified_user_id` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'Most recent user that modified',
  `core_modified_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `core_language` char(7) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `core_publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `core_publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `core_content_item_id` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'ID from the individual type table',
  `asset_id` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `core_images` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `core_urls` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `core_hits` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `core_version` int(10) UNSIGNED NOT NULL DEFAULT '1',
  `core_ordering` int(11) NOT NULL DEFAULT '0',
  `core_metakey` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `core_metadesc` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `core_catid` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `core_xreference` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'A reference to enable linkages to external data sets.',
  `core_type_id` int(10) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Contains core content data in name spaced fields';

--
-- Дамп данных таблицы `jm_ucm_content`
--

INSERT INTO `jm_ucm_content` (`core_content_id`, `core_type_alias`, `core_title`, `core_alias`, `core_body`, `core_state`, `core_checked_out_time`, `core_checked_out_user_id`, `core_access`, `core_params`, `core_featured`, `core_metadata`, `core_created_user_id`, `core_created_by_alias`, `core_created_time`, `core_modified_user_id`, `core_modified_time`, `core_language`, `core_publish_up`, `core_publish_down`, `core_content_item_id`, `asset_id`, `core_images`, `core_urls`, `core_hits`, `core_version`, `core_ordering`, `core_metakey`, `core_metadesc`, `core_catid`, `core_xreference`, `core_type_id`) VALUES
(1, 'com_content.article', 'Getting Started', 'getting-started', '<p>It\'s easy to get started creating your website. Knowing some of the basics will help.</p><h3>What is a Content Management System?</h3><p>A content management system is software that allows you to create and manage webpages easily by separating the creation of your content from the mechanics required to present it on the web.</p><p>In this site, the content is stored in a <em>database</em>. The look and feel are created by a <em>template</em>. Joomla! brings together the template and your content to create web pages.</p><h3>Logging in</h3><p>To login to your site use the user name and password that were created as part of the installation process. Once logged-in you will be able to create and edit articles and modify some settings.</p><h3>Creating an article</h3><p>Once you are logged-in, a new menu will be visible. To create a new article, click on the \"Submit Article\" link on that menu.</p><p>The new article interface gives you a lot of options, but all you need to do is add a title and put something in the content area. To make it easy to find, set the state to published.</p><div>You can edit an existing article by clicking on the edit icon (this only displays to users who have the right to edit).</div><h3>Template, site settings, and modules</h3><p>The look and feel of your site is controlled by a template. You can change the site name, background colour, highlights colour and more by editing the template settings. Click the \"Template Settings\" in the user menu.</p><p>The boxes around the main content of the site are called modules. You can modify modules on the current page by moving your cursor to the module and clicking the edit link. Always be sure to save and close any module you edit.</p><p>You can change some site settings such as the site name and description by clicking on the \"Site Settings\" link.</p><p>More advanced options for templates, site settings, modules, and more are available in the site administrator.</p><h3>Site and Administrator</h3><p>Your site actually has two separate sites. The site (also called the front end) is what visitors to your site will see. The administrator (also called the back end) is only used by people managing your site. You can access the administrator by clicking the \"Site Administrator\" link on the \"User Menu\" menu (visible once you login) or by adding /administrator to the end of your domain name. The same user name and password are used for both sites.</p><h3>Learn more</h3><p>There is much more to learn about how to use Joomla! to create the website you envision. You can learn much more at the <a href=\"https://docs.joomla.org/\" target=\"_blank\">Joomla! documentation site</a> and on the<a href=\"https://forum.joomla.org/\" target=\"_blank\"> Joomla! forums</a>.</p>', 1, '', 0, 1, '{\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}', 0, '{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}', 494, '', '2017-10-19 14:54:23', 0, '0000-00-00 00:00:00', '*', '2017-10-19 14:54:23', '0000-00-00 00:00:00', 1, 62, '{\"image_intro\":\"\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}', '{\"urla\":false,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":false,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":false,\"urlctext\":\"\",\"targetc\":\"\"}', 0, 1, 0, '', '', 2, '', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `jm_ucm_history`
--
-- Создание: Мар 30 2018 г., 11:27
--

DROP TABLE IF EXISTS `jm_ucm_history`;
CREATE TABLE `jm_ucm_history` (
  `version_id` int(10) UNSIGNED NOT NULL,
  `ucm_item_id` int(10) UNSIGNED NOT NULL,
  `ucm_type_id` int(10) UNSIGNED NOT NULL,
  `version_note` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'Optional version name',
  `save_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `editor_user_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `character_count` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'Number of characters in this version.',
  `sha1_hash` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'SHA1 hash of the version_data column.',
  `version_data` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'json-encoded string of version data',
  `keep_forever` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0=auto delete; 1=keep'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `jm_ucm_history`
--

INSERT INTO `jm_ucm_history` (`version_id`, `ucm_item_id`, `ucm_type_id`, `version_note`, `save_date`, `editor_user_id`, `character_count`, `sha1_hash`, `version_data`, `keep_forever`) VALUES
(1, 2, 10, 'Initial content', '2017-10-19 14:54:23', 494, 558, 'be28228b479aa67bad3dc1db2975232a033d5f0f', '{\"id\":2,\"parent_id\":\"1\",\"lft\":\"1\",\"rgt\":2,\"level\":1,\"path\":\"joomla\",\"title\":\"Joomla\",\"alias\":\"joomla\",\"note\":\"\",\"description\":null,\"published\":1,\"checked_out\":\"0\",\"checked_out_time\":\"0000-00-00 00:00:00\",\"access\":1,\"params\":null,\"metadesc\":null,\"metakey\":null,\"metadata\":null,\"created_user_id\":\"849\",\"created_time\":\"2013-11-16 00:00:00\",\"created_by_alias\":\"\",\"modified_user_id\":\"0\",\"modified_time\":\"0000-00-00 00:00:00\",\"images\":null,\"urls\":null,\"hits\":\"0\",\"language\":\"*\",\"version\":\"1\",\"publish_up\":\"0000-00-00 00:00:00\",\"publish_down\":\"0000-00-00 00:00:00\"}', 0),
(2, 1, 1, 'Initial content', '2017-10-19 14:54:23', 494, 4539, '4f6bf8f67e89553853c3b6e8ed0a6111daaa7a2f', '{\"id\":1,\"asset_id\":54,\"title\":\"Getting Started\",\"alias\":\"getting-started\",\"introtext\":\"<p>It\'s easy to get started creating your website. Knowing some of the basics will help.<\\/p>\\r\\n<h3>What is a Content Management System?<\\/h3>\\r\\n<p>A content management system is software that allows you to create and manage webpages easily by separating the creation of your content from the mechanics required to present it on the web.<\\/p>\\r\\n<p>In this site, the content is stored in a <em>database<\\/em>. The look and feel are created by a <em>template<\\/em>. Joomla! brings together the template and your content to create web pages.<\\/p>\\r\\n<h3>Logging in<\\/h3>\\r\\n<p>To login to your site use the user name and password that were created as part of the installation process. Once logged-in you will be able to create and edit articles and modify some settings.<\\/p>\\r\\n<h3>Creating an article<\\/h3>\\r\\n<p>Once you are logged-in, a new menu will be visible. To create a new article, click on the \\\"Submit Article\\\" link on that menu.<\\/p>\\r\\n<p>The new article interface gives you a lot of options, but all you need to do is add a title and put something in the content area. To make it easy to find, set the state to published.<\\/p>\\r\\n<div>You can edit an existing article by clicking on the edit icon (this only displays to users who have the right to edit).<\\/div>\\r\\n<h3>Template, site settings, and modules<\\/h3>\\r\\n<p>The look and feel of your site is controlled by a template. You can change the site name, background colour, highlights colour and more by editing the template settings. Click the \\\"Template Settings\\\" in the user menu.\\u00a0<\\/p>\\r\\n<p>The boxes around the main content of the site are called modules. \\u00a0You can modify modules on the current page by moving your cursor to the module and clicking the edit link. Always be sure to save and close any module you edit.<\\/p>\\r\\n<p>You can change some site settings such as the site name and description by clicking on the \\\"Site Settings\\\" link.<\\/p>\\r\\n<p>More advanced options for templates, site settings, modules, and more are available in the site administrator.<\\/p>\\r\\n<h3>Site and Administrator<\\/h3>\\r\\n<p>Your site actually has two separate sites. The site (also called the front end) is what visitors to your site will see. The administrator (also called the back end) is only used by people managing your site. You can access the administrator by clicking the \\\"Site Administrator\\\" link on the \\\"User Menu\\\" menu (visible once you login) or by adding \\/administrator to the end of your domain name. The same user name and password are used for both sites.<\\/p>\\r\\n<h3>Learn more<\\/h3>\\r\\n<p>There is much more to learn about how to use Joomla! to create the website you envision. You can learn much more at the <a href=\\\"https:\\/\\/docs.joomla.org\\\" target=\\\"_blank\\\">Joomla! documentation site<\\/a> and on the<a href=\\\"https:\\/\\/forum.joomla.org\\/\\\" target=\\\"_blank\\\"> Joomla! forums<\\/a>.<\\/p>\",\"fulltext\":\"\",\"state\":1,\"catid\":\"2\",\"created\":\"2013-11-16 00:00:00\",\"created_by\":\"849\",\"created_by_alias\":\"\",\"modified\":\"\",\"modified_by\":null,\"checked_out\":null,\"checked_out_time\":null,\"publish_up\":\"2013-11-16 00:00:00\",\"publish_down\":\"0000-00-00 00:00:00\",\"images\":\"{\\\"image_intro\\\":\\\"\\\",\\\"float_intro\\\":\\\"\\\",\\\"image_intro_alt\\\":\\\"\\\",\\\"image_intro_caption\\\":\\\"\\\",\\\"image_fulltext\\\":\\\"\\\",\\\"float_fulltext\\\":\\\"\\\",\\\"image_fulltext_alt\\\":\\\"\\\",\\\"image_fulltext_caption\\\":\\\"\\\"}\",\"urls\":\"{\\\"urla\\\":false,\\\"urlatext\\\":\\\"\\\",\\\"targeta\\\":\\\"\\\",\\\"urlb\\\":false,\\\"urlbtext\\\":\\\"\\\",\\\"targetb\\\":\\\"\\\",\\\"urlc\\\":false,\\\"urlctext\\\":\\\"\\\",\\\"targetc\\\":\\\"\\\"}\",\"attribs\":\"{\\\"show_title\\\":\\\"\\\",\\\"link_titles\\\":\\\"\\\",\\\"show_tags\\\":\\\"\\\",\\\"show_intro\\\":\\\"\\\",\\\"info_block_position\\\":\\\"\\\",\\\"show_category\\\":\\\"\\\",\\\"link_category\\\":\\\"\\\",\\\"show_parent_category\\\":\\\"\\\",\\\"link_parent_category\\\":\\\"\\\",\\\"show_author\\\":\\\"\\\",\\\"link_author\\\":\\\"\\\",\\\"show_create_date\\\":\\\"\\\",\\\"show_modify_date\\\":\\\"\\\",\\\"show_publish_date\\\":\\\"\\\",\\\"show_item_navigation\\\":\\\"\\\",\\\"show_icons\\\":\\\"\\\",\\\"show_print_icon\\\":\\\"\\\",\\\"show_email_icon\\\":\\\"\\\",\\\"show_vote\\\":\\\"\\\",\\\"show_hits\\\":\\\"\\\",\\\"show_noauth\\\":\\\"\\\",\\\"urls_position\\\":\\\"\\\",\\\"alternative_readmore\\\":\\\"\\\",\\\"article_layout\\\":\\\"\\\",\\\"show_publishing_options\\\":\\\"\\\",\\\"show_article_options\\\":\\\"\\\",\\\"show_urls_images_backend\\\":\\\"\\\",\\\"show_urls_images_frontend\\\":\\\"\\\"}\",\"version\":1,\"ordering\":null,\"metakey\":\"\",\"metadesc\":\"\",\"access\":\"1\",\"hits\":null,\"metadata\":\"{\\\"robots\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"rights\\\":\\\"\\\",\\\"xreference\\\":\\\"\\\"}\",\"featured\":\"0\",\"language\":\"*\",\"xreference\":\"\"}', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `jm_updates`
--
-- Создание: Мар 30 2018 г., 11:27
-- Последнее обновление: Апр 11 2018 г., 09:26
--

DROP TABLE IF EXISTS `jm_updates`;
CREATE TABLE `jm_updates` (
  `update_id` int(11) NOT NULL,
  `update_site_id` int(11) DEFAULT '0',
  `extension_id` int(11) DEFAULT '0',
  `name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `element` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `folder` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `client_id` tinyint(3) DEFAULT '0',
  `version` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `detailsurl` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `infourl` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `extra_query` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Available Updates';

--
-- Дамп данных таблицы `jm_updates`
--

INSERT INTO `jm_updates` (`update_id`, `update_site_id`, `extension_id`, `name`, `description`, `element`, `type`, `folder`, `client_id`, `version`, `data`, `detailsurl`, `infourl`, `extra_query`) VALUES
(1, 2, 0, 'Armenian', '', 'pkg_hy-AM', 'package', '', 0, '3.4.4.1', '', 'https://update.joomla.org/language/details3/hy-AM_details.xml', '', ''),
(2, 2, 0, 'Malay', '', 'pkg_ms-MY', 'package', '', 0, '3.4.1.2', '', 'https://update.joomla.org/language/details3/ms-MY_details.xml', '', ''),
(3, 2, 0, 'Romanian', '', 'pkg_ro-RO', 'package', '', 0, '3.7.3.1', '', 'https://update.joomla.org/language/details3/ro-RO_details.xml', '', ''),
(4, 2, 0, 'Flemish', '', 'pkg_nl-BE', 'package', '', 0, '3.8.6.1', '', 'https://update.joomla.org/language/details3/nl-BE_details.xml', '', ''),
(5, 2, 0, 'Chinese Traditional', '', 'pkg_zh-TW', 'package', '', 0, '3.8.0.1', '', 'https://update.joomla.org/language/details3/zh-TW_details.xml', '', ''),
(6, 2, 0, 'French', '', 'pkg_fr-FR', 'package', '', 0, '3.8.6.1', '', 'https://update.joomla.org/language/details3/fr-FR_details.xml', '', ''),
(7, 2, 0, 'Galician', '', 'pkg_gl-ES', 'package', '', 0, '3.3.1.2', '', 'https://update.joomla.org/language/details3/gl-ES_details.xml', '', ''),
(8, 2, 0, 'Georgian', '', 'pkg_ka-GE', 'package', '', 0, '3.8.6.1', '', 'https://update.joomla.org/language/details3/ka-GE_details.xml', '', ''),
(9, 2, 0, 'Greek', '', 'pkg_el-GR', 'package', '', 0, '3.8.6.1', '', 'https://update.joomla.org/language/details3/el-GR_details.xml', '', ''),
(10, 2, 0, 'Japanese', '', 'pkg_ja-JP', 'package', '', 0, '3.8.6.2', '', 'https://update.joomla.org/language/details3/ja-JP_details.xml', '', ''),
(11, 2, 0, 'Hebrew', '', 'pkg_he-IL', 'package', '', 0, '3.1.1.2', '', 'https://update.joomla.org/language/details3/he-IL_details.xml', '', ''),
(12, 2, 0, 'Bengali', '', 'pkg_bn-BD', 'package', '', 0, '3.8.5.1', '', 'https://update.joomla.org/language/details3/bn-BD_details.xml', '', ''),
(13, 2, 0, 'Hungarian', '', 'pkg_hu-HU', 'package', '', 0, '3.8.4.1', '', 'https://update.joomla.org/language/details3/hu-HU_details.xml', '', ''),
(14, 2, 0, 'Afrikaans', '', 'pkg_af-ZA', 'package', '', 0, '3.8.4.1', '', 'https://update.joomla.org/language/details3/af-ZA_details.xml', '', ''),
(15, 2, 0, 'Arabic Unitag', '', 'pkg_ar-AA', 'package', '', 0, '3.7.5.1', '', 'https://update.joomla.org/language/details3/ar-AA_details.xml', '', ''),
(16, 2, 0, 'Belarusian', '', 'pkg_be-BY', 'package', '', 0, '3.2.1.2', '', 'https://update.joomla.org/language/details3/be-BY_details.xml', '', ''),
(17, 2, 0, 'Bulgarian', '', 'pkg_bg-BG', 'package', '', 0, '3.6.5.2', '', 'https://update.joomla.org/language/details3/bg-BG_details.xml', '', ''),
(18, 2, 0, 'Catalan', '', 'pkg_ca-ES', 'package', '', 0, '3.8.3.3', '', 'https://update.joomla.org/language/details3/ca-ES_details.xml', '', ''),
(19, 2, 0, 'Chinese Simplified', '', 'pkg_zh-CN', 'package', '', 0, '3.8.6.1', '', 'https://update.joomla.org/language/details3/zh-CN_details.xml', '', ''),
(20, 2, 0, 'Croatian', '', 'pkg_hr-HR', 'package', '', 0, '3.8.5.1', '', 'https://update.joomla.org/language/details3/hr-HR_details.xml', '', ''),
(21, 2, 0, 'Czech', '', 'pkg_cs-CZ', 'package', '', 0, '3.8.6.1', '', 'https://update.joomla.org/language/details3/cs-CZ_details.xml', '', ''),
(22, 2, 0, 'Danish', '', 'pkg_da-DK', 'package', '', 0, '3.8.6.1', '', 'https://update.joomla.org/language/details3/da-DK_details.xml', '', ''),
(23, 2, 0, 'Dutch', '', 'pkg_nl-NL', 'package', '', 0, '3.8.6.1', '', 'https://update.joomla.org/language/details3/nl-NL_details.xml', '', ''),
(24, 2, 0, 'Esperanto', '', 'pkg_eo-XX', 'package', '', 0, '3.8.3.1', '', 'https://update.joomla.org/language/details3/eo-XX_details.xml', '', ''),
(25, 2, 0, 'Estonian', '', 'pkg_et-EE', 'package', '', 0, '3.7.0.1', '', 'https://update.joomla.org/language/details3/et-EE_details.xml', '', ''),
(26, 2, 0, 'Italian', '', 'pkg_it-IT', 'package', '', 0, '3.8.6.1', '', 'https://update.joomla.org/language/details3/it-IT_details.xml', '', ''),
(27, 2, 0, 'Khmer', '', 'pkg_km-KH', 'package', '', 0, '3.4.5.1', '', 'https://update.joomla.org/language/details3/km-KH_details.xml', '', ''),
(28, 2, 0, 'Korean', '', 'pkg_ko-KR', 'package', '', 0, '3.8.6.1', '', 'https://update.joomla.org/language/details3/ko-KR_details.xml', '', ''),
(29, 2, 0, 'Latvian', '', 'pkg_lv-LV', 'package', '', 0, '3.7.3.1', '', 'https://update.joomla.org/language/details3/lv-LV_details.xml', '', ''),
(30, 2, 0, 'Macedonian', '', 'pkg_mk-MK', 'package', '', 0, '3.6.5.1', '', 'https://update.joomla.org/language/details3/mk-MK_details.xml', '', ''),
(31, 2, 0, 'Norwegian Bokmal', '', 'pkg_nb-NO', 'package', '', 0, '3.8.4.1', '', 'https://update.joomla.org/language/details3/nb-NO_details.xml', '', ''),
(32, 2, 0, 'Norwegian Nynorsk', '', 'pkg_nn-NO', 'package', '', 0, '3.4.2.1', '', 'https://update.joomla.org/language/details3/nn-NO_details.xml', '', ''),
(33, 2, 0, 'Persian', '', 'pkg_fa-IR', 'package', '', 0, '3.8.6.1', '', 'https://update.joomla.org/language/details3/fa-IR_details.xml', '', ''),
(34, 2, 0, 'Polish', '', 'pkg_pl-PL', 'package', '', 0, '3.8.6.1', '', 'https://update.joomla.org/language/details3/pl-PL_details.xml', '', ''),
(35, 2, 0, 'Portuguese', '', 'pkg_pt-PT', 'package', '', 0, '3.8.2.1', '', 'https://update.joomla.org/language/details3/pt-PT_details.xml', '', ''),
(36, 2, 0, 'English AU', '', 'pkg_en-AU', 'package', '', 0, '3.8.6.1', '', 'https://update.joomla.org/language/details3/en-AU_details.xml', '', ''),
(37, 2, 0, 'Slovak', '', 'pkg_sk-SK', 'package', '', 0, '3.8.6.4', '', 'https://update.joomla.org/language/details3/sk-SK_details.xml', '', ''),
(38, 2, 0, 'English US', '', 'pkg_en-US', 'package', '', 0, '3.8.6.1', '', 'https://update.joomla.org/language/details3/en-US_details.xml', '', ''),
(39, 2, 0, 'Swedish', '', 'pkg_sv-SE', 'package', '', 0, '3.8.6.1', '', 'https://update.joomla.org/language/details3/sv-SE_details.xml', '', ''),
(40, 2, 0, 'Syriac', '', 'pkg_sy-IQ', 'package', '', 0, '3.4.5.1', '', 'https://update.joomla.org/language/details3/sy-IQ_details.xml', '', ''),
(41, 2, 0, 'Tamil', '', 'pkg_ta-IN', 'package', '', 0, '3.8.6.1', '', 'https://update.joomla.org/language/details3/ta-IN_details.xml', '', ''),
(42, 2, 0, 'Thai', '', 'pkg_th-TH', 'package', '', 0, '3.8.6.1', '', 'https://update.joomla.org/language/details3/th-TH_details.xml', '', ''),
(43, 2, 0, 'Turkish', '', 'pkg_tr-TR', 'package', '', 0, '3.8.2.1', '', 'https://update.joomla.org/language/details3/tr-TR_details.xml', '', ''),
(44, 2, 0, 'Ukrainian', '', 'pkg_uk-UA', 'package', '', 0, '3.7.1.1', '', 'https://update.joomla.org/language/details3/uk-UA_details.xml', '', ''),
(45, 2, 0, 'Uyghur', '', 'pkg_ug-CN', 'package', '', 0, '3.7.5.1', '', 'https://update.joomla.org/language/details3/ug-CN_details.xml', '', ''),
(46, 2, 0, 'Albanian', '', 'pkg_sq-AL', 'package', '', 0, '3.1.1.2', '', 'https://update.joomla.org/language/details3/sq-AL_details.xml', '', ''),
(47, 2, 0, 'Basque', '', 'pkg_eu-ES', 'package', '', 0, '3.7.5.1', '', 'https://update.joomla.org/language/details3/eu-ES_details.xml', '', ''),
(48, 2, 0, 'Hindi', '', 'pkg_hi-IN', 'package', '', 0, '3.3.6.2', '', 'https://update.joomla.org/language/details3/hi-IN_details.xml', '', ''),
(49, 2, 0, 'German DE', '', 'pkg_de-DE', 'package', '', 0, '3.8.6.1', '', 'https://update.joomla.org/language/details3/de-DE_details.xml', '', ''),
(50, 2, 0, 'Portuguese Brazil', '', 'pkg_pt-BR', 'package', '', 0, '3.8.6.2', '', 'https://update.joomla.org/language/details3/pt-BR_details.xml', '', ''),
(51, 2, 0, 'Serbian Latin', '', 'pkg_sr-YU', 'package', '', 0, '3.8.6.1', '', 'https://update.joomla.org/language/details3/sr-YU_details.xml', '', ''),
(52, 2, 0, 'Spanish', '', 'pkg_es-ES', 'package', '', 0, '3.8.6.1', '', 'https://update.joomla.org/language/details3/es-ES_details.xml', '', ''),
(53, 2, 0, 'Bosnian', '', 'pkg_bs-BA', 'package', '', 0, '3.8.6.1', '', 'https://update.joomla.org/language/details3/bs-BA_details.xml', '', ''),
(54, 2, 0, 'Serbian Cyrillic', '', 'pkg_sr-RS', 'package', '', 0, '3.8.6.1', '', 'https://update.joomla.org/language/details3/sr-RS_details.xml', '', ''),
(55, 2, 0, 'Vietnamese', '', 'pkg_vi-VN', 'package', '', 0, '3.2.1.2', '', 'https://update.joomla.org/language/details3/vi-VN_details.xml', '', ''),
(56, 2, 0, 'Bahasa Indonesia', '', 'pkg_id-ID', 'package', '', 0, '3.6.2.1', '', 'https://update.joomla.org/language/details3/id-ID_details.xml', '', ''),
(57, 2, 0, 'Finnish', '', 'pkg_fi-FI', 'package', '', 0, '3.8.1.1', '', 'https://update.joomla.org/language/details3/fi-FI_details.xml', '', ''),
(58, 2, 0, 'Swahili', '', 'pkg_sw-KE', 'package', '', 0, '3.7.0.1', '', 'https://update.joomla.org/language/details3/sw-KE_details.xml', '', ''),
(59, 2, 0, 'Montenegrin', '', 'pkg_srp-ME', 'package', '', 0, '3.3.1.2', '', 'https://update.joomla.org/language/details3/srp-ME_details.xml', '', ''),
(60, 2, 0, 'English CA', '', 'pkg_en-CA', 'package', '', 0, '3.8.6.1', '', 'https://update.joomla.org/language/details3/en-CA_details.xml', '', ''),
(61, 2, 0, 'French CA', '', 'pkg_fr-CA', 'package', '', 0, '3.6.5.1', '', 'https://update.joomla.org/language/details3/fr-CA_details.xml', '', ''),
(62, 2, 0, 'Welsh', '', 'pkg_cy-GB', 'package', '', 0, '3.8.5.1', '', 'https://update.joomla.org/language/details3/cy-GB_details.xml', '', ''),
(63, 2, 0, 'Sinhala', '', 'pkg_si-LK', 'package', '', 0, '3.3.1.2', '', 'https://update.joomla.org/language/details3/si-LK_details.xml', '', ''),
(64, 2, 0, 'Dari Persian', '', 'pkg_prs-AF', 'package', '', 0, '3.4.4.2', '', 'https://update.joomla.org/language/details3/prs-AF_details.xml', '', ''),
(65, 2, 0, 'Turkmen', '', 'pkg_tk-TM', 'package', '', 0, '3.5.0.2', '', 'https://update.joomla.org/language/details3/tk-TM_details.xml', '', ''),
(66, 2, 0, 'Irish', '', 'pkg_ga-IE', 'package', '', 0, '3.8.5.1', '', 'https://update.joomla.org/language/details3/ga-IE_details.xml', '', ''),
(67, 2, 0, 'Dzongkha', '', 'pkg_dz-BT', 'package', '', 0, '3.6.2.1', '', 'https://update.joomla.org/language/details3/dz-BT_details.xml', '', ''),
(68, 2, 0, 'Slovenian', '', 'pkg_sl-SI', 'package', '', 0, '3.8.6.1', '', 'https://update.joomla.org/language/details3/sl-SI_details.xml', '', ''),
(69, 2, 0, 'Spanish CO', '', 'pkg_es-CO', 'package', '', 0, '3.8.6.1', '', 'https://update.joomla.org/language/details3/es-CO_details.xml', '', ''),
(70, 2, 0, 'German CH', '', 'pkg_de-CH', 'package', '', 0, '3.8.6.1', '', 'https://update.joomla.org/language/details3/de-CH_details.xml', '', ''),
(71, 2, 0, 'German AT', '', 'pkg_de-AT', 'package', '', 0, '3.8.6.1', '', 'https://update.joomla.org/language/details3/de-AT_details.xml', '', ''),
(72, 2, 0, 'German LI', '', 'pkg_de-LI', 'package', '', 0, '3.8.6.1', '', 'https://update.joomla.org/language/details3/de-LI_details.xml', '', ''),
(73, 2, 0, 'German LU', '', 'pkg_de-LU', 'package', '', 0, '3.8.6.1', '', 'https://update.joomla.org/language/details3/de-LU_details.xml', '', ''),
(74, 2, 0, 'English NZ', '', 'pkg_en-NZ', 'package', '', 0, '3.8.6.1', '', 'https://update.joomla.org/language/details3/en-NZ_details.xml', '', ''),
(75, 5, 10004, 'Purity III Template', '', 'purity_iii', 'template', '', 0, '1.2.1', '', 'http://update.joomlart.com/service/tracking/j31/purity_iii.xml', 'http://www.joomlart.com/update-steps', ''),
(76, 6, 10005, 'T3 System Plugin', '', 't3', 'plugin', 'system', 0, '2.7.0', '', 'http://update.joomlart.com/service/tracking/j16/plg_system_t3.xml', 'http://www.joomlart.com/update-steps', '');

-- --------------------------------------------------------

--
-- Структура таблицы `jm_update_sites`
--
-- Создание: Мар 30 2018 г., 11:27
-- Последнее обновление: Апр 11 2018 г., 09:26
--

DROP TABLE IF EXISTS `jm_update_sites`;
CREATE TABLE `jm_update_sites` (
  `update_site_id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `location` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `enabled` int(11) DEFAULT '0',
  `last_check_timestamp` bigint(20) DEFAULT '0',
  `extra_query` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Update Sites';

--
-- Дамп данных таблицы `jm_update_sites`
--

INSERT INTO `jm_update_sites` (`update_site_id`, `name`, `type`, `location`, `enabled`, `last_check_timestamp`, `extra_query`) VALUES
(1, 'Joomla! Core', 'collection', 'https://update.joomla.org/core/list.xml', 1, 1523438799, ''),
(2, 'Accredited Joomla! Translations', 'collection', 'https://update.joomla.org/language/translationlist_3.xml', 1, 1523438799, ''),
(3, 'Joomla! Update Component Update Site', 'extension', 'https://update.joomla.org/core/extensions/com_joomlaupdate.xml', 1, 1523438799, ''),
(4, 'WebInstaller Update Site', 'extension', 'https://appscdn.joomla.org/webapps/jedapps/webinstaller.xml', 1, 1523438800, ''),
(5, '', 'extension', 'http://update.joomlart.com/service/tracking/j31/purity_iii.xml', 1, 1523438803, ''),
(6, '', 'extension', 'http://update.joomlart.com/service/tracking/j16/plg_system_t3.xml', 1, 1523438805, '');

-- --------------------------------------------------------

--
-- Структура таблицы `jm_update_sites_extensions`
--
-- Создание: Мар 30 2018 г., 11:33
--

DROP TABLE IF EXISTS `jm_update_sites_extensions`;
CREATE TABLE `jm_update_sites_extensions` (
  `update_site_id` int(11) NOT NULL DEFAULT '0',
  `extension_id` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Links extensions to update sites';

--
-- Дамп данных таблицы `jm_update_sites_extensions`
--

INSERT INTO `jm_update_sites_extensions` (`update_site_id`, `extension_id`) VALUES
(1, 700),
(2, 802),
(2, 10002),
(3, 28),
(4, 10003),
(5, 10004),
(6, 10005);

-- --------------------------------------------------------

--
-- Структура таблицы `jm_usergroups`
--
-- Создание: Мар 30 2018 г., 11:27
--

DROP TABLE IF EXISTS `jm_usergroups`;
CREATE TABLE `jm_usergroups` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'Primary Key',
  `parent_id` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'Adjacency List Reference Id',
  `lft` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set lft.',
  `rgt` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set rgt.',
  `title` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `jm_usergroups`
--

INSERT INTO `jm_usergroups` (`id`, `parent_id`, `lft`, `rgt`, `title`) VALUES
(1, 0, 1, 18, 'Public'),
(2, 1, 8, 15, 'Registered'),
(3, 2, 9, 14, 'Author'),
(4, 3, 10, 13, 'Editor'),
(5, 4, 11, 12, 'Publisher'),
(6, 1, 4, 7, 'Manager'),
(7, 6, 5, 6, 'Administrator'),
(8, 1, 16, 17, 'Super Users'),
(9, 1, 2, 3, 'Guest');

-- --------------------------------------------------------

--
-- Структура таблицы `jm_users`
--
-- Создание: Мар 30 2018 г., 11:27
-- Последнее обновление: Апр 11 2018 г., 09:30
--

DROP TABLE IF EXISTS `jm_users`;
CREATE TABLE `jm_users` (
  `id` int(11) NOT NULL,
  `name` varchar(400) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `username` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `password` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `block` tinyint(4) NOT NULL DEFAULT '0',
  `sendEmail` tinyint(4) DEFAULT '0',
  `registerDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `lastvisitDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `activation` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `params` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastResetTime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Date of last password reset',
  `resetCount` int(11) NOT NULL DEFAULT '0' COMMENT 'Count of password resets since lastResetTime',
  `otpKey` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'Two factor authentication encrypted keys',
  `otep` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'One time emergency passwords',
  `requireReset` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'Require user to reset password on next login'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `jm_users`
--

INSERT INTO `jm_users` (`id`, `name`, `username`, `email`, `password`, `block`, `sendEmail`, `registerDate`, `lastvisitDate`, `activation`, `params`, `lastResetTime`, `resetCount`, `otpKey`, `otep`, `requireReset`) VALUES
(494, 'Super User', 'Fyodor', 'f.mail.diff@gmail.com', '$2y$10$PlfRrn6oWmWh3puXEj9gkelUmdRD9ka9Mw6pQUIIk9iOsfM6GduBe', 0, 1, '2017-10-19 14:54:23', '2018-04-11 09:30:01', '0', '{}', '0000-00-00 00:00:00', 0, '', '', 0),
(495, 'Test', 'Test', 'qon10820@pqoia.com', '$2y$10$ATKOY0VFOucGgKXSQ6wcu.WetZeqEMzDT.ADU9huWmTLtEMpEKMRW', 0, 1, '2018-04-09 06:30:37', '0000-00-00 00:00:00', '', '{\"admin_style\":\"\",\"admin_language\":\"\",\"language\":\"\",\"editor\":\"\",\"helpsite\":\"\",\"timezone\":\"\"}', '0000-00-00 00:00:00', 0, '', '', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `jm_user_keys`
--
-- Создание: Мар 30 2018 г., 11:33
--

DROP TABLE IF EXISTS `jm_user_keys`;
CREATE TABLE `jm_user_keys` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `series` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `invalid` tinyint(4) NOT NULL,
  `time` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `uastring` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `jm_user_notes`
--
-- Создание: Мар 30 2018 г., 11:27
--

DROP TABLE IF EXISTS `jm_user_notes`;
CREATE TABLE `jm_user_notes` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `catid` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `subject` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `checked_out` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_user_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `created_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_user_id` int(10) UNSIGNED NOT NULL,
  `modified_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `review_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `jm_user_profiles`
--
-- Создание: Мар 30 2018 г., 11:27
--

DROP TABLE IF EXISTS `jm_user_profiles`;
CREATE TABLE `jm_user_profiles` (
  `user_id` int(11) NOT NULL,
  `profile_key` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `profile_value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `ordering` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Simple user profile storage table';

-- --------------------------------------------------------

--
-- Структура таблицы `jm_user_usergroup_map`
--
-- Создание: Мар 30 2018 г., 11:27
-- Последнее обновление: Апр 09 2018 г., 06:30
--

DROP TABLE IF EXISTS `jm_user_usergroup_map`;
CREATE TABLE `jm_user_usergroup_map` (
  `user_id` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'Foreign Key to #__users.id',
  `group_id` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'Foreign Key to #__usergroups.id'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `jm_user_usergroup_map`
--

INSERT INTO `jm_user_usergroup_map` (`user_id`, `group_id`) VALUES
(494, 8),
(495, 2);

-- --------------------------------------------------------

--
-- Структура таблицы `jm_utf8_conversion`
--
-- Создание: Мар 30 2018 г., 11:27
--

DROP TABLE IF EXISTS `jm_utf8_conversion`;
CREATE TABLE `jm_utf8_conversion` (
  `converted` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `jm_utf8_conversion`
--

INSERT INTO `jm_utf8_conversion` (`converted`) VALUES
(2);

-- --------------------------------------------------------

--
-- Структура таблицы `jm_viewlevels`
--
-- Создание: Мар 30 2018 г., 11:27
--

DROP TABLE IF EXISTS `jm_viewlevels`;
CREATE TABLE `jm_viewlevels` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'Primary Key',
  `title` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `rules` varchar(5120) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'JSON encoded access control.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `jm_viewlevels`
--

INSERT INTO `jm_viewlevels` (`id`, `title`, `ordering`, `rules`) VALUES
(1, 'Public', 0, '[1]'),
(2, 'Registered', 2, '[6,2,8]'),
(3, 'Special', 3, '[6,3,8]'),
(5, 'Guest', 1, '[9]'),
(6, 'Super Users', 4, '[8]');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `jm_assets`
--
ALTER TABLE `jm_assets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `idx_asset_name` (`name`),
  ADD KEY `idx_lft_rgt` (`lft`,`rgt`),
  ADD KEY `idx_parent_id` (`parent_id`);

--
-- Индексы таблицы `jm_associations`
--
ALTER TABLE `jm_associations`
  ADD PRIMARY KEY (`context`,`id`),
  ADD KEY `idx_key` (`key`);

--
-- Индексы таблицы `jm_banners`
--
ALTER TABLE `jm_banners`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_state` (`state`),
  ADD KEY `idx_own_prefix` (`own_prefix`),
  ADD KEY `idx_metakey_prefix` (`metakey_prefix`(100)),
  ADD KEY `idx_banner_catid` (`catid`),
  ADD KEY `idx_language` (`language`);

--
-- Индексы таблицы `jm_banner_clients`
--
ALTER TABLE `jm_banner_clients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_own_prefix` (`own_prefix`),
  ADD KEY `idx_metakey_prefix` (`metakey_prefix`(100));

--
-- Индексы таблицы `jm_banner_tracks`
--
ALTER TABLE `jm_banner_tracks`
  ADD PRIMARY KEY (`track_date`,`track_type`,`banner_id`),
  ADD KEY `idx_track_date` (`track_date`),
  ADD KEY `idx_track_type` (`track_type`),
  ADD KEY `idx_banner_id` (`banner_id`);

--
-- Индексы таблицы `jm_categories`
--
ALTER TABLE `jm_categories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cat_idx` (`extension`,`published`,`access`),
  ADD KEY `idx_access` (`access`),
  ADD KEY `idx_checkout` (`checked_out`),
  ADD KEY `idx_path` (`path`(100)),
  ADD KEY `idx_left_right` (`lft`,`rgt`),
  ADD KEY `idx_alias` (`alias`(100)),
  ADD KEY `idx_language` (`language`);

--
-- Индексы таблицы `jm_contact_details`
--
ALTER TABLE `jm_contact_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_access` (`access`),
  ADD KEY `idx_checkout` (`checked_out`),
  ADD KEY `idx_state` (`published`),
  ADD KEY `idx_catid` (`catid`),
  ADD KEY `idx_createdby` (`created_by`),
  ADD KEY `idx_featured_catid` (`featured`,`catid`),
  ADD KEY `idx_language` (`language`),
  ADD KEY `idx_xreference` (`xreference`);

--
-- Индексы таблицы `jm_content`
--
ALTER TABLE `jm_content`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_access` (`access`),
  ADD KEY `idx_checkout` (`checked_out`),
  ADD KEY `idx_state` (`state`),
  ADD KEY `idx_catid` (`catid`),
  ADD KEY `idx_createdby` (`created_by`),
  ADD KEY `idx_featured_catid` (`featured`,`catid`),
  ADD KEY `idx_language` (`language`),
  ADD KEY `idx_xreference` (`xreference`),
  ADD KEY `idx_alias` (`alias`(191));

--
-- Индексы таблицы `jm_contentitem_tag_map`
--
ALTER TABLE `jm_contentitem_tag_map`
  ADD UNIQUE KEY `uc_ItemnameTagid` (`type_id`,`content_item_id`,`tag_id`),
  ADD KEY `idx_tag_type` (`tag_id`,`type_id`),
  ADD KEY `idx_date_id` (`tag_date`,`tag_id`),
  ADD KEY `idx_core_content_id` (`core_content_id`);

--
-- Индексы таблицы `jm_content_frontpage`
--
ALTER TABLE `jm_content_frontpage`
  ADD PRIMARY KEY (`content_id`);

--
-- Индексы таблицы `jm_content_rating`
--
ALTER TABLE `jm_content_rating`
  ADD PRIMARY KEY (`content_id`);

--
-- Индексы таблицы `jm_content_types`
--
ALTER TABLE `jm_content_types`
  ADD PRIMARY KEY (`type_id`),
  ADD KEY `idx_alias` (`type_alias`(100));

--
-- Индексы таблицы `jm_extensions`
--
ALTER TABLE `jm_extensions`
  ADD PRIMARY KEY (`extension_id`),
  ADD KEY `element_clientid` (`element`,`client_id`),
  ADD KEY `element_folder_clientid` (`element`,`folder`,`client_id`),
  ADD KEY `extension` (`type`,`element`,`folder`,`client_id`);

--
-- Индексы таблицы `jm_fields`
--
ALTER TABLE `jm_fields`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_checkout` (`checked_out`),
  ADD KEY `idx_state` (`state`),
  ADD KEY `idx_created_user_id` (`created_user_id`),
  ADD KEY `idx_access` (`access`),
  ADD KEY `idx_context` (`context`(191)),
  ADD KEY `idx_language` (`language`);

--
-- Индексы таблицы `jm_fields_categories`
--
ALTER TABLE `jm_fields_categories`
  ADD PRIMARY KEY (`field_id`,`category_id`);

--
-- Индексы таблицы `jm_fields_groups`
--
ALTER TABLE `jm_fields_groups`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_checkout` (`checked_out`),
  ADD KEY `idx_state` (`state`),
  ADD KEY `idx_created_by` (`created_by`),
  ADD KEY `idx_access` (`access`),
  ADD KEY `idx_context` (`context`(191)),
  ADD KEY `idx_language` (`language`);

--
-- Индексы таблицы `jm_fields_values`
--
ALTER TABLE `jm_fields_values`
  ADD KEY `idx_field_id` (`field_id`),
  ADD KEY `idx_item_id` (`item_id`(191));

--
-- Индексы таблицы `jm_finder_filters`
--
ALTER TABLE `jm_finder_filters`
  ADD PRIMARY KEY (`filter_id`);

--
-- Индексы таблицы `jm_finder_links`
--
ALTER TABLE `jm_finder_links`
  ADD PRIMARY KEY (`link_id`),
  ADD KEY `idx_type` (`type_id`),
  ADD KEY `idx_title` (`title`(100)),
  ADD KEY `idx_md5` (`md5sum`),
  ADD KEY `idx_url` (`url`(75)),
  ADD KEY `idx_published_list` (`published`,`state`,`access`,`publish_start_date`,`publish_end_date`,`list_price`),
  ADD KEY `idx_published_sale` (`published`,`state`,`access`,`publish_start_date`,`publish_end_date`,`sale_price`);

--
-- Индексы таблицы `jm_finder_links_terms0`
--
ALTER TABLE `jm_finder_links_terms0`
  ADD PRIMARY KEY (`link_id`,`term_id`),
  ADD KEY `idx_term_weight` (`term_id`,`weight`),
  ADD KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`);

--
-- Индексы таблицы `jm_finder_links_terms1`
--
ALTER TABLE `jm_finder_links_terms1`
  ADD PRIMARY KEY (`link_id`,`term_id`),
  ADD KEY `idx_term_weight` (`term_id`,`weight`),
  ADD KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`);

--
-- Индексы таблицы `jm_finder_links_terms2`
--
ALTER TABLE `jm_finder_links_terms2`
  ADD PRIMARY KEY (`link_id`,`term_id`),
  ADD KEY `idx_term_weight` (`term_id`,`weight`),
  ADD KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`);

--
-- Индексы таблицы `jm_finder_links_terms3`
--
ALTER TABLE `jm_finder_links_terms3`
  ADD PRIMARY KEY (`link_id`,`term_id`),
  ADD KEY `idx_term_weight` (`term_id`,`weight`),
  ADD KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`);

--
-- Индексы таблицы `jm_finder_links_terms4`
--
ALTER TABLE `jm_finder_links_terms4`
  ADD PRIMARY KEY (`link_id`,`term_id`),
  ADD KEY `idx_term_weight` (`term_id`,`weight`),
  ADD KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`);

--
-- Индексы таблицы `jm_finder_links_terms5`
--
ALTER TABLE `jm_finder_links_terms5`
  ADD PRIMARY KEY (`link_id`,`term_id`),
  ADD KEY `idx_term_weight` (`term_id`,`weight`),
  ADD KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`);

--
-- Индексы таблицы `jm_finder_links_terms6`
--
ALTER TABLE `jm_finder_links_terms6`
  ADD PRIMARY KEY (`link_id`,`term_id`),
  ADD KEY `idx_term_weight` (`term_id`,`weight`),
  ADD KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`);

--
-- Индексы таблицы `jm_finder_links_terms7`
--
ALTER TABLE `jm_finder_links_terms7`
  ADD PRIMARY KEY (`link_id`,`term_id`),
  ADD KEY `idx_term_weight` (`term_id`,`weight`),
  ADD KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`);

--
-- Индексы таблицы `jm_finder_links_terms8`
--
ALTER TABLE `jm_finder_links_terms8`
  ADD PRIMARY KEY (`link_id`,`term_id`),
  ADD KEY `idx_term_weight` (`term_id`,`weight`),
  ADD KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`);

--
-- Индексы таблицы `jm_finder_links_terms9`
--
ALTER TABLE `jm_finder_links_terms9`
  ADD PRIMARY KEY (`link_id`,`term_id`),
  ADD KEY `idx_term_weight` (`term_id`,`weight`),
  ADD KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`);

--
-- Индексы таблицы `jm_finder_links_termsa`
--
ALTER TABLE `jm_finder_links_termsa`
  ADD PRIMARY KEY (`link_id`,`term_id`),
  ADD KEY `idx_term_weight` (`term_id`,`weight`),
  ADD KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`);

--
-- Индексы таблицы `jm_finder_links_termsb`
--
ALTER TABLE `jm_finder_links_termsb`
  ADD PRIMARY KEY (`link_id`,`term_id`),
  ADD KEY `idx_term_weight` (`term_id`,`weight`),
  ADD KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`);

--
-- Индексы таблицы `jm_finder_links_termsc`
--
ALTER TABLE `jm_finder_links_termsc`
  ADD PRIMARY KEY (`link_id`,`term_id`),
  ADD KEY `idx_term_weight` (`term_id`,`weight`),
  ADD KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`);

--
-- Индексы таблицы `jm_finder_links_termsd`
--
ALTER TABLE `jm_finder_links_termsd`
  ADD PRIMARY KEY (`link_id`,`term_id`),
  ADD KEY `idx_term_weight` (`term_id`,`weight`),
  ADD KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`);

--
-- Индексы таблицы `jm_finder_links_termse`
--
ALTER TABLE `jm_finder_links_termse`
  ADD PRIMARY KEY (`link_id`,`term_id`),
  ADD KEY `idx_term_weight` (`term_id`,`weight`),
  ADD KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`);

--
-- Индексы таблицы `jm_finder_links_termsf`
--
ALTER TABLE `jm_finder_links_termsf`
  ADD PRIMARY KEY (`link_id`,`term_id`),
  ADD KEY `idx_term_weight` (`term_id`,`weight`),
  ADD KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`);

--
-- Индексы таблицы `jm_finder_taxonomy`
--
ALTER TABLE `jm_finder_taxonomy`
  ADD PRIMARY KEY (`id`),
  ADD KEY `parent_id` (`parent_id`),
  ADD KEY `state` (`state`),
  ADD KEY `ordering` (`ordering`),
  ADD KEY `access` (`access`),
  ADD KEY `idx_parent_published` (`parent_id`,`state`,`access`);

--
-- Индексы таблицы `jm_finder_taxonomy_map`
--
ALTER TABLE `jm_finder_taxonomy_map`
  ADD PRIMARY KEY (`link_id`,`node_id`),
  ADD KEY `link_id` (`link_id`),
  ADD KEY `node_id` (`node_id`);

--
-- Индексы таблицы `jm_finder_terms`
--
ALTER TABLE `jm_finder_terms`
  ADD PRIMARY KEY (`term_id`),
  ADD UNIQUE KEY `idx_term` (`term`),
  ADD KEY `idx_term_phrase` (`term`,`phrase`),
  ADD KEY `idx_stem_phrase` (`stem`,`phrase`),
  ADD KEY `idx_soundex_phrase` (`soundex`,`phrase`);

--
-- Индексы таблицы `jm_finder_terms_common`
--
ALTER TABLE `jm_finder_terms_common`
  ADD KEY `idx_word_lang` (`term`,`language`),
  ADD KEY `idx_lang` (`language`);

--
-- Индексы таблицы `jm_finder_tokens`
--
ALTER TABLE `jm_finder_tokens`
  ADD KEY `idx_word` (`term`),
  ADD KEY `idx_context` (`context`);

--
-- Индексы таблицы `jm_finder_tokens_aggregate`
--
ALTER TABLE `jm_finder_tokens_aggregate`
  ADD KEY `token` (`term`),
  ADD KEY `keyword_id` (`term_id`);

--
-- Индексы таблицы `jm_finder_types`
--
ALTER TABLE `jm_finder_types`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `title` (`title`);

--
-- Индексы таблицы `jm_languages`
--
ALTER TABLE `jm_languages`
  ADD PRIMARY KEY (`lang_id`),
  ADD UNIQUE KEY `idx_sef` (`sef`),
  ADD UNIQUE KEY `idx_langcode` (`lang_code`),
  ADD KEY `idx_access` (`access`),
  ADD KEY `idx_ordering` (`ordering`);

--
-- Индексы таблицы `jm_menu`
--
ALTER TABLE `jm_menu`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `idx_client_id_parent_id_alias_language` (`client_id`,`parent_id`,`alias`(100),`language`),
  ADD KEY `idx_componentid` (`component_id`,`menutype`,`published`,`access`),
  ADD KEY `idx_menutype` (`menutype`),
  ADD KEY `idx_left_right` (`lft`,`rgt`),
  ADD KEY `idx_alias` (`alias`(100)),
  ADD KEY `idx_path` (`path`(100)),
  ADD KEY `idx_language` (`language`);

--
-- Индексы таблицы `jm_menu_types`
--
ALTER TABLE `jm_menu_types`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `idx_menutype` (`menutype`);

--
-- Индексы таблицы `jm_messages`
--
ALTER TABLE `jm_messages`
  ADD PRIMARY KEY (`message_id`),
  ADD KEY `useridto_state` (`user_id_to`,`state`);

--
-- Индексы таблицы `jm_messages_cfg`
--
ALTER TABLE `jm_messages_cfg`
  ADD UNIQUE KEY `idx_user_var_name` (`user_id`,`cfg_name`);

--
-- Индексы таблицы `jm_modules`
--
ALTER TABLE `jm_modules`
  ADD PRIMARY KEY (`id`),
  ADD KEY `published` (`published`,`access`),
  ADD KEY `newsfeeds` (`module`,`published`),
  ADD KEY `idx_language` (`language`);

--
-- Индексы таблицы `jm_modules_menu`
--
ALTER TABLE `jm_modules_menu`
  ADD PRIMARY KEY (`moduleid`,`menuid`);

--
-- Индексы таблицы `jm_newsfeeds`
--
ALTER TABLE `jm_newsfeeds`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_access` (`access`),
  ADD KEY `idx_checkout` (`checked_out`),
  ADD KEY `idx_state` (`published`),
  ADD KEY `idx_catid` (`catid`),
  ADD KEY `idx_createdby` (`created_by`),
  ADD KEY `idx_language` (`language`),
  ADD KEY `idx_xreference` (`xreference`);

--
-- Индексы таблицы `jm_overrider`
--
ALTER TABLE `jm_overrider`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `jm_postinstall_messages`
--
ALTER TABLE `jm_postinstall_messages`
  ADD PRIMARY KEY (`postinstall_message_id`);

--
-- Индексы таблицы `jm_redirect_links`
--
ALTER TABLE `jm_redirect_links`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_old_url` (`old_url`(100)),
  ADD KEY `idx_link_modifed` (`modified_date`);

--
-- Индексы таблицы `jm_schemas`
--
ALTER TABLE `jm_schemas`
  ADD PRIMARY KEY (`extension_id`,`version_id`);

--
-- Индексы таблицы `jm_session`
--
ALTER TABLE `jm_session`
  ADD PRIMARY KEY (`session_id`),
  ADD KEY `userid` (`userid`),
  ADD KEY `time` (`time`);

--
-- Индексы таблицы `jm_tags`
--
ALTER TABLE `jm_tags`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tag_idx` (`published`,`access`),
  ADD KEY `idx_access` (`access`),
  ADD KEY `idx_checkout` (`checked_out`),
  ADD KEY `idx_path` (`path`(100)),
  ADD KEY `idx_left_right` (`lft`,`rgt`),
  ADD KEY `idx_alias` (`alias`(100)),
  ADD KEY `idx_language` (`language`);

--
-- Индексы таблицы `jm_template_styles`
--
ALTER TABLE `jm_template_styles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_template` (`template`),
  ADD KEY `idx_home` (`home`);

--
-- Индексы таблицы `jm_ucm_base`
--
ALTER TABLE `jm_ucm_base`
  ADD PRIMARY KEY (`ucm_id`),
  ADD KEY `idx_ucm_item_id` (`ucm_item_id`),
  ADD KEY `idx_ucm_type_id` (`ucm_type_id`),
  ADD KEY `idx_ucm_language_id` (`ucm_language_id`);

--
-- Индексы таблицы `jm_ucm_content`
--
ALTER TABLE `jm_ucm_content`
  ADD PRIMARY KEY (`core_content_id`),
  ADD KEY `tag_idx` (`core_state`,`core_access`),
  ADD KEY `idx_access` (`core_access`),
  ADD KEY `idx_alias` (`core_alias`(100)),
  ADD KEY `idx_language` (`core_language`),
  ADD KEY `idx_title` (`core_title`(100)),
  ADD KEY `idx_modified_time` (`core_modified_time`),
  ADD KEY `idx_created_time` (`core_created_time`),
  ADD KEY `idx_content_type` (`core_type_alias`(100)),
  ADD KEY `idx_core_modified_user_id` (`core_modified_user_id`),
  ADD KEY `idx_core_checked_out_user_id` (`core_checked_out_user_id`),
  ADD KEY `idx_core_created_user_id` (`core_created_user_id`),
  ADD KEY `idx_core_type_id` (`core_type_id`);

--
-- Индексы таблицы `jm_ucm_history`
--
ALTER TABLE `jm_ucm_history`
  ADD PRIMARY KEY (`version_id`),
  ADD KEY `idx_ucm_item_id` (`ucm_type_id`,`ucm_item_id`),
  ADD KEY `idx_save_date` (`save_date`);

--
-- Индексы таблицы `jm_updates`
--
ALTER TABLE `jm_updates`
  ADD PRIMARY KEY (`update_id`);

--
-- Индексы таблицы `jm_update_sites`
--
ALTER TABLE `jm_update_sites`
  ADD PRIMARY KEY (`update_site_id`);

--
-- Индексы таблицы `jm_update_sites_extensions`
--
ALTER TABLE `jm_update_sites_extensions`
  ADD PRIMARY KEY (`update_site_id`,`extension_id`);

--
-- Индексы таблицы `jm_usergroups`
--
ALTER TABLE `jm_usergroups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `idx_usergroup_parent_title_lookup` (`parent_id`,`title`),
  ADD KEY `idx_usergroup_title_lookup` (`title`),
  ADD KEY `idx_usergroup_adjacency_lookup` (`parent_id`),
  ADD KEY `idx_usergroup_nested_set_lookup` (`lft`,`rgt`) USING BTREE;

--
-- Индексы таблицы `jm_users`
--
ALTER TABLE `jm_users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_name` (`name`(100)),
  ADD KEY `idx_block` (`block`),
  ADD KEY `username` (`username`),
  ADD KEY `email` (`email`);

--
-- Индексы таблицы `jm_user_keys`
--
ALTER TABLE `jm_user_keys`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `series` (`series`),
  ADD KEY `user_id` (`user_id`);

--
-- Индексы таблицы `jm_user_notes`
--
ALTER TABLE `jm_user_notes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_category_id` (`catid`);

--
-- Индексы таблицы `jm_user_profiles`
--
ALTER TABLE `jm_user_profiles`
  ADD UNIQUE KEY `idx_user_id_profile_key` (`user_id`,`profile_key`);

--
-- Индексы таблицы `jm_user_usergroup_map`
--
ALTER TABLE `jm_user_usergroup_map`
  ADD PRIMARY KEY (`user_id`,`group_id`);

--
-- Индексы таблицы `jm_viewlevels`
--
ALTER TABLE `jm_viewlevels`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `idx_assetgroup_title_lookup` (`title`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `jm_assets`
--
ALTER TABLE `jm_assets`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Primary Key', AUTO_INCREMENT=94;

--
-- AUTO_INCREMENT для таблицы `jm_banners`
--
ALTER TABLE `jm_banners`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `jm_banner_clients`
--
ALTER TABLE `jm_banner_clients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `jm_categories`
--
ALTER TABLE `jm_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT для таблицы `jm_contact_details`
--
ALTER TABLE `jm_contact_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `jm_content`
--
ALTER TABLE `jm_content`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `jm_content_types`
--
ALTER TABLE `jm_content_types`
  MODIFY `type_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT для таблицы `jm_extensions`
--
ALTER TABLE `jm_extensions`
  MODIFY `extension_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10006;

--
-- AUTO_INCREMENT для таблицы `jm_fields`
--
ALTER TABLE `jm_fields`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `jm_fields_groups`
--
ALTER TABLE `jm_fields_groups`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `jm_finder_filters`
--
ALTER TABLE `jm_finder_filters`
  MODIFY `filter_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `jm_finder_links`
--
ALTER TABLE `jm_finder_links`
  MODIFY `link_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `jm_finder_taxonomy`
--
ALTER TABLE `jm_finder_taxonomy`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `jm_finder_terms`
--
ALTER TABLE `jm_finder_terms`
  MODIFY `term_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `jm_finder_types`
--
ALTER TABLE `jm_finder_types`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `jm_languages`
--
ALTER TABLE `jm_languages`
  MODIFY `lang_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `jm_menu`
--
ALTER TABLE `jm_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=110;

--
-- AUTO_INCREMENT для таблицы `jm_menu_types`
--
ALTER TABLE `jm_menu_types`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `jm_messages`
--
ALTER TABLE `jm_messages`
  MODIFY `message_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `jm_modules`
--
ALTER TABLE `jm_modules`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=120;

--
-- AUTO_INCREMENT для таблицы `jm_newsfeeds`
--
ALTER TABLE `jm_newsfeeds`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `jm_overrider`
--
ALTER TABLE `jm_overrider`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Primary Key', AUTO_INCREMENT=2457;

--
-- AUTO_INCREMENT для таблицы `jm_postinstall_messages`
--
ALTER TABLE `jm_postinstall_messages`
  MODIFY `postinstall_message_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT для таблицы `jm_redirect_links`
--
ALTER TABLE `jm_redirect_links`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `jm_tags`
--
ALTER TABLE `jm_tags`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `jm_template_styles`
--
ALTER TABLE `jm_template_styles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT для таблицы `jm_ucm_content`
--
ALTER TABLE `jm_ucm_content`
  MODIFY `core_content_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `jm_ucm_history`
--
ALTER TABLE `jm_ucm_history`
  MODIFY `version_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `jm_updates`
--
ALTER TABLE `jm_updates`
  MODIFY `update_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=77;

--
-- AUTO_INCREMENT для таблицы `jm_update_sites`
--
ALTER TABLE `jm_update_sites`
  MODIFY `update_site_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT для таблицы `jm_usergroups`
--
ALTER TABLE `jm_usergroups`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Primary Key', AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT для таблицы `jm_users`
--
ALTER TABLE `jm_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=496;

--
-- AUTO_INCREMENT для таблицы `jm_user_keys`
--
ALTER TABLE `jm_user_keys`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `jm_user_notes`
--
ALTER TABLE `jm_user_notes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `jm_viewlevels`
--
ALTER TABLE `jm_viewlevels`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Primary Key', AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
