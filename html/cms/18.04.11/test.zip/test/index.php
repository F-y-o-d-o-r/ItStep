<?php
defined('_JEXEC') or die;
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php echo $this->language; ?>" lang="<?php echo $this->language;?>">
    <head>
        <jdoc:include type="head"/>
    </head>
    <body>
        <jdoc:include type="modules" name="position-0" style="xhtml"/>
        <jdoc:include type="modules" name="position-1" style="xhtml"/>
        <jdoc:include type="modules" name="position-2" style="xhtml"/>
        <jdoc:include type="modules" name="position-3" style="xhtml"/>
        <jdoc:include type="modules" name="position-4" style="xhtml"/>
    </body>
</html>

